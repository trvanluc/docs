# UniSupport — PRD và đối chiếu dành cho Antigravity

## Phạm vi và ràng buộc của người dùng

- Đây là bản PRD đã hiệu chỉnh theo góp ý review video, kèm đối chiếu thay đổi.
- Không thêm chức năng. Giữ nguyên 14 mã FR hiện có.
- Bám đúng giờ làm của bảng Resources: giữ từng giờ theo dòng và vai trò; tổng 618 giờ cơ sở + 22 giờ dự phòng = 640 giờ, gồm PM 70 giờ và DevOps 30 giờ.
- Không thay đổi nội dung triển khai kỹ thuật. Các tài liệu kỹ thuật có trong phần PRD tổng hợp được giữ làm ngữ cảnh.
- Các sai lệch nguồn đã được ghi rõ; không diễn giải chúng thành quyết định thêm chức năng, công sức hoặc phương án triển khai.

Tài liệu gồm hai phần: đối chiếu các thay đổi và toàn bộ bản PRD tổng hợp đã sửa. Nội dung PRD được giữ đầy đủ, không rút gọn.

---

# PHẦN 1 — ĐỐI CHIẾU THAY ĐỔI

# Đối chiếu bản sửa PRD UniSupport

Bản sửa chính nằm ở phần 2 của chính tài liệu này. Xuất phát từ file combined-docs.md gốc người dùng gửi; thay đổi trực tiếp nội dung 3 PRD, không lấy bản master plan đã sửa ở lượt trước làm đầu vào.

## Các thay đổi chính

| Mức | Góp ý video / mốc tham chiếu | Phần PRD đã sửa | Kết quả |
| --- | --- | --- | --- |
| P1 | V1 00:55–01:15; V2 00:42–03:27 | STU-01, STF-01, MNG-01, MNG-04 | ADMIN cấp tài khoản; thống nhất vai trò, phòng ban và cổng đăng nhập; không thêm tự đăng ký. |
| P1 | V1 02:20–03:10; 03:30–05:06 | Tổng quan Student, STU-02, STF-02 | Định nghĩa nhóm vấn đề, nguồn danh mục, chủ sở hữu và liên kết phòng ban; không tự thêm danh mục hoặc chức năng quản trị. |
| P1 | V2 03:40–05:46; 08:53–09:21 | STU-03/04, STF-02/03/04/05 | Nối luồng gửi → tiếp nhận → bổ sung/chuyển → trả kết quả → đánh giá; phân biệt tiếp nhận, chuyển phòng và phân công. |
| P1 | V1 00:00–00:15; V2 07:42–10:50 | Tổng quan các phân hệ, bảng đối chiếu cuối PRD Management | Giữ 14 mã FR hiện có; đối chiếu 17 dòng Resources, giữ từng giờ theo vai trò; không đổi mã đăng nhập thành FAQ. |
| P2 | V1 02:20–05:06; 05:17–06:26 | Cả 14 FR | Bổ sung luồng thao tác nghiệp vụ, kết quả và liên kết giữa vai trò bên cạnh đặc tả chi tiết đã có. |
| P2 | V1 02:55–03:10 | STU-02/04, STF-03/05 | Sửa thông báo thiếu .jpeg, lỗi ký tự/câu chữ; mô tả thử lại đánh giá theo AC có sẵn; nhãn Đã giải quyết/Đã đóng khớp trạng thái. |

Mốc video là khoảng tìm nội dung review đã ghi trong báo cáo trước, không phải timestamp một bug ứng dụng. Việc kiểm tra và sửa câu chữ PRD dựa trực tiếp vào tài liệu người dùng gửi. Ý góp ý lời nói dùng bản nhận dạng đã nêu giới hạn ở báo cáo video, không coi là lời trích nguyên văn hoặc quyết định thêm chức năng.

## Kiểm tra ràng buộc

- 4 FR Student + 5 FR Staff + 5 FR Management = **14 FR**, không phát sinh FR mới.
- 17 dòng Resources giữ nguyên tên và **187 giá trị giờ** (8 vai trò + cơ sở + dự phòng + kế hoạch của mỗi dòng).
- **618 giờ cơ sở + 22 giờ dự phòng = 640 giờ toàn dự án**, gồm PM 70 và DevOps 30 giờ; không tăng giờ và không phân lại giờ giữa các vai trò.
- Toàn bộ tài liệu Workflow, Architecture, NFR, ADR và assumptions.md giữ nguyên văn. Các cơ chế kỹ thuật nhúng trong PRD (token, API, server, chống trùng, khóa tranh chấp, audit, cache, công thức SLA và xuất dữ liệu) giữ nguyên.
- Chỉ đóng hai khối Markdown thiếu dấu kết thúc ở README và Business Rules để PRD hiển thị đúng; nội dung trong hai khối không đổi.
- Giữ các giới hạn nhập liệu, số tệp, dung lượng, số sao, giới hạn xuất và tiêu chí hiệu năng gốc. Các AC thêm chỉ kiểm tra lại quy tắc/phạm vi đã có, không thêm năng lực mới.
- Không sửa workbook Resources hay các file gốc trong repository.

## Các sai lệch nguồn được ghi rõ, chưa tự sửa kỹ thuật

FAQ chưa có FR riêng; Resource ghi mở lại nhưng vòng đời CLOSED chưa hỗ trợ; CSAT và dòng phản hồi chưa có ánh xạ effort riêng được xác nhận; PRD/WF mô tả thời điểm đóng chưa đồng nhất; Actors & Roles và PRD/BR-13 còn khác giới hạn file. Các điểm này đã được ghi ở cuối PRD, giữ nguyên giờ và các ràng buộc hiện có, không tự tạo tính năng hoặc chỉnh phương án triển khai.

---

# PHẦN 2 — TOÀN BỘ PRD ĐÃ SỬA

# UniSupport - Tài Liệu Dự Án (Documentation Center)

Chào mừng bạn đến với kho tài liệu kỹ thuật và quản lý dự án chính thức của **UniSupport** – Nền tảng tiếp nhận, xử lý và quản lý yêu cầu hỗ trợ sinh viên tại **Aurora University**.

---

## 📌 Tổng Quan Dự Án

* **Tên dự án:** Hệ thống Quản lý Yêu cầu Hỗ trợ Sinh viên (UniSupport)
* **Khách hàng:** Aurora University
* **Mục tiêu:** Chuẩn hóa và tập trung hóa toàn bộ quy trình gửi, tiếp nhận, điều phối, xử lý và đánh giá yêu cầu hỗ trợ của sinh viên; loại bỏ sự phụ thuộc vào các kênh rời rạc như email, form online hay tin nhắn tự phát.
* **Quy mô phục vụ:** Tối ưu cho quy mô khoảng **3.000 sinh viên**.
* **Nền tảng triển khai:** Web Application (Responsive trên máy tính và thiết bị di động).
* **Thời gian thực hiện:** **14 tuần** (70 ngày làm việc), bao gồm 6 giai đoạn từ thu thập yêu cầu đến bàn giao.
* **Tổng ngân sách:** **300 Triệu VNĐ**.

---

## 📐 Cấu Trúc Thư Mục Tài Liệu

Bộ tài liệu này được cấu trúc chi tiết thành 8 phần chính nhằm đảm bảo tính đồng bộ thông tin giữa đội ngũ phát triển, kiểm thử, quản lý dự án và đại diện Aurora University:

```text
docs/
├── README.md                           # Tổng quan tài liệu & Hướng dẫn tra cứu
├── 01-product/                         # Tổng quan sản phẩm & Phạm vi dự án
│   ├── product-overview.md             # Định hướng & Giải pháp cốt lõi
│   ├── problem-statement.md            # Khó khăn hiện tại & Động lực dự án
│   ├── goals-and-non-goals.md          # Mục tiêu dự án & Phạm vi Out of Scope
│   ├── actors-and-roles.md             # Định nghĩa 3 vai trò (Sinh viên, Nhân viên, Quản lý)
│   └── product-scope.md                # Phạm vi chi tiết & Giả định kỹ thuật
├── 02-domain/                          # Nghiệp vụ & Quy tắc hệ thống
│   ├── domain-overview.md             # Nghiệp vụ hỗ trợ tại Aurora University
│   ├── terminology.md                  # Thuật ngữ chuyên ngành (Ticket, SLA, UAT,...)
│   ├── ticket-model.md                 # Cấu trúc & Trường dữ liệu Ticket
│   ├── ticket-lifecycle.md             # Vòng đời chuyển dịch của Ticket
│   ├── state-transition.md             # Ma trận chuyển đổi trạng thái
│   └── business-rules.md               # Các quy tắc nghiệp vụ bắt buộc
├── 03-modules/                         # Phân hệ chức năng & PRD Chi tiết
│   ├── M01-student-portal.md       # Phân hệ Sinh viên
│   ├── M02-staff-operations.md     # Phân hệ Nhân viên
│   └── M03-management-dashboard.md # Phân hệ Quản lý
├── 04-workflows/                       # Quy trình nghiệp vụ tiêu chuẩn (Workflows)
│   ├── WF-01-submit-support-request.md # Sinh viên tạo Ticket mới
│   ├── WF-02-claim-and-triage.md       # Nhân viên tiếp nhận & Phân loại
│   ├── WF-03-request-supplement.md     # Yêu cầu bổ sung thông tin/giấy tờ
│   ├── WF-04-transfer-department.md    # Chuyển tiếp yêu cầu liên phòng ban
│   ├── WF-05-complete-and-resolve.md   # Xử lý hoàn tất & Đóng Ticket
│   └── WF-06-close-and-rate.md         # Sinh viên nhận kết quả & Đánh giá
├── 05-non-functional-requirements/    # Yêu cầu phi chức năng
│   ├── performance.md                  # Hiệu năng (Đáp ứng 3.000 SV)
│   ├── security.md                     # Bảo mật & Phân quyền xem File
│   ├── reliability.md                  # Độ ổn định & Hạ tầng triển khai
│   ├── usability.md                    # Giao diện Responsive & Đa ngôn ngữ (VI/EN)
│   ├── observability.md                # Ghi nhận thông tin & Audit Log
│   └── deployment.md                   # Hạ tầng Server & Tên miền Client
├── 06-acceptance/                      # Kiểm thử & Nghiệm thu
│   ├── traceability-matrix.md          # Ma trận truy xuất yêu cầu (RTM)
│   └── test-scenarios.md               # Kịch bản kiểm thử UAT (10 ngày nghiệm thu)
├── 07-architecture/                    # Thiết kế Kiến trúc & Kỹ thuật
│   ├── system-context.md               # Sơ đồ ngữ cảnh hệ thống
│   ├── architecture-overview.md        # Kiến trúc Frontend & Backend
│   ├── data-model.md                   # Sơ đồ ERD & Mô hình CSDL
│   ├── api-design.md                   # Thiết kế chuẩn RESTful API
│   ├── security-design.md              # Cơ chế xác thực & Phân quyền
│   └── technical-decisions/            # Các quyết định kỹ thuật quan trọng (ADR)
│       ├── ADR-001-ticket-id-generation.md
│       ├── ADR-002-role-based-access-control.md
│       └── ADR-003-file-attachment-storage.md
└── 08-project/                         # Quản lý Dự án & Tiến độ
    ├── assumptions.md                  # Giả định triển khai
    ├── constraints.md                  # Ràng buộc dự án (14 tuần, 300 tr)
    ├── milestones-and-timeline.md      # Lịch trình 6 giai đoạn & Lịch nghiệm thu/Bảo hành
    ├── open-questions.md               # Danh mục trao đổi cần phê duyệt
    └── glossary.md                     # Thuật ngữ dự án
```
# Định Nghĩa Vai Trò & Phân Quyền Hệ Thống (Actors & Roles)

## 1. Tổng Quan Kiến Trúc Phân Quyền (RBAC Architecture)
Hệ thống UniSupport áp dụng mô hình phân quyền dựa trên vai trò (Role-Based Access Control - RBAC). Mỗi người dùng khi đăng nhập sẽ được cấp một danh tính định danh duy nhất (`user_id`), thuộc về một vai trò chính (`role`) và có thể liên kết với một đơn vị phòng ban (`department_id`).

Quyền hạn của người dùng được xác thực tập trung thông qua JWT Access Token trên từng API Endpoint và được kiểm soát phạm vi dữ liệu (Data Isolation) ở cấp CSDL.

## 2. Chi Tiết Danh Mục Vai Trò (System Roles Specification)

### 2.1. Sinh Viên (`role = STUDENT`)
- **Mô tả:** Sinh viên đang theo học tại Aurora University có nhu cầu gửi yêu cầu giải đáp, hỗ trợ các thủ tục hành chính, đào tạo, tài chính hoặc kỹ thuật.
- **Phạm vi Dữ liệu (Data Scope):** Chỉ xem và thao tác trên dữ liệu do chính mình tạo ra (`WHERE student_id == current_user_id`). Tuyệt đối không có quyền xem Ticket của sinh viên khác.
- **Danh mục Quyền chi tiết (Permissions):**
  - Khởi tạo Ticket mới kèm file đính kèm (Ảnh/PDF $\le 10\text{MB}$, tối đa 3 file).
  - Tra cứu danh sách, tiến độ và lịch sử cập nhật Ticket cá nhân.
  - Bổ sung thông tin/file đính kèm khi Ticket ở trạng thái `NEED_MORE_INFO`.
  - Xem kết quả giải quyết và thực hiện Đánh giá chất lượng dịch vụ (CSAT $1-5$ sao, tối đa 01 lần/Ticket).
  - Nhận thông báo tự động (In-app Bell Notification / Email) khi Ticket có thay đổi trạng thái.

### 2.2. Nhân Viên Phòng Ban (`role = STAFF`)
- **Mô tả:** Cán bộ/Nhân viên thuộc các phòng ban nghiệp vụ (Phòng Đào tạo, Phòng Công tác sinh viên, Phòng Tài chính, Phòng Kế toán,...).
- **Phạm vi Dữ liệu (Data Scope):**
  - Xem danh sách Ticket nằm trong Queue chung của Phòng ban mình phụ trách (`WHERE department_id == current_staff_department_id`).
  - Thao tác trực tiếp trên các Ticket do cá nhân mình tiếp nhận xử lý (`WHERE assignee_id == current_staff_id`).
  - Không có quyền xem hoặc can thiệp vào Ticket của phòng ban khác (khi chưa được chuyển giao).
- **Danh mục Quyền chi tiết (Permissions):**
  - Tiếp nhận (Claim) Ticket mới (`NEW` / `TRANSFERRED`) từ Queue phòng ban về danh sách cá nhân xử lý.
  - Điều chỉnh Phân loại nhóm vấn đề (`category_id`) và Mức độ ưu tiên (`priority`: `LOW`, `MEDIUM`, `HIGH`, `URGENT`).
  - Chuyển tiếp Ticket sang phòng ban khác (`TRANSFERRED`) kèm lý do bắt buộc ($10-500\text{ ký tự}$).
  - Phát yêu cầu bổ sung hồ sơ/giấy tờ tới sinh viên (`NEED_MORE_INFO`).
  - Ghi nhận kết quả xử lý ($20-2000\text{ ký tự}$), đính kèm file kết quả và hoàn tất/giải quyết Ticket (`RESOLVED`).
  - Từ chối Ticket không hợp lệ (`REJECTED`) kèm lý do từ chối ($10-500\text{ ký tự}$).

### 2.3. Quản Lý Phòng Ban (`role = MANAGER`)
- **Mô tả:** Trưởng/Phó phòng ban chuyên môn chịu trách nhiệm giám sát tiến độ giải quyết công việc, phân công nhân sự và theo dõi chỉ số hài lòng trong phạm vi phòng ban.
- **Phạm vi Dữ liệu (Data Scope):** Toàn bộ dữ liệu Ticket, Báo cáo và Nhân sự thuộc `department_id` của mình phụ trách.
- **Danh mục Quyền chi tiết (Permissions):**
  - Toàn bộ quyền của STAFF trong phòng ban.
  - Phân công trực tiếp Ticket cho một Nhân viên cụ thể trong phòng ban hoặc thu hồi (Unassign/Reassign) Ticket cấp lại cho người khác.
  - Xem Dashboard tổng quan chỉ số SLA, cảnh báo quá hạn (SLA Breached) của phòng ban theo thời gian thực.
  - Báo cáo phân tích hiệu năng xử lý của từng nhân viên và điểm CSAT của phòng ban.
  - Export báo cáo thống kê phòng ban ra file Excel/CSV (Tối đa 10.000 dòng/lần).

### 2.4. Quản Trị Hệ Thống (`role = ADMIN`)
- **Mô tả:** Quản trị viên hệ thống UniSupport (Ban Giám hiệu, Phòng CNTT/Vận hành hệ thống).
- **Phạm vi Dữ liệu (Data Scope):** Toàn quyền hệ thống (Global Scope) trên toàn bộ Phòng ban, User, Ticket, Báo cáo và System Logs.
- **Danh mục Quyền chi tiết (Permissions):**
  - Quản lý danh mục Tài khoản người dùng: Tạo mới, Chỉnh sửa thông tin, Đổi vai trò (Role), Gán phòng ban (Department), Khóa/Mở khóa tài khoản (`ACTIVE`/`INACTIVE`).
  - Vô hiệu hóa phiên làm việc (Revoke Session/Token) ngay lập tức khi khóa tài khoản.
  - Xem Dashboard và Báo cáo tổng quan toàn trường (Cross-department Analytics).
  - Cấu hình danh mục nhóm vấn đề (Categories) và Khung thời gian SLA.
  - Xem và tra cứu Nhật ký hệ thống (Audit Trail Log) đối với các thao tác quản trị nhạy cảm.

## 3. Ma Trận Phân Quyền Chi Tiết (Access Control Matrix)

| Chức năng / API Endpoint | STUDENT | STAFF | MANAGER | ADMIN |
| :--- | :---: | :---: | :---: | :---: |
| **Đăng nhập & Lấy Profile** | X | X | X | X |
| **Tạo Ticket hỗ trợ mới** | X | - | - | - |
| **Xem danh sách Ticket cá nhân** | X | - | - | - |
| **Gửi bổ sung hồ sơ (File/Note)** | X | - | - | - |
| **Gửi Đánh giá hài lòng (CSAT)** | X | - | - | - |
| **Xem Queue Ticket Phòng ban** | - | X | X | X |
| **Tiếp nhận xử lý Ticket (Claim)** | - | X | X | X |
| **Chuyển phòng ban / Yêu cầu bổ sung** | - | X | X | X |
| **Ghi kết quả & Hoàn tất Ticket** | - | X | X | X |
| **Phân công / Thu hồi Ticket người khác** | - | - | X | X |
| **Xem Dashboard & Báo cáo Phòng ban** | - | - | X | X |
| **Xem Dashboard & Báo cáo Toàn trường** | - | - | - | X |
| **Tạo / Sửa / Khóa Tài khoản User** | - | - | - | X |
| **Xem Audit Log hệ thống** | - | - | - | X |

## 4. Ràng Buộc Kỹ Thuật & Mã Lỗi Truy Cập (Security & Error Handling Specs)

| Ràng buộc Kỹ thuật | Xử lý vi phạm | Mã lỗi HTTP & Error Code | Message hiển thị cho người dùng |
| :--- | :--- | :--- | :--- |
| **Chưa xác thực (Unauthenticated)** | Không gửi Bearer Token hoặc Token hết hạn. | `401 Unauthorized`<br><br>`UNAUTHORIZED` | "Phiên đăng nhập đã hết hạn. Vui lòng đăng nhập lại." |
| **Sai vai trò (Role Mismatch)** | Student cố truy cập API Staff/Admin. | `403 Forbidden`<br><br>`FORBIDDEN_ACCESS` | "Bạn không có quyền truy cập vào chức năng này." |
| **Thao tác ngoài Scope Dữ liệu** | Staff cố xem/sửa Ticket của Phòng ban khác. | `403 Forbidden`<br><br>`FORBIDDEN_DEPARTMENT_ACCESS` | "Bạn không có quyền thao tác trên Ticket thuộc phòng ban khác." |
| **Student truy cập Ticket người khác** | Đổi `ticket_id` trên URL sang Ticket của bạn học. | `403 Forbidden`<br><br>`FORBIDDEN_ACCESS` | "Không tìm thấy yêu cầu hoặc bạn không có quyền truy cập." |
| **Tài khoản bị khóa (INACTIVE)** | Dùng Token của tài khoản đã bị Admin vô hiệu hóa. | `403 Forbidden`<br><br>`ACCOUNT_DISABLED` | "Tài khoản của bạn đã bị vô hiệu hóa. Vui lòng liên hệ Admin." |
# Mục Tiêu Dự Án & Phạm Vi Ngoài Dự Án

## 1. Mục Tiêu Cốt Lõi (Goals)
Dự án UniSupport tập trung giải quyết các mục tiêu chiến lược sau:

* **Tập trung hóa đầu mối:** Cung cấp kênh duy nhất tiếp nhận yêu cầu hỗ trợ, cấp mã Ticket tự động để sinh viên tra cứu tiến độ và người phụ trách một cách minh bạch.
* **Tối ưu quy trình vận hành:** Chuẩn hóa quy trình tiếp nhận, phân loại, chuyển tiếp và đóng yêu cầu; giảm thiểu bỏ sót hay xử lý trùng lặp.
* **Nâng cao năng lực giám sát:** Cung cấp chỉ số trực quan (số lượng Ticket mới, đang xử lý, quá hạn, nhóm sự cố phổ biến, thời gian xử lý trung bình) hỗ trợ ban quản lý điều phối nguồn lực.
* **Đảm bảo trải nghiệm người dùng:** Giao diện Responsive thân thiện, dễ thao tác trên máy tính và thiết bị di động, hỗ trợ cơ bản hai ngôn ngữ Tiếng Việt và Tiếng Anh.

---

## 2. Các Hạng Mục Ngoài Phạm Vi (Non-Goals / Out of Scope)
Để đảm bảo tiến độ 14 tuần và ngân sách 300 Triệu VNĐ, các hạng mục sau **tuyệt đối không nằm trong phạm vi triển khai**:

* **Mobile App độc lập:** Không phát triển ứng dụng di động riêng lẻ trên App Store (iOS) hoặc Google Play (Android).
* **Tích hợp bên thứ ba mở rộng:** Không tích hợp các hệ thống ngoài phạm vi đã thỏa thuận.
* **Hạ tầng & Vận hành máy chủ lâu dài:** Không bao gồm việc thiết lập tự động sao lưu, theo dõi hạ tầng server hay bảo trì hạ tầng dài hạn sau giai đoạn bảo hành.
* **Phân quyền nâng cao & Audit log chi tiết:** Không phát triển phân quyền đa cấp phức tạp hoặc ghi lịch sử thao tác sâu ở cấp độ dữ liệu hệ thống.
* **Giao tiếp Real-time nâng cao:** Không xây dựng tính năng Chat trực tiếp (Livechat) hay Gọi thoại/Video call nội bộ.
* **Tối ưu hóa chịu tải lớn:** Không thiết kế kiến trúc phục vụ chịu tải vượt quá quy mô **3.000 sinh viên**.
# Hiện Trạng & Khó Khăn (Problem Statement)

## 1. Bối Cảnh & Bất Cập Hiện Tại
Trước khi triển khai dự án UniSupport, công tác tiếp nhận và xử lý yêu cầu hỗ trợ sinh viên tại Aurora University gặp nhiều hạn chế do sự phụ thuộc vào các kênh liên lạc rời rạc:

* **Email cá nhân/phòng ban:** Dễ bị trôi thư, thiếu công cụ phân loại tự động và không theo dõi được trạng thái xử lý.
* **Biểu mẫu trực tuyến (Google Forms / Microsoft Forms):** Dữ liệu phân tán, khó tương tác phản hồi hai chiều với sinh viên và không hỗ trợ quy trình chuyển tiếp liên phòng ban.
* **Tin nhắn tự phát / Trực tiếp:** Khó lưu vết thông tin, dễ dẫn đến thiếu đồng nhất trong câu trả lời từ các nhân viên khác nhau.

---

## 2. Các Tắc Nghẽn Vận Hành Cụ Thể

### Đối với Sinh viên
* **Thiếu tính minh bạch:** Sinh viên không biết yêu cầu của mình đang do ai thụ lý, tiến độ đến đâu và khi nào có kết quả.
* **Phải gửi yêu cầu nhiều lần:** Do không nhận được phản hồi kịp thời, sinh viên thường xuyên gửi lại yêu cầu qua nhiều kênh khác nhau, gây ra tình trạng quá tải và trùng lặp dữ liệu.

### Đối với Nhân viên các Phòng ban
* **Bỏ sót & Bỏ trùng:** Khó phân công công việc rõ ràng, dẫn đến việc một yêu cầu có thể bị nhiều người xử lý trùng lặp hoặc bị bỏ sót hoàn toàn.
* **Khó khăn trong việc phối hợp:** Khi yêu cầu liên quan đến nhiều phòng ban, nhân viên gặp khó khăn trong việc chuyển giao và theo dõi kết quả xử lý từ phòng ban phối hợp.

### Đối với Ban Quản lý
* **Thiếu số liệu giám sát:** Không có công cụ đo lường khối lượng công việc thực tế của từng phòng ban/nhân viên.
* **Không nắm bắt được vấn đề nóng:** Không thể thống kê chính xác nhóm sự cố nào đang phát sinh nhiều nhất để đưa ra phương án điều chỉnh nhân sự hoặc quy trình kịp thời.
# Tổng Quan Sản Phẩm UniSupport

## 1. Giới Thiệu Dự Án
**UniSupport** là hệ thống Web Application đóng vai trò làm đầu mối tập trung để quản lý và giải quyết toàn bộ các yêu cầu hỗ trợ của sinh viên tại **Aurora University**. Nền tảng được thiết kế nhằm thay thế các phương thức làm việc thủ công, phân tán trước đây, hướng tới việc chuẩn hóa toàn bộ quy trình tiếp nhận, điều phối và phản hồi yêu cầu.

---

## 2. Giải Pháp Cốt Lõi
Hệ thống UniSupport mang đến giải pháp toàn diện cho 3 nhóm đối tượng chính:

* **Dành cho Sinh viên:** Cung cấp cổng thông tin tập trung để sinh viên chủ động gửi yêu cầu, đính kèm minh chứng, theo dõi tiến độ xử lý theo thời gian thực qua mã Ticket duy nhất, nhận kết quả và đánh giá mức độ hài lòng.
* **Dành cho Nhân viên các Phòng ban:** Cung cấp công cụ tiếp nhận, phân loại, đánh giá độ ưu tiên, chuyển tiếp đúng đơn vị phụ trách và cập nhật tiến độ giải quyết trên một giao diện thống nhất.
* **Dành cho Ban quản lý:** Cung cấp Dashboard báo cáo trực quan giúp theo dõi tổng quan số lượng Ticket, khối lượng công việc từng phòng ban, thời gian xử lý trung bình và các nhóm vấn đề phát sinh phổ biến.

---

## 3. Đặc Điểm Kỹ Thuật & Vận Hành Chính
* **Nền tảng:** Web Application hỗ trợ giao diện Responsive, hoạt động mượt mà trên cả trình duyệt máy tính và thiết bị di động.
* **Quy mô phục vụ:** Thiết kế tối ưu cho quy mô khoảng **3.000 sinh viên** của nhà trường.
* **Ngôn ngữ hỗ trợ:** Giao diện hỗ trợ Tiếng Việt và Tiếng Anh ở mức cơ bản.
* **Bảo mật & Phân quyền:** Đăng nhập tài khoản cá nhân, phân quyền truy cập theo 3 vai trò (Sinh viên, Nhân viên, Quản lý), kiểm soát quyền xem file đính kèm và lưu vết nhật ký thao tác cơ bản (Audit log).
# Phạm Vi Sản Phẩm & Các Giả Định Dự Án

## 1. Tóm Tắt Phạm Vi Chức Năng
Sản phẩm UniSupport bao gồm 3 phân hệ chức năng tương ứng với 3 vai trò người dùng:

| Phân hệ | Chức năng cốt lõi |
| :--- | :--- |
| **Module 1: Sinh viên** | Đăng nhập; Tạo Ticket (chọn nhóm, mô tả, đính kèm file); Theo dõi tiến độ qua mã Ticket; Bổ sung giấy tờ; Nhận kết quả & Đánh giá mức độ hài lòng. |
| **Module 2: Nhân viên** | Đăng nhập; Tiếp nhận & Phân loại Ticket; Chuyển tiếp phòng ban; Cập nhật tiến độ; Yêu cầu bổ sung thông tin; Ghi kết quả & Đóng Ticket. |
| **Module 3: Quản lý** | Đăng nhập; Dashboard tổng quan; Báo cáo thống kê (xu hướng, thời gian xử lý, đánh giá); Quản trị tài khoản & Phân quyền vai trò. |

---

## 2. Các Giả Định Triển Khai (Assumptions)
Đội ngũ phát triển và Aurora University thống nhất các giả định nền tảng sau:

1. **Quy mô hệ thống:** Phục vụ tối đa khoảng **3.000 sinh viên**, kiến trúc hệ thống không thiết kế cho tải lớn vượt mốc này.
2. **Hình thức sản phẩm:** Hệ thống được triển khai dưới dạng **Web Application**, hỗ trợ giao diện Responsive trên Web Desktop và Mobile Browser.
3. **Đa ngôn ngữ:** Hệ thống hỗ trợ giao diện cơ bản bằng Tiếng Việt và Tiếng Anh.
4. **Hạ tầng & Tên miền:** Khách hàng (Aurora University) chịu trách nhiệm cung cấp máy chủ (Server) và Tên miền (Domain) đáp ứng tiêu chuẩn triển khai.
5. **Tiến độ phản hồi:** Thời gian triển khai 14 tuần (70 ngày làm việc) không bao gồm thời gian chờ phản hồi, phê duyệt hoặc nghiệm thu chậm trễ từ phía Client.
6. **Bảo mật & Tích hợp:** Không yêu cầu tích hợp hệ thống bên thứ ba ngoài danh mục thống nhất và không yêu cầu chứng nhận bảo mật chuyên sâu.
# Quy Tắc Nghiệp Vụ Bắt Buộc (Business Rules Specification)

## 1. Tổng Quan
Tài liệu này tập hợp toàn bộ các Quy tắc Nghiệp vụ Cốt lõi (Business Rules - BR) bắt buộc phải được cài đặt chặt chẽ ở cả $2\text{ lớp}$: Client-side Validation (Giao diện người dùng) và Server-side Validation & Database Constraints (Logic dịch vụ Backend). Các vi phạm quy tắc phải lập tức kích hoạt mã lỗi chuẩn hệ thống.

## 2. Chi Tiết Danh Mục Quy Tắc Nghiệp Vụ

### GROUP 1: Quy Tắc Khởi Tạo Ticket & Chống Trùng Lặp

| Mã Quy Tắc | Tên Quy Tắc | Mô Tả Nghiệp Vụ & Rules Kỹ Thuật | Handling Specs & Error Code |
| :--- | :--- | :--- | :--- |
| **BR-01** | Bắt buộc Thông tin Đầu vào | Khi Sinh viên tạo Ticket, các trường `category_id` (Dropdown), `title` ($10 - 150\text{ ký tự}$), và `description` ($20 - 2000\text{ ký tự}$) là BẮT BUỘC. | Nếu thiếu bất kỳ trường nào, Client chặn submit. Server trả mã lỗi `400 INVALID_INPUT`. |
| **BR-02** | Tính Hợp Lệ Nội Dung Chuỗi | Mọi trường văn bản đầu vào (`title`, `description`, `resolution_note`, `request_note`, `rating_comment`) bắt buộc phải qua hàm `trim()`. Chuỗi chỉ chứa ký tự trắng (space, tab, newline) bị coi là không hợp lệ. | Báo lỗi validation: "Nội dung không được để trống hoặc chỉ chứa khoảng trắng." (`400 INVALID_INPUT`). |
| **BR-03** | Chống Trùng Lặp Thao Tác (Idempotency) | Một hành động gửi của Sinh viên chỉ được tạo ra đúng 01 Ticket duy nhất, bất kể sinh viên click đúp, retry do mất mạng hoặc bị nghẽn request. | **Client:** Vô hiệu hóa Form & Nút Gửi ngay khi bấm.<br>**Server:** Sử dụng Header `Client-Request-ID` (UUID v4) + Redis Key lock trong $30\text{ giây}$. Trả về `409 DUPLICATE_REQUEST` nếu trùng key. |
| **BR-04** | Ràng Buộc Quyền Sở Hữu (Ownership) | Ticket khi khởi tạo phải tự động liên kết cứng với `student_id` lấy từ JWT Token của phiên đăng nhập hiện tại. Tránh triệt để việc giả mạo ID người gửi trên Payload. | Backend bỏ qua mọi trường `student_id` gửi lên từ body payload; bắt buộc đọc từ `request.user.id` thu được sau khi verify Token. |

### GROUP 2: Quy Tắc Xử Lý, Chuyển Tiếp & Đóng Ticket

| Mã Quy Tắc | Tên Quy Tắc | Mô Tả Nghiệp Vụ & Rules Kỹ Thuật | Handling Specs & Error Code |
| :--- | :--- | :--- | :--- |
| **BR-05** | Chống Tranh Chấp Tiếp Nhận (Claim Lock) | Hai Nhân viên cùng phòng ban bấm Tiếp nhận (Claim) 1 Ticket `NEW` tại 1 thời điểm: Chỉ người có request đến trước được tiếp nhận. | Server sử dụng Atomic Database Lock (`status IN ('NEW', 'TRANSFERRED')`). Người đến sau nhận lỗi `409 TICKET_ALREADY_CLAIMED`. |
| **BR-06** | Quy Tắc Chuyển Phòng Ban (Transfer) | - Nhân viên chỉ được chuyển phòng ban khi Ticket chưa ở trạng thái `CLOSED` / `REJECTED`.<br>- Bắt buộc nhập lý do chuyển tiếp (`transfer_reason`) từ $10 - 500\text{ ký tự}$.<br>- Khi chuyển, `assignee_id` tự động đặt về `NULL`.<br>- Bắt buộc ghi 01 record vào Audit Log (`ticket_histories`). | Nếu thiếu lý do, trả mã lỗi `400 MISSING_TRANSFER_REASON`. |
| **BR-07** | Ràng Buộc Bổ Sung Hồ Sơ | Khi Ticket ở `NEED_MORE_INFO`, Sinh viên chỉ được gửi lời nhắn giải trình và upload file đính kèm bổ sung. KHÔNG ĐƯỢC phép chỉnh sửa `title`, `description` hay `category_id` ban đầu. | Trạng thái Ticket tự động chuyển từ `NEED_MORE_INFO` $\rightarrow$ `IN_PROGRESS` ngay khi Sinh viên submit bổ sung thành công. |
| **BR-08** | Bắt Buộc Kết Quả Khi Đóng Ticket | Nhân viên BẮT BUỘC phải nhập `resolution_note` (Độ dài từ $20 - 2000\text{ ký tự}$) trước khi bấm Hoàn tất xử lý (`RESOLVED` / `CLOSED`). | Nếu để trống hoặc chỉ nhập khoảng trắng, Server từ chối đổi trạng thái và trả lỗi `400 INVALID_INPUT`. |
| **BR-09** | Quy Tắc Auto-Close Hệ Thống | Ticket ở trạng thái `RESOLVED` quá $3\text{ ngày làm việc}$ ($72\text{ giờ làm việc}$, loại trừ T7, CN, Lễ) mà Sinh viên không phản hồi, Cronjob sẽ tự động chuyển `status = CLOSED`. | Cronjob hệ thống chạy định kỳ $23:00$ mỗi ngày. Ghi log `action = SYSTEM_AUTO_CLOSE`. |

### GROUP 3: Quy Tắc Cảnh Báo SLA (Service Level Agreement)

| Mã Quy Tắc | Tên Quy Tắc | Mô Tả Nghiệp Vụ & Rules Kỹ Thuật | Handling Specs & Error Code |
| :--- | :--- | :--- | :--- |
| **BR-10** | Khung Thời Gian Cam Kết SLA | Mặc định thời hạn xử lý Ticket (`sla_target_at`) là $24\text{ giờ làm việc}$ kể từ khi tạo. Khung giờ làm việc tính từ $08:00 - 17:00$ (từ Thứ 2 đến Thứ 6), không tính cuối tuần và ngày lễ. | Sinh tự động: `sla_target_at = created_at + 24 working hours`. |
| **BR-11** | Trạng Thái Cảnh Báo Quá Hạn SLA | Cảnh báo trạng thái SLA dựa trên thời gian còn lại đến mốc `sla_target_at`:<br>- `ON_TRACK`: Thời gian còn lại $> 25\%$ SLA ($> 6\text{ giờ làm việc}$).<br>- `WARNING`: Thời gian còn lại $\le 25\%$ SLA ($\le 6\text{ giờ làm việc}$).<br>- `BREACHED`: Đã quá hạn nhưng Ticket chưa `RESOLVED`/`CLOSED`. | Dashboard Quản lý tự động nhóm và hiển thị cảnh báo đỏ với các Ticket ở trạng thái `BREACHED`. |

### GROUP 4: Quy Tắc Phân Quyền File, Tài Khoản & Đánh Giá CSAT

| Mã Quy Tắc | Tên Quy Tắc | Mô Tả Nghiệp Vụ & Rules Kỹ Thuật | Handling Specs & Error Code |
| :--- | :--- | :--- | :--- |
| **BR-12** | Phân Quyền Xem File Đính Kèm | File đính kèm lưu ở thư mục Private cách ly hoàn toàn với Web Root. Mọi API xem/tải file (`/api/v1/attachments/{file_id}`) bắt buộc verify Bearer Token và Context Ticket. | Chỉ trả file stream khi người dùng là: Sinh viên sở hữu Ticket, Nhân viên thuộc phòng ban thụ lý, hoặc Admin/Manager. Người khác trả về `403 FORBIDDEN_ACCESS`. |
| **BR-13** | Giới Hạn File Upload | - Số lượng: Tối đa $5\text{ file/Ticket}$ (đối với SV) và $3\text{ file/Ticket}$ (đối với kết quả xử lý của Staff).<br>- Dung lượng: Tối đa $5\text{MB}$ ($5.242.880\text{ Bytes}$) / file.<br>- Định dạng: MIME Type thực tế (Magic Bytes) phải đúng `.pdf`, `.png`, `.jpg`, `.jpeg`. | Vi phạm dung lượng: Trả mã lỗi `400 FILE_EXCEEDS_LIMIT`. Vi phạm định dạng/magic bytes: Trả mã lỗi `400 FILE_TYPE_NOT_ALLOWED`. |
| **BR-14** | Đánh Giá Chất Lượng Dịch Vụ (CSAT) | Sinh viên chỉ được gửi Đánh giá hài lòng (`rating_score` từ $1 - 5\text{ sao}$) đúng $01\text{ lần duy nhất}$ cho mỗi Ticket. Khi đã đánh giá, Component Đánh giá chuyển sang Read-only. | Nếu gửi lặp (Race condition): Backend kiểm tra `rating_score IS NOT NULL` và trả lỗi `409 ALREADY_RATED`. |
| **BR-15** | Vô Hiệu Hóa Phiên Khi Khóa Tài Khoản | Khi Admin chuyển trạng thái tài khoản User sang `INACTIVE`, hệ thống phải ngay lập tức vô hiệu hóa (Revoke) toàn bộ Active Sessions và Refresh Tokens của user đó trên Redis/Database. | User bị đẩy văng ra màn hình Login ngay ở thao tác API tiếp theo với mã lỗi `403 ACCOUNT_DISABLED`. |

## 3. Ma Trận Xử Lý Lỗi Tập Trung (Business Rules Error Matrix)

```plaintext
[Client Form Input] ────> Validation Layer (BR-01, BR-02, BR-13) ──── Lỗi ───> HTTP 400 INVALID_INPUT
                                  │
                                Hợp lệ
                                  ▼
[API Gateway] ──────────> Security & Token Check (BR-04, BR-12, BR-15) ─ Lỗi ───> HTTP 401 / 403 FORBIDDEN
                                  │
                                Hợp lệ
                                  ▼
[Service Engine] ───────> Business Rules & Concurrency Check (BR-03, BR-05, BR-14) ─ Lỗi ───> HTTP 409 CONFLICT
                                  │
                                Hợp lệ
                                  ▼
[Database Commit] ──────> State Machine & Audit Log (BR-06, BR-08, BR-09)
```
# Tổng Quan Nghiệp Vụ Hỗ Trợ Sinh Viên (Domain Overview)

## 1. Giới Thiệu Nghiệp Vụ
Tại **Aurora University**, công tác hỗ trợ sinh viên bao gồm việc giải đáp thắc mắc, xử lý thủ tục hành chính, hỗ trợ kỹ thuật và giải quyết các đề xuất liên quan đến quá trình học tập. Hệ thống **UniSupport** được xây dựng nhằm chuẩn hóa toàn bộ nghiệp vụ này thành quy trình số hóa khép kín, minh bạch và có thể đo lường.

---

## 2. Các Nhóm Dịch Vụ Hỗ Trợ Chính
Hệ thống quản lý yêu cầu dựa trên các phân loại nghiệp vụ chính bao gồm:
* **Hành chính - Đào tạo:** Xác nhận sinh viên, bảng điểm, đăng ký môn học, hoãn thi, nghỉ học tạm thời.
* **Tài chính - Học phí:** Thắc mắc học phí, gia hạn đóng học phí, xét miễn giảm/học bổng.
* **Công tác sinh viên:** Thẻ sinh viên, bảo hiểm y tế, điểm rèn luyện, ký túc xá.
* **Hạ tầng & Kỹ thuật:** Tài khoản LMS/Email, sự cố kết nối Wi-Fi, mượn thiết bị học tập.

---

## 3. Nguyên Tắc Vận Hành Nghiệp Vụ
1. **Tập trung hóa:** Sinh viên chỉ tạo yêu cầu qua một đầu mối duy nhất trên UniSupport (thay vì gửi email hay nhắn tin rời rạc).
2. **Minh bạch hóa:** Mọi Ticket đều có mã định danh duy nhất, trạng thái cập nhật rõ ràng và công khai người/phòng ban đang thụ lý.
3. **Đúng thẩm quyền:** Yêu cầu phải được chuyển giao đúng phòng ban chuyên trách; nếu tiếp nhận sai, nhân viên có quyền chuyển tiếp sang đúng đơn vị.
4. **Tránh trùng lặp:** Hệ thống chủ động ngăn chặn việc gửi trùng nhiều lần cho cùng một vấn đề do thao tác nhấp đúp hay sự cố mạng.
# 1. Danh Sách Mã Trạng Thái Trí Tuệ Định Nghĩa (State Definitions)

| Mã trạng thái (`status`) | Tên hiển thị (VI) | Mô tả chi tiết & Ý nghĩa nghiệp vụ |
| :--- | :--- | :--- |
| `NEW` | Mới tạo | Ticket vừa tạo thành công, đang nằm trong Queue chung của Phòng ban, chưa có cá nhân Nhân viên tiếp nhận. |
| `IN_PROGRESS` | Đang xử lý | Ticket đã có Nhân viên phụ trách (`assignee_id != NULL`) và đang trong tiến trình giải quyết nghiệp vụ. |
| `NEED_MORE_INFO` | Cần bổ sung | Nhân viên tạm dừng xử lý để chờ Sinh viên cung cấp thêm thông tin hoặc giấy tờ còn thiếu. |
| `TRANSFERRED` | Đã chuyển giao | Ticket đã được điều chuyển sang Phòng ban khác. Đang nằm trong Queue chờ của Phòng ban mới (`assignee_id = NULL`). |
| `REJECTED` | Từ chối xử lý | Ticket bị từ chối do nội dung vi phạm, spam hoặc không đúng quy định nhà trường. Đây là trạng thái kết thúc (Terminal State). |
| `RESOLVED` | Đã giải quyết | Nhân viên đã xử lý xong nghiệp vụ và gửi kết quả cho Sinh viên. Chờ Sinh viên nghiệm thu/đánh giá. |
| `CLOSED` | Đã đóng hoàn tất | Ticket đã kết thúc toàn bộ vòng đời (Đã được đánh giá hoặc tự động đóng sau 3 ngày). Không thể chỉnh sửa hay thay đổi trạng thái. |

# 2. Ma Trận Chuyển Đổi Trạng Thái (State Transition Matrix)

Các đường chuyển trạng thái **KHÔNG NẰM TRONG BẢNG DƯỚI ĐÂY** đều bị hệ thống cấm (Chữa lỗi trực tiếp ở API Validation level - trả về mã lỗi `400 INVALID_TICKET_STATE`).

| Trạng thái hiện tại | Trạng thái chuyển tới | Vai trò thực hiện | Điều kiện kích hoạt & Validation Rules | Hành động phụ kèm theo (Side Effects) |
| :--- | :--- | :--- | :--- | :--- |
| `NEW` | `IN_PROGRESS` | STAFF, MANAGER | Nhân viên bấm Tiếp nhận xử lý. Áp dụng Optimistic Locking chống tranh chấp. | - Gán `assignee_id = current_user_id`<br>- Cập nhật `priority` (nếu có chỉnh sửa). |
| `NEW` | `TRANSFERRED` | STAFF, MANAGER | Bắt buộc nhập lý do chuyển tiếp (10 - 500 ký tự). Chọn phòng ban mới khác phòng ban hiện tại. | - Đổi `department_id = target_department_id`<br>- Gán `assignee_id = NULL`<br>- Ghi vết Audit Log. |
| `NEW` | `REJECTED` | STAFF, MANAGER | Bắt buộc nhập lý do từ chối (10 - 500 ký tự). | - Gửi thông báo từ chối kèm lý do cho Sinh viên.<br>- Cập nhật `closed_at = CURRENT_TIMESTAMP`. |
| `IN_PROGRESS` | `NEED_MORE_INFO` | STAFF (Assignee) | Bắt buộc nhập nội dung yêu cầu bổ sung (10 - 1000 ký tự). | - Lưu tin nhắn vào Conversation log.<br>- Gửi Notification cho Sinh viên. |
| `IN_PROGRESS` | `TRANSFERRED` | STAFF (Assignee) | Bắt buộc nhập lý do chuyển tiếp (10 - 500 ký tự). | - Đổi `department_id = target_department_id`<br>- Gán `assignee_id = NULL`<br>- Ghi vết Audit Log. |
| `IN_PROGRESS` | `RESOLVED` | STAFF (Assignee) | Bắt buộc nhập `resolution_note` (20 - 2000 ký tự). | - Cập nhật `resolved_at = CURRENT_TIMESTAMP`<br>- Gửi thông báo kết quả cho Sinh viên. |
| `NEED_MORE_INFO` | `IN_PROGRESS` | STUDENT (Owner) | Sinh viên gửi đính kèm/lời nhắn bổ sung thành công. | - Lưu file/tin nhắn vào Conversation log.<br>- Phát thông báo cho Nhân viên phụ trách. |
| `TRANSFERRED` | `IN_PROGRESS` | STAFF (PB mới) | Nhân viên phòng ban mới bấm Tiếp nhận xử lý. | - Gán `assignee_id = current_user_id`. |
| `TRANSFERRED` | `REJECTED` | STAFF (PB mới) | Nhân viên phòng ban mới kiểm tra và từ chối. Bắt buộc nhập lý do từ chối. | - Cập nhật `closed_at = CURRENT_TIMESTAMP`. |
| `RESOLVED` | `CLOSED` | STUDENT (Owner) | Sinh viên gửi Đánh giá hài lòng (Rating 1-5 sao). | - Lưu `rating_score`, `rating_comment`, `rated_at`.<br>- Cập nhật `closed_at = CURRENT_TIMESTAMP`. |
| `RESOLVED` | `CLOSED` | SYSTEM (Cronjob) | Ticket ở trạng thái `RESOLVED` quá 03 ngày làm việc không có tương tác mới. | - Cập nhật `closed_at = CURRENT_TIMESTAMP`. |

# 3. Quy Tắc Bảo Mật & Phân Quyền Theo Trạng Thái (State-based Security Matrix)

| Trạng thái Ticket | Quyền của Sinh viên (Owner) | Quyền của Nhân viên (Assignee) | Quyền của Quản lý / Admin |
| :--- | :--- | :--- | :--- |
| `NEW` | Xem chi tiết. KHÔNG được chỉnh sửa nội dung. | Xem chi tiết, Claim, Transfer, Reject. | Xem chi tiết, Phân công trực tiếp cho Staff. |
| `IN_PROGRESS` | Xem tiến độ, xem tên Nhân viên phụ trách. | Xem chi tiết, Yêu cầu bổ sung, Transfer, Complete. | Xem chi tiết, Thu hồi Ticket cấp lại cho Staff khác. |
| `NEED_MORE_INFO` | Xem yêu cầu bổ sung, Được upload file / nhắn tin bổ sung. | Xem tiến độ, Chờ sinh viên phản hồi. | Xem chi tiết. |
| `TRANSFERRED` | Xem lịch sử chuyển phòng ban. | **Staff cũ:** Read-only.<br>**Staff phòng ban mới:** Xem & Claim. | Xem chi tiết. |
| `REJECTED` | Xem lý do bị từ chối (Read-only). | Read-only. | Read-only. |
| `RESOLVED` | Xem kết quả giải quyết, Được thực hiện Đánh giá (Rating). | Read-only. | Read-only. |
| `CLOSED` | Xem lại toàn bộ lịch sử & đánh giá đã gửi (Read-only). | Read-only. | Read-only. |
# Thuật Ngữ Nghiệp Vụ & Chỉ Số Quản Trị (Terminology & Metrics Specification)

## 1. Tổng Quan
Tài liệu này định nghĩa chính xác danh mục thuật ngữ nghiệp vụ, mã trạng thái kỹ thuật và các chỉ số quản trị cốt lõi (KPIs/Metrics) được áp dụng đồng bộ trong hệ thống UniSupport. Việc chuẩn hóa này đảm bảo tính nhất quán giữa tài liệu PRD, thiết kế CSDL, định nghĩa API Response và giao diện hiển thị Dashboard.

## 2. Bảng Danh Mục Thuật Ngữ Cốt Lõi (Core Terminology)

| Thuật ngữ | Mã Kỹ Thuật / Field Name | Mô Tả & Giải Thích Kỹ Thuật Chi Tiết |
| :--- | :--- | :--- |
| **Ticket (Phiếu hỗ trợ)** | `ticket` | Đơn vị dữ liệu trung tâm (Core Entity) đại diện cho một giao dịch hỗ trợ do Sinh viên khởi tạo, chứa toàn bộ lịch sử biến động, file đính kèm, phản hồi và đánh giá. |
| **Ticket ID (Mã Ticket)** | `ticket_id` | Mã định danh duy nhất hiển thị dạng `TK-YYYYMMDD-XXXX` (VD: `TK-20261009-0001`). Sinh tự động, bất biến (Immutable), độ dài cố định $15\text{ ký tự}$. |
| **Idempotency Key** | `client_request_id` | Mã UUID v4 ngẫu nhiên do Client sinh ra khi mở Form tạo Ticket, gửi kèm trong Request Header để Server chống ghi nhận trùng dữ liệu do click đúp/mạng gián đoạn. |
| **Category (Nhóm vấn đề)** | `category_id` | Phân loại nghiệp vụ của yêu cầu (VD: Học phí, Đăng ký môn học, Giấy xác nhận). Mỗi Category liên kết mặc định với 01 Phòng ban (`department_id`). |
| **Priority (Độ ưu tiên)** | `priority` | Mức độ khẩn cấp xử lý Ticket. Enum gồm 4 giá trị: `LOW` (Thấp), `MEDIUM` (Trung bình - Mặc định), `HIGH` (Cao), `URGENT` (Khẩn cấp). |
| **Assignee (Người phụ trách)** | `assignee_id` | Mã định danh (`user_id`) của Nhân viên phòng ban trực tiếp chịu trách nhiệm thụ lý và giải quyết Ticket. Trả về `NULL` khi Ticket ở Queue chờ chung. |
| **Department (Phòng ban)** | `department_id` | Đơn vị nghiệp vụ thụ lý Ticket (VD: Phòng Đào tạo, Phòng Công tác Sinh viên, Phòng Tài chính). |
| **Attachment (File đính kèm)** | `attachments` | Tài liệu/hình ảnh minh chứng do Sinh viên hoặc Nhân viên tải lên. Ràng buộc: Định dạng `.pdf`, `.png`, `.jpg`, `.jpeg`; dung lượng $\le 5\text{MB/file}$; lưu ở thư mục Private. |
| **Conversation Log** | `ticket_conversations` | Bảng nhật ký ghi lại toàn bộ các câu trao đổi, lời nhắn yêu cầu bổ sung hồ sơ và phản hồi giữa Sinh viên và Nhân viên theo thứ tự thời gian (`created_at ASC`). |
| **Audit Trail (Nhật ký tra soát)** | `audit_logs` | Bảng nhật ký Append-Only ghi nhận vĩnh viễn các thao tác quản trị nhạy cảm (Tạo/khóa tài khoản, Phân quyền, Chuyển phòng ban) phục vụ kiểm toán an toàn thông tin. |
| **UAT (User Acceptance Testing)** | `uat` | Kiểm thử chấp nhận người dùng do Ban quản lý và Cán bộ Aurora University thực hiện trước khi nghiệm thu chính thức đưa hệ thống vào vận hành. |

## 3. Danh Mục Chỉ Số Quản Trị & SLA (Management Metrics & SLA Specifications)
Các chỉ số dưới đây được tính toán và hiển thị trực tiếp trên Phân hệ Quản lý (M03 - Management Dashboard):

| Tên Chỉ Số / Thuật Ngữ | Mã Chỉ Số | Công Thức Tính Toán & Specs Kỹ Thuật | Ý Nghĩa Quản Trị & Cảnh Báo |
| :--- | :--- | :--- | :--- |
| **SLA Target (Hạn chót SLA)** | `sla_target_at` | `created_at` + $24\text{ giờ làm việc}$ (Chỉ tính từ $08:00 - 17:00$ các ngày Thứ 2 đến Thứ 6, loại trừ T7, CN và Ngày lễ). | Mốc thời gian cam kết nhà trường phải hoàn tất giải quyết Ticket cho sinh viên. |
| **SLA On-Track (Trong hạn)** | `ON_TRACK` | Thời gian còn lại đến `sla_target_at` $> 25\%$ tổng quỹ thời gian SLA ($> 6\text{ giờ làm việc}$). | Ticket đang trong tiến độ xử lý an toàn. Hiển thị Badge màu xanh lá trên Dashboard. |
| **SLA Warning (Sắp quá hạn)** | `WARNING` | Thời gian còn lại đến `sla_target_at` $\le 25\%$ tổng quỹ thời gian SLA ($\le 6\text{ giờ làm việc}$). | Cảnh báo Nhân viên cần ưu tiên xử lý ngay. Hiển thị Badge màu vàng trên Dashboard. |
| **SLA Breached / Overdue** | `BREACHED` | Thời gian xử lý thực tế vượt quá `sla_target_at` nhưng Ticket chưa ở trạng thái `RESOLVED`/`CLOSED`. | Vi phạm cam kết dịch vụ. Dashboard Quản lý gom nhóm đẩy lên đầu trang kèm Badge màu đỏ. |
| **Avg Resolution Time** | `avg_resolution_time` | $\frac{\sum (\text{resolved\_at} - \text{created\_at})}{\text{Tổng số Ticket RESOLVED trong kỳ}}$ (Đơn vị: Giờ). | Đo lường năng suất và tốc độ giải quyết công việc trung bình của từng Phòng ban / Nhân viên. |
| **CSAT Score (Điểm Hài lòng)** | `csat_score` | $\frac{\text{Tổng số sao thu được}}{\text{Tổng số lượt đánh giá} \times 5} \times 100\%$ (Đơn vị: $\%$) | Chỉ số đánh giá chất lượng phục vụ của nhà trường dựa trên phản hồi của sinh viên ($1-5$ sao). |
| **Workload Distribution** | `workload_count` | `COUNT(ticket_id) WHERE assignee_id = {staff_id} AND status = 'IN_PROGRESS'` | Đo lường số lượng công việc thực tế đang gán cho từng Nhân viên để Quản lý điều phối cân bằng. |
| **Aggregation Cache** | `aggregation_cache` | Dữ liệu chỉ số Dashboard được tính toán trước và lưu tạm trên Redis (TTL: $30 - 60\text{ giây}$). | Tối ưu hiệu năng Query, tránh quá tải CSDL khi Quản lý truy cập Dashboard liên tục. |

## 4. Ma Trận Áp Dụng Thuật Ngữ Trong CSDL & APIs (Data Mapping)

| Thuật ngữ Nghiệp vụ | Bảng CSDL (Database Table) | Tên Trường CSDL (Column Name) | Enum Values / Data Type |
| :--- | :--- | :--- | :--- |
| **Mã Ticket** | `tickets` | `ticket_id` | `VARCHAR(15) PRIMARY KEY` |
| **Trạng thái Ticket** | `tickets` | `status` | `ENUM('NEW', 'IN_PROGRESS', 'NEED_MORE_INFO', 'TRANSFERRED', 'RESOLVED', 'CLOSED', 'REJECTED')` |
| **Độ ưu tiên** | `tickets` | `priority` | `ENUM('LOW', 'MEDIUM', 'HIGH', 'URGENT')` |
| **Trạng thái SLA** | `tickets` | `sla_status` | `ENUM('ON_TRACK', 'WARNING', 'BREACHED')` |
| **Điểm Đánh giá CSAT** | `tickets` | `rating_score` | `INTEGER` (Giá trị từ $1$ đến $5$) |
| **Vai trò Người dùng** | `users` | `role` | `ENUM('STUDENT', 'STAFF', 'MANAGER', 'ADMIN')` |
| **Trạng thái Tài khoản** | `users` | `status` | `ENUM('ACTIVE', 'INACTIVE')` |
# 1. Tổng Quan Vòng Đời Phiếu Hỗ Trợ (Ticket Lifecycle)

Vòng đời của một Ticket trong UniSupport phản ánh chính xác quy trình nghiệp vụ từng bước giữa Sinh viên (Student), Nhân viên (Staff) và Quản lý (Manager/Admin). Trạng thái Ticket được quản lý dưới dạng Máy trạng thái hữu hạn (Finite State Machine - FSM) nhằm đảm bảo dữ liệu không bị chuyển trạng thái sai quy tắc.

Plaintext

       [ Khởi Tạo ] (Student)
            │
            ▼
        (  NEW  ) ───────────────┬───────────────┐
            │                    │               │
      Claim │              Reject│       Transfer│
            ▼                    ▼               ▼
    ( IN_PROGRESS )       ( REJECTED )   ( TRANSFERRED )
       │        ▲                │               │
Request│        │Upload          └───────┬───────┘
       ▼        │                        │ Claim
(NEED_MORE_INFO)                         ▼
       │                          ( IN_PROGRESS )
       │ Resolve                         │
       └─────────────────────────────────┤ Resolve
                                         ▼
                                   ( RESOLVED )
                                         │
                                   Rate  │ (or Auto-close)
                                         ▼
                                   (  CLOSED  )

# 2. Chi Tiết Các Giai Đoạn Trong Vòng Đời

## Giai đoạn 1: Khởi Tạo (Created)
- **Tác nhân:** Sinh viên.
- **Thao tác:** Nhập tiêu đề, mô tả, chọn nhóm vấn đề (`category_id`), đính kèm file (nếu có).
- **Trạng thái hệ thống:** Khởi tạo ở trạng thái `NEW`.
- **Hành vi hệ thống:**
  - Kiểm tra `client_request_id` (Idempotency Key) để tránh trùng lặp.
  - Tự động gán `department_id` mặc định dựa trên `category_id`.
  - Tự động tính toán mốc thời hạn giải quyết `sla_target_at` (= Thời điểm tạo + 24 giờ làm việc).
  - Khởi tạo `sla_status` = `ON_TRACK`.

## Giai đoạn 2: Tiếp Nhận & Phân Loại (Claim, Triage & Transfer)
- **Tác nhân:** Nhân viên phòng ban (`department_id`).
- **Thao tác:**
  - **Trường hợp 1 (Tiếp nhận):** Nhân viên bấm Tiếp nhận xử lý, điều chỉnh priority (`LOW`, `MEDIUM`, `HIGH`, `URGENT`) nếu cần. Trạng thái chuyển sang `IN_PROGRESS`, gán `assignee_id` = `staff_id`.
  - **Trường hợp 2 (Từ chối):** Yêu cầu sai quy định, vi phạm chính sách hoặc spam. Nhân viên nhập lý do từ chối (bắt buộc) và chuyển trạng thái sang `REJECTED`.
  - **Trường hợp 3 (Chuyển phòng ban):** Yêu cầu không thuộc thẩm quyền phòng ban hiện tại. Nhân viên chọn phòng ban mới, nhập lý do chuyển tiếp (bắt buộc, min 10 ký tự). Trạng thái chuyển sang `TRANSFERRED`, gán `assignee_id` = `NULL`.

## Giai đoạn 3: Xử Lý & Bổ Sung Hồ Sơ (Processing & Supplementation)
- **Tác nhân:** Nhân viên phụ trách & Sinh viên.
- **Thao tác:**
  - **Xử lý bình thường:** Nhân viên thực hiện các nghiệp vụ nội bộ để giải quyết yêu cầu. Ticket giữ nguyên `IN_PROGRESS`.
  - **Yêu cầu bổ sung (Staff):** Thiếu hồ sơ/giấy tờ. Nhân viên nhập tin nhắn yêu cầu bổ sung. Trạng thái đổi sang `NEED_MORE_INFO`.
  - **Gửi bổ sung (Student):** Sinh viên tải lên các file/mô tả còn thiếu. Ngay khi bấm Gửi bổ sung, trạng thái tự động chuyển ngược lại về `IN_PROGRESS` và phát thông báo cho Nhân viên.

## Giai đoạn 4: Giải Quyết & Đóng Ticket (Resolution & Closure)
- **Tác nhân:** Nhân viên phụ trách & Hệ thống (Auto-task).
- **Thao tác:**
  - **Nhân viên xử lý xong:** Nhập `resolution_note` (min 20 ký tự), đính kèm file kết quả (nếu có) và bấm Hoàn tất xử lý.
  - Trạng thái Ticket chuyển sang `RESOLVED`, ghi nhận `resolved_at` = `CURRENT_TIMESTAMP`.
  - **Đóng Ticket (Closure):**
    - Sinh viên gửi đánh giá hài lòng -> Ticket tự động chuyển sang `CLOSED`.
    - Sau 03 ngày làm việc kể từ khi ở `RESOLVED`, nếu sinh viên không có khiếu nại hoặc không đánh giá, Job tự động của Server (Cron job) sẽ chuyển trạng thái Ticket sang `CLOSED` và lưu `closed_at`.

## Giai đoạn 5: Đánh Giá Chất Lượng Phục Vụ (Feedback & CSAT)
- **Tác nhân:** Sinh viên.
- **Thao tác:** Mở Ticket ở trạng thái `RESOLVED` hoặc `CLOSED` để chọn số sao (1–5) và nhập nhận xét.
- **Ràng buộc:**
  - Chỉ cho phép đánh giá 01 lần duy nhất.
  - Khi đã đánh giá, giao diện đánh giá chuyển sang dạng Read-only.
# Mô Hình Dữ Liệu Ticket (Ticket Model)

## 1. Cấu Trúc Tổng Quan Của Ticket
Ticket là đối tượng dữ liệu trung tâm (Core Domain Entity) của hệ thống UniSupport. Mỗi Ticket phản ánh toàn bộ vòng đời tương tác giữa Sinh viên và Các phòng ban nghiệp vụ, bao gồm: Thông tin khởi tạo, Phân loại điều phối, File đính kèm, Lịch sử trao đổi/Bổ sung, Cảnh báo SLA, Kết quả giải quyết và Đánh giá chất lượng dịch vụ (CSAT).

## 2. Chi Tiết Danh Mục Trường Dữ Liệu (Data Dictionary)

| Nhóm thông tin | Tên trường (Database / API) | Kiểu dữ liệu | Bắt buộc | Ràng buộc Validation & Specs kỹ thuật |
| :--- | :--- | :--- | :--- | :--- |
| **Định danh** | ticket_id | String | Có | Primary Key. Mã hiển thị chuẩn TK-YYYYMMDD-XXXX (VD: TK-20261009-0001). Sinh tự động phía Server. Read-only. |
| | client_request_id | UUID v4 | Có | Mã định danh Idempotency Key gửi từ Client để chống trùng lặp dữ liệu khi mạng lag hoặc bấm gửi nhiều lần. |
| **Sinh viên gửi** | student_id | String / FK | Có | Foreign Key liên kết bảng Users. Lấy tự động từ Session Token của Sinh viên đang đăng nhập. Không cho phép giả mạo. |
| | student_name | String | Có | Snapshot họ tên sinh viên tại thời điểm tạo Ticket (Độ dài 2–100 ký tự). Read-only. |
| | student_email | String | Có | Snapshot Email công vụ của sinh viên @aurora.edu.vn. |
| **Nội dung** | category_id | String / FK | Có | Foreign Key liên kết bảng Categories. Lấy từ Dropdown danh mục khả dụng. |
| | title | String | Có | Tiêu đề Ticket. Độ dài: 10 – 150 ký tự. Tự động trim(). Không chấp nhận chuỗi chỉ chứa khoảng trắng. |
| | description | Text | Có | Nội dung mô tả chi tiết. Độ dài: 20 – 2.000 ký tự. Tự động trim(). Không chấp nhận chuỗi chỉ chứa khoảng trắng. |
| **Đính kèm** | attachments | JSONB / Array | Không | Danh sách đối tượng File đính kèm do Sinh viên tải lên lúc tạo Ticket. Tối đa 5 file/Ticket. |
| **Điều phối** | department_id | String / FK | Có | Foreign Key liên kết bảng Departments. Mặc định gán theo category_id, có thể cập nhật khi Chuyển phòng ban. |
| | assignee_id | String / FK | Không | Foreign Key liên kết Users (Nhân viên). Mặc định NULL khi mới tạo (NEW / TRANSFERRED). Gán ID khi Staff bấm Claim. |
| | priority | Enum | Có | Giá trị Enum: LOW, MEDIUM, HIGH, URGENT. Mặc định MEDIUM. Cán bộ có thể điều chỉnh khi Claim/Triage. |
| **Trạng thái & SLA** | status | Enum | Có | Giá trị Enum: NEW, IN_PROGRESS, NEED_MORE_INFO, TRANSFERRED, RESOLVED, CLOSED. Mặc định NEW. |
| | sla_target_at | DateTime | Có | Mốc thời gian hạn chót giải quyết theo SLA (Timestamp). Sinh tự động = created_at + 24 giờ làm việc. |
| | sla_status | Enum | Có | Giá trị Enum: ON_TRACK, WARNING, BREACHED. Sinh tự động dựa trên sla_target_at và status. |
| **Thời gian** | created_at | DateTime | Có | Timestamp thời điểm tạo Ticket. Server tự động sinh (CURRENT_TIMESTAMP). |
| | updated_at | DateTime | Có | Timestamp thời điểm có cập nhật mới nhất. Server tự động cập nhật khi record thay đổi. |
| | resolved_at | DateTime | Không | Timestamp thời điểm Nhân viên hoàn tất xử lý (status đổi sang RESOLVED). Mặc định NULL. |
| | closed_at | DateTime | Không | Timestamp thời điểm Ticket đóng hoàn toàn (status đổi sang CLOSED). Mặc định NULL. |
| **Kết quả xử lý** | resolution_note | Text | Không | Bắt buộc khi đóng/hoàn thành Ticket. Độ dài: 20 – 2.000 ký tự. Tự động trim(). |
| | resolution_attachments | JSONB / Array | Không | Danh sách đối tượng File đính kèm kết quả do Nhân viên gửi (Tối đa 3 file/Ticket). |
| **Đánh giá CSAT** | rating_score | Integer | Không | Điểm số đánh giá của sinh viên. Giá trị số nguyên từ 1 đến 5 (Mặc định NULL khi chưa đánh giá). |
| | rating_comment | Text | Không | Ý kiến nhận xét bổ sung của sinh viên khi đánh giá. Độ dài tối đa 500 ký tự. |
| | rated_at | DateTime | Không | Timestamp thời điểm sinh viên gửi đánh giá thành công. |

## 3. Cấu Trúc Chi Tiết Của File Đính Kèm (Attachment Object)
Mỗi phần tử trong danh sách attachments và resolution_attachments phải tuân thủ chính xác cấu trúc dữ liệu JSON sau:

| Tên thuộc tính | Kiểu dữ liệu | Bắt buộc | Mô tả & Ràng buộc |
| :--- | :--- | :--- | :--- |
| file_id | String | Có | Mã định danh duy nhất của file do Hệ thống Storage sinh ra (UUID v4). |
| file_name | String | Có | Tên gốc của file do người dùng upload (Ví dụ: Bang_Diem_Chuyen_Truong.pdf). Max 255 ký tự. |
| file_size | Integer | Có | Dung lượng file tính bằng Byte. Ràng buộc: file_size <= 5,242,880 (Tương đương 5MB). |
| file_type | String | Có | MIME Type thực tế kiểm tra phía Server (application/pdf, image/png, image/jpeg). |
| file_url | String | Có | Đường dẫn CDN/S3 an toàn để tải hoặc xem file. |
| uploaded_by | String / FK | Có | ID người dùng thực hiện upload file (user_id). |
| uploaded_at | DateTime | Có | Timestamp thời điểm tải file lên thành công. |

## 4. Cấu Trúc Nhật Ký Trao Đổi & Bổ Sung (Conversation & Activity Log)
Dữ liệu trao đổi bổ sung thông tin giữa Sinh viên và Nhân viên không lưu trực tiếp vào bảng Ticket chính mà lưu ở bảng phụ ticket_conversations (1-n) nối tới ticket_id:

| Tên trường | Kiểu dữ liệu | Bắt buộc | Mô tả & Ràng buộc Validation |
| :--- | :--- | :--- | :--- |
| conversation_id | String / PK | Có | Mã Primary Key duy nhất của bản ghi nhật ký. |
| ticket_id | String / FK | Có | Foreign Key tham chiếu đến Ticket tương ứng. |
| sender_id | String / FK | Có | Foreign Key người gửi (Sinh viên hoặc Nhân viên). |
| sender_role | Enum | Có | Vai trò người gửi: STUDENT, STAFF, SYSTEM. |
| message_type | Enum | Có | Loại bản ghi: PUBLIC_MESSAGE (Hiển thị cho cả SV và Staff), INTERNAL_NOTE (Chỉ hiển thị nội bộ giữa Staff/Manager). |
| message_text | Text | Có | Nội dung trao đổi hoặc yêu cầu bổ sung. Độ dài: 10 – 1.000 ký tự. |
| attachments | JSONB / Array | Không | Cấu trúc mảng File đính kèm bổ sung (Tuân thủ Attachment Object ở Mục 3). |
| created_at | DateTime | Có | Timestamp thời điểm phát sinh tin nhắn/nhật ký. |

## 5. Các Ràng Buộc Dữ Liệu Ở Cấp CSDL (Database Constraints & Indexing)
Để đảm bảo hiệu năng query và tính toàn vẹn dữ liệu, Database phải cài đặt các chỉ mục và ràng buộc sau:

1. **Unique Constraints:**
   - `UNIQUE(ticket_id)`
   - `UNIQUE(client_request_id)` (Chống ghi nhận Ticket trùng lặp).

2. **Database Indexes:**
   - `INDEX(student_id, status)`: Tối ưu query danh sách Ticket cá nhân của Sinh viên.
   - `INDEX(department_id, status, assignee_id)`: Tối ưu query Queue công việc của Nhân viên phòng ban.
   - `INDEX(sla_status, status)`: Tối ưu query Dashboard Quản lý cảnh báo quá hạn.
   - `INDEX(created_at)`: Tối ưu cho việc lọc báo cáo theo mốc thời gian.

3. **Foreign Key Integrity:**
   - Ngoại trừ các trường Audit/Snapshot (`student_name`, `student_email`), toàn bộ các trường `_id` (`student_id`, `category_id`, `department_id`, `assignee_id`) đều có ràng buộc Foreign Key cứng, từ chối hành vi xóa mờ (Soft Delete required).
# Phân Hệ Sinh Viên (M01 - Student Portal)

## I. TỔNG QUAN PHÂN HỆ

Phân hệ Sinh viên cung cấp giao diện Web Responsive (tương thích Desktop và Mobile) cho sinh viên Aurora University. Phân hệ bao gồm các nhóm chức năng chính: Xác thực tài khoản, Khởi tạo yêu cầu hỗ trợ, Quản lý & Theo dõi tiến độ Ticket, Bổ sung hồ sơ theo yêu cầu, Xem kết quả và Đánh giá chất lượng phục vụ.

### 1. Luồng sử dụng và phạm vi

Tài khoản được nhà trường cấp, với ADMIN thực hiện quản trị tài khoản theo FR-MNG-04. Sinh viên dùng tài khoản đó để đăng nhập, gửi yêu cầu, theo dõi chính yêu cầu của mình, bổ sung hồ sơ khi nhân viên yêu cầu, rồi xem kết quả và đánh giá. Đăng nhập không bao gồm sinh viên tự đăng ký tài khoản.

Thông báo trạng thái thuộc luồng theo dõi yêu cầu đã có. Các kênh thông báo giữ theo tài liệu hiện tại; phần hiển thị kết quả thuộc FR-STU-04, không coi thông báo là kết quả giải quyết.

### 2. Nhóm vấn đề dùng khi gửi yêu cầu

| Nội dung | Đặc tả nghiệp vụ theo tài liệu gốc |
| --- | --- |
| Ý nghĩa | Nhóm phân loại nội dung yêu cầu, ví dụ Học phí, Đăng ký môn học, Giấy xác nhận. Đây là ví dụ, không phải danh sách cố định hoặc danh mục mới. |
| Nguồn | Danh mục của hệ thống đã được định nghĩa tại phần Terminology; ADMIN có quyền cấu hình danh mục tại Actors & Roles. |
| Chủ sở hữu danh mục | ADMIN quản lý; sinh viên chọn một giá trị trong danh sách được cung cấp, không tạo nhóm vấn đề ngay trên biểu mẫu gửi yêu cầu. |
| Liên kết phòng ban | Mỗi nhóm vấn đề gắn mặc định với một phòng ban tiếp nhận. Chọn nhóm vấn đề là đầu vào để xác định đơn vị nhận yêu cầu. |
| Vai trò nhân viên | Có thể phân loại lại bằng danh mục thuộc phòng ban hiện tại theo FR-STF-02; chuyển sang phòng ban khác theo FR-STF-03. |
| Phụ thuộc | Danh mục và liên kết phòng ban phải có sẵn cho bước chọn nhóm vấn đề. Quyền cấu hình đã có trong tài liệu, không mở thêm mã FR hoặc màn hình mới trong lần sửa này. |

### 3. Giới hạn công sức

Giữ nguyên các dòng Resource!3:7: 124 giờ cơ sở + 4 giờ dự phòng = 128 giờ kế hoạch cho Student. FR-STU-01 dùng chung phạm vi tài khoản tại Resource!22, không cộng thêm giờ đăng nhập vào Student. Bảng đối chiếu đầy đủ nằm sau PRD Management; không phân bổ lại giờ giữa các vai trò hoặc dòng nguồn.

---

## II. CHI TIẾT CÁC CHỨC NĂNG (FUNCTIONAL REQUIREMENTS)

### [FR-STU-01] Sinh viên đăng nhập hệ thống

#### 1. Mô tả & Phạm vi
Cho phép sinh viên đăng nhập vào hệ thống UniSupport bằng tài khoản cá nhân do nhà trường cấp. Hệ thống áp dụng cơ chế xác thực tập trung và trả về token quản lý phiên làm việc.

**Luồng thao tác nghiệp vụ:**

1. Sinh viên đã được cấp tài khoản nhập tên đăng nhập/mã sinh viên và mật khẩu.
2. Đăng nhập thành công thì vào trang tổng quan cá nhân; thông tin sai hoặc tài khoản khóa thì hiển thị thông báo tương ứng tại mục 6.
3. Tạo, sửa, khóa/mở khóa tài khoản thuộc FR-MNG-04 và do ADMIN thực hiện; sinh viên không thực hiện các thao tác đó tại màn hình đăng nhập.

#### 2. Actors & Điều kiện tiên quyết
- **Actor:** Sinh viên.
- **Preconditions:** Tài khoản sinh viên đã tồn tại trên cơ sở dữ liệu hệ thống, ở trạng thái hoạt động (ACTIVE).

#### 3. Quy tắc Dữ liệu & Validation (Data Contracts)
- **Trường dữ liệu đầu vào:**
  - **Username / Student ID:** Bắt buộc, chuỗi không khoảng trắng, độ dài từ 6 - 20 ký tự, tự động `trim()` khoảng trắng hai đầu.
  - **Password:** Bắt buộc, độ dài từ 6 - 50 ký tự, phân biệt chữ hoa/chữ thường.
- **Xử lý khoảng trắng:** Tự động loại bỏ khoảng trắng thừa đầu/cuối của Username trước khi gửi request.

#### 4. Giao diện & Hành vi UI/UX (UI States)
- **Trạng thái Nút Đăng nhập:**
  - Vô hiệu hóa (Disabled) khi Username hoặc Password đang trống.
  - Khi nhấn Đăng nhập, nút chuyển sang trạng thái Loading (hiển thị spinner, disable tương tác), đồng thời vô hiệu hóa toàn bộ các input field trên form.
- **Cơ chế chống gửi lặp (Debounce/Throttle):** Áp dụng Debounce/Disable form ngay khi gửi request để chặn hoàn toàn thao tác click liên tiếp (double click, spam click).

#### 5. Luồng xử lý chi tiết (Flow of Events)
1. Sinh viên truy cập trang `/login`.
2. Hệ thống kiểm tra phiên làm việc hiện tại:
   - Nếu đã có Token hợp lệ và còn hạn -> Tự động chuyển hướng sang `/dashboard`.
   - Nếu chưa -> Hiển thị form đăng nhập.
3. Sinh viên nhập Username, Password và nhấn Đăng nhập (hoặc bấm phím Enter).
4. Client thực hiện validate dữ liệu đầu vào. Nếu hợp lệ, gửi request đăng nhập.
5. Server xác thực thông tin:
   - Trả về Token xác thực (JWT Access Token & Refresh Token) và thông tin Profile cơ bản (`student_id`, `full_name`, `email`, `role`).
6. Client lưu trữ Token an toàn (HTTP-Only Cookie hoặc Storage có bảo mật) và chuyển hướng người dùng đến trang `/dashboard`.

#### 6. Luồng ngoại lệ & Mã lỗi (Alternative & Error Flows)
- **Lỗi Validation Client:** Hiển thị message bên dưới field tương ứng: *"Vui lòng nhập tên đăng nhập / mật khẩu"*.
- **Thông tin đăng nhập sai (Mã lỗi 401 Unauthorized):** Hiển thị Alert/Toast error: *"Tài khoản hoặc mật khẩu không chính xác."*
- **Tài khoản bị khóa (403 Forbidden / INACTIVE / BLOCKED):** Hiển thị Alert error: *"Tài khoản của bạn đã bị khóa. Vui lòng liên hệ Quản trị viên."*
- **Lỗi kết nối / Server lỗi (500 / 503):** Hiển thị Toast error: *"Hệ thống đang gặp sự cố. Vui lòng thử lại sau ít phút."*

#### 7. Tiêu chí nghiệm thu (Acceptance Criteria)
- **AC-01:** Đăng nhập thành công với credential đúng -> Lưu phiên làm việc và chuyển đến `/dashboard` trong dưới 1.5 giây.
- **AC-02:** Sai credential -> Hiển thị thông báo lỗi chi tiết, không lưu session, mật khẩu bị xóa khỏi input field.
- **AC-03:** Click nút Đăng nhập nhiều lần liên tiếp -> Chỉ gửi đúng 01 request duy nhất lên Server.
- **AC-04:** Chuyển đổi thiết bị / Resize màn hình -> Giao diện form hiển thị chuẩn responsive trên Mobile (khoảng cách lề, font size, button size chuẩn touch point).

---

### [FR-STU-02] Sinh viên gửi yêu cầu hỗ trợ (Tạo Ticket)

#### 1. Mô tả & Phạm vi
Cung cấp biểu mẫu cho phép sinh viên tạo yêu cầu hỗ trợ mới gửi đến các phòng ban, kèm theo tài liệu/hình ảnh minh chứng.

**Luồng thao tác nghiệp vụ:**

1. Sinh viên mở biểu mẫu, chọn nhóm vấn đề từ danh mục đã có, nhập tiêu đề, nội dung và chọn minh chứng nếu cần.
2. Sinh viên kiểm tra các trường và tệp theo giới hạn tại mục 3 rồi gửi yêu cầu.
3. Gửi thành công thì nhận mã yêu cầu và xem trang chi tiết; yêu cầu mới được đưa đến phòng ban mặc định của nhóm vấn đề theo WF-01.
4. Nếu nhập sai hoặc tải tệp thất bại, xử lý theo mục 7. Chỉ thông báo tạo thành công khi đã có kết quả tạo yêu cầu; không bổ sung chức năng lưu bản nháp.

#### 2. Actors & Điều kiện tiên quyết
- **Actor:** Sinh viên đã đăng nhập.
- **Preconditions:** Phiên làm việc hợp lệ.

#### 3. Quy tắc Dữ liệu & Validation (Data Contracts)
- **Danh mục nhóm vấn đề (Category):** Dropdown bắt buộc chọn. Dữ liệu category lấy từ API danh mục của hệ thống.
- **Tiêu đề yêu cầu (Title):** Bắt buộc, chuỗi từ 10 đến 150 ký tự. Không chấp nhận chuỗi chỉ chứa khoảng trắng.
- **Nội dung chi tiết (Description):** Bắt buộc, chuỗi từ 20 đến 2000 ký tự. Tự động `trim()` khoảng trắng hai đầu. Không chấp nhận chuỗi chỉ chứa ký tự trắng.
- **File đính kèm (Attachments):**
  - **Số lượng:** Tối đa 5 file / 1 Ticket.
  - **Dung lượng:** Tối đa 5MB / 1 file.
  - **Định dạng cho phép:** `.pdf`, `.png`, `.jpg`, `.jpeg` (Kiểm tra cả file extension và MIME type thực tế của file).

#### 4. Giao diện & Hành vi UI/UX (UI States)
- **Form Validation Real-time:** Báo lỗi ngay dưới input field khi người dùng blur khỏi field hoặc khi bấm Gửi yêu cầu.
- **Upload File UI:** Hiển thị danh sách file đã chọn kèm tên file, dung lượng, nút Xóa file. Hiển thị thanh progress bar trong quá trình tải file lên.
- **Nút Gửi yêu cầu:** Đổi sang trạng thái Loading ngay khi bấm. Disable form để tránh thao tác chỉnh sửa trong lúc request đang xử lý.

#### 5. Cơ chế chống trùng lặp dữ liệu (Idempotency)
- **Idempotency Key:** Client tự động sinh một mã `Client-Request-ID` (UUID v4) ngay khi render form tạo ticket. Mã này được gắn vào Header của request gửi Ticket.
- **Xử lý phía Server:** Server kiểm tra `Client-Request-ID`. Nếu trùng trong thời gian timeout (ví dụ: 30 giây), Server từ chối ghi nhận record mới và trả về kết quả của Ticket đã tạo trước đó.
- **Handling Retry/Lag Network:** Trường hợp mất mạng hoặc timeout từ Client, nếu Client bấm gửi lại với cùng `Client-Request-ID`, hệ thống không bao giờ sinh ra Ticket thứ 2.

#### 6. Luồng xử lý chi tiết (Flow of Events)
1. Sinh viên bấm nút Tạo yêu cầu mới.
2. Hệ thống tải danh mục Category và render Form. Sinh ngữ cảnh `Client-Request-ID`.
3. Sinh viên điền các trường thông tin và tải file đính kèm (nếu có).
4. Client kiểm tra validation toàn bộ form.
5. Sinh viên nhấn Gửi yêu cầu.
6. Client gọi API upload file (hoặc gửi multipart) kèm theo `Client-Request-ID`.
7. Server khởi tạo Ticket với trạng thái mặc định là `NEW`, ghi nhận log khởi tạo, trả về mã Ticket dạng chuẩn (VD: `TK-20261009-0001`).
8. Client nhận phản hồi thành công, hiển thị Modal/Toast thông báo thành công kèm mã Ticket, tự động chuyển về trang `/tickets/{ticket_id}`.

#### 7. Luồng ngoại lệ & Mã lỗi (Alternative & Error Flows)
- **File sai định dạng/Quá dung lượng:** Block file ngay tại Client, hiển thị message error dưới khu vực upload: *"File [Tên_File] vượt quá 5MB hoặc không đúng định dạng (.pdf, .png, .jpg, .jpeg)"*.
- **Upload thất bại:** Nếu API upload file lỗi, ngắt toàn bộ tiến trình tạo Ticket, hiển thị lỗi: *"Không thể tải file lên. Vui lòng thử lại"*.
- **Request bị trùng lặp (409 Conflict):** Trả về thông tin Ticket đã tạo, chuyển người dùng đến chi tiết Ticket đó.

#### 8. Tiêu chí nghiệm thu (Acceptance Criteria)
- **AC-01:** Điền đầy đủ thông tin + File hợp lệ -> Tạo 01 Ticket duy nhất trạng thái `NEW`, sinh đúng định dạng Mã Ticket.
- **AC-02:** Nhập khoảng trắng vào tiêu đề/mô tả -> Nút gửi bị khóa hoặc hiển thị lỗi validation *"Nội dung không được để trống"*.
- **AC-03:** Kéo thả 6 file hoặc file `.exe` / `.docx` -> Hệ thống từ chối nhận file và hiển thị lý do rõ ràng.
- **AC-04:** Bấm nút Gửi liên tục 5 lần / F5 gửi lại request -> Chỉ duy nhất 01 Ticket được tạo trên Database.

- **AC-05:** Chọn nhóm vấn đề có sẵn và gửi thành công -> Chi tiết yêu cầu thể hiện đúng phòng ban tiếp nhận mặc định của nhóm đã chọn theo WF-01; không tạo nhóm vấn đề mới từ biểu mẫu này.
- **AC-06:** Chọn tệp hợp lệ có đuôi `.jpeg` -> Không bị báo sai định dạng; thông báo giới hạn tệp liệt kê đủ bốn định dạng tại mục 3.

---

### [FR-STU-03] Sinh viên theo dõi tiến độ & bổ sung hồ sơ

#### 1. Mô tả & Phạm vi
Cung cấp giao diện xem danh sách các Ticket cá nhân, tra cứu chi tiết luồng xử lý, xem lịch sử phản hồi từ nhân viên và thực hiện bổ sung file/giấy tờ khi có yêu cầu.

**Luồng thao tác nghiệp vụ:**

1. Sinh viên mở danh sách yêu cầu cá nhân, chọn một yêu cầu để xem trạng thái, phòng ban, lịch sử và phản hồi.
2. Khi nhân viên đã gửi yêu cầu bổ sung tại FR-STF-04, sinh viên đọc nội dung cần bổ sung trên chính yêu cầu đó.
3. Sinh viên gửi hồ sơ bổ sung và lời nhắn nếu có; sau khi gửi thành công, yêu cầu quay lại trạng thái đang xử lý để nhân viên tiếp tục.
4. Hồ sơ bổ sung thuộc cùng mã yêu cầu, không tạo yêu cầu mới và không sửa tiêu đề, nhóm vấn đề hoặc phản hồi cũ.

#### 2. Actors & Điều kiện tiên quyết
- **Actor:** Sinh viên đã đăng nhập.
- **Preconditions:** Đã có dữ liệu Ticket trong hệ thống.

#### 3. Phân trang, Bộ lọc & Sắp xếp (List View Rules)
- **Phân trang:** Mặc định 10 Ticket / trang. Có bộ chọn chuyển trang (Pagination).
- **Bộ lọc Trạng thái:** Filter theo danh sách: Tất cả, `NEW` (Mới tạo), `IN_PROGRESS` (Đang xử lý), `NEED_MORE_INFO` (Cần bổ sung), `RESOLVED` (Đã xử lý), `CLOSED` (Đã đóng).
- **Sắp xếp:** Mặc định xếp theo thời gian cập nhật mới nhất (`updated_at DESC`).
- **Phân quyền truy cập dữ liệu:** Query dữ liệu cứng theo `student_id` của tài khoản đang đăng nhập. Không cho phép đổi ID trên URL để xem Ticket của sinh viên khác.

#### 4. Quy tắc Bổ sung Hồ sơ (Ticket State Machine)
- **Điều kiện hiển thị Form Bổ sung:** Nút Bổ sung thông tin VÀ khu vực upload file CHỈ hiển thị khi Ticket có trạng thái chính xác là `NEED_MORE_INFO`.
- **Ràng buộc chỉnh sửa:** Không cho phép sửa Title, Category, hay các phản hồi trước đó. Chỉ được nhập thêm Lời nhắn bổ sung (Optional, max 1000 ký tự) và File đính kèm bổ sung (Max 5 file, tuân thủ rule dung lượng/định dạng như FR-STU-02).
- **Chuyển đổi trạng thái (State Transition):** Sau khi sinh viên gửi bổ sung thành công, hệ thống tự động chuyển trạng thái Ticket từ `NEED_MORE_INFO` sang `IN_PROGRESS`.

#### 5. Luồng xử lý chi tiết (Flow of Events)
1. Sinh viên truy cập trang `/tickets`. Hệ thống hiển thị danh sách Ticket cá nhân.
2. Sinh viên click chọn 1 Ticket. Client chuyển hướng sang `/tickets/{ticket_id}`.
3. Hệ thống hiển thị chi tiết Ticket: Mã ticket, Ngày tạo, Trạng thái, Phòng ban phụ trách, Timeline các bước xử lý và Lịch sử trao đổi (Conversation log).
4. Nếu trạng thái là `NEED_MORE_INFO`:
   - Hiển thị hộp thông điệp yêu cầu từ nhân viên và khung upload bổ sung.
   - Sinh viên chọn file đính kèm, nhập lời nhắn (nếu có) và nhấn Gửi bổ sung.
   - Client gửi request cập nhật.
   - Server lưu file, ghi nhận tin nhắn mới vào Conversation log, cập nhật `status = IN_PROGRESS`, gửi notify cho Nhân viên phụ trách.
5. Giao diện Client cập nhật lại trạng thái Ticket thành `IN_PROGRESS`, ẩn Form bổ sung thông tin.

#### 6. Luồng ngoại lệ & Mã lỗi (Alternative & Error Flows)
- **Truy cập Ticket của người khác (403 Forbidden / 404 Not Found):** Hiển thị màn hình lỗi: *"Không tìm thấy yêu cầu hoặc bạn không có quyền truy cập."* kèm nút Quay lại danh sách.
- **Gửi bổ sung khi Ticket đã chuyển trạng thái khác (400 Bad Request):** Nếu nhân viên đã hủy hoặc đổi trạng thái Ticket ở tab khác, khi sinh viên bấm gửi sẽ báo lỗi: *"Trạng thái Ticket đã thay đổi, không thể bổ sung hồ sơ vào lúc này."* và tự động reload lại dữ liệu Ticket.

#### 7. Tiêu chí nghiệm thu (Acceptance Criteria)
- **AC-01:** Trang danh sách phân trang chuẩn 10 item/trang, filter đúng theo từng trạng thái chọn.
- **AC-02:** Thay đổi Ticket ID trên URL sang ID thuộc về sinh viên khác -> Trả về lỗi 403/404, không lộ dữ liệu.
- **AC-03:** Bổ sung file thành công khi Ticket ở `NEED_MORE_INFO` -> Trạng thái Ticket lập tức đổi sang `IN_PROGRESS` trên cả giao diện và Database.
- **AC-04:** Ticket ở trạng thái `IN_PROGRESS`, `RESOLVED`, `CLOSED` -> Ẩn hoàn toàn tính năng upload/gửi file bổ sung.

- **AC-05:** Nhân viên gửi yêu cầu bổ sung theo FR-STF-04 -> Sinh viên thấy đúng nội dung cần bổ sung tại cùng mã Ticket; gửi bổ sung thành công -> Nhân viên xem được phần bổ sung trong lịch sử của Ticket đó.

---

### [FR-STU-04] Xem kết quả giải quyết & Đánh giá mức độ hài lòng

#### 1. Mô tả & Phạm vi
Cho phép sinh viên xem nội dung phản hồi kết quả xử lý cuối cùng từ nhà trường và thực hiện đánh giá chất lượng dịch vụ cho Ticket đã hoàn tất.

**Luồng thao tác nghiệp vụ:**

1. Sinh viên mở yêu cầu đã giải quyết/đã đóng của mình và đọc câu trả lời, tệp kết quả nếu có và thời gian hoàn thành.
2. Nếu chưa đánh giá, sinh viên chọn 1–5 sao, nhập nhận xét nếu muốn rồi gửi; nếu đã đánh giá thì chỉ xem lại đánh giá đã lưu.
3. Gửi thành công thì hiển thị lời cảm ơn và đánh giá ở chế độ chỉ đọc. Khi lỗi mạng, giữ số sao và nhận xét để thử lại theo AC-04.
4. Mở lại trang chi tiết để xem hoặc đánh giá không có nghĩa mở lại quá trình xử lý Ticket.

#### 2. Actors & Điều kiện tiên quyết
- **Actor:** Sinh viên đã đăng nhập.
- **Preconditions:** Ticket của sinh viên đã được Nhân viên/Quản lý xử lý xong và chuyển sang trạng thái `RESOLVED` hoặc `CLOSED`.

#### 3. Quy tắc Dữ liệu & Đánh giá (Business & Validation Rules)
- **Trường thông tin Đánh giá:**
  - **Rating:** Bắt buộc, số nguyên từ 1 đến 5 (tương ứng từ 1 sao đến 5 sao).
  - **Feedback / Comment:** Không bắt buộc, tối đa 500 ký tự. Tự động `trim()`.
- **Ràng buộc số lần đánh giá:** Mỗi Ticket chỉ được đánh giá duy nhất 01 lần.
- **Khóa biểu mẫu:** Khi Ticket đã có dữ liệu đánh giá, hệ thống chuyển Form đánh giá sang trạng thái Read-Only (Hiển thị số sao và nhận xét đã gửi, không cho thao tác bấm gửi lại).

#### 4. Luồng xử lý chi tiết (Flow of Events)
1. Sinh viên mở chi tiết Ticket đã xử lý xong tại `/tickets/{ticket_id}`.
2. Hệ thống hiển thị rõ ràng phần Kết quả giải quyết (Gồm câu trả lời, file đính kèm kết quả từ nhân viên nếu có, thời gian hoàn thành).
3. Kiểm tra trạng thái đánh giá của Ticket:
   - Chưa đánh giá: Hiển thị Component Đánh giá (5 ngôi sao tương tác + Textarea nhập nhận xét + Nút Gửi đánh giá).
   - Đã đánh giá: Hiển thị kết quả đánh giá cũ dạng Read-only.
4. Sinh viên chọn số sao, nhập nhận xét và bấm Gửi đánh giá.
5. Client gửi request lưu đánh giá.
6. Server ghi nhận thông tin đánh giá, chuyển trạng thái Ticket từ `RESOLVED` sang `CLOSED` (nếu đang ở `RESOLVED`), lưu timestamp `rated_at`.
7. Client hiển thị Toast thông báo: *"Cảm ơn bạn đã đánh giá dịch vụ!"*, đồng thời chuyển Component đánh giá sang dạng Read-only.

#### 5. Luồng ngoại lệ & Race Condition Handling
- **Lỗi mạng khi gửi đánh giá:** Hiển thị *"Chưa gửi được đánh giá. Vui lòng thử lại."* và giữ nguyên số sao, nhận xét đã nhập theo AC-04.
- **Đánh giá đồng thời nhiều tab (Race Condition):** Nếu sinh viên mở 2 tab cùng 1 Ticket và bấm gửi ở tab A trước:
  - **Tab A:** Gửi thành công.
  - **Tab B:** Khi bấm gửi, Server trả về mã lỗi 409 Conflict hoặc 400 Bad Request với message: *"Ticket này đã được đánh giá trước đó."*
  - **Client tại Tab B nhận lỗi:** Tự động ẩn form nhập và fetch lại dữ liệu đánh giá đã lưu để hiển thị dạng Read-only.

#### 6. Tiêu chí nghiệm thu (Acceptance Criteria)
- **AC-01:** Đánh giá 5 sao + nhận xét hợp lệ -> Lưu chính xác dữ liệu vào hệ thống, hiển thị đúng trạng thái đã đánh giá.
- **AC-02:** Không chọn số sao mà bấm Gửi -> Báo lỗi validation: *"Vui lòng chọn mức độ hài lòng (từ 1 đến 5 sao)"*.
- **AC-03:** Sau khi gửi đánh giá thành công, F5 lại trang hoặc mở lại trang chi tiết Ticket -> Form đánh giá ở trạng thái Read-only, không thể chỉnh sửa hay gửi lại.
- **AC-04:** Lỗi mạng khi gửi đánh giá -> Thông báo lỗi, giữ nguyên số sao và nhận xét sinh viên đã nhập trên giao diện để sinh viên bấm thử lại.

---

## III. BẢNG MÃ LỖI CHUẨN DÙNG CHUNG CHO DEV (SYSTEM ERROR CODES)

Để Frontend và Backend đồng bộ xử lý không cần trao đổi thêm, phân hệ áp dụng chuẩn response lỗi như sau:

| HTTP Status | Error Code | Message hiển thị người dùng | Kịch bản áp dụng |
| :--- | :--- | :--- | :--- |
| **400** | `INVALID_INPUT` | *"Dữ liệu nhập vào không hợp lệ. Vui lòng kiểm tra lại."* | Lỗi validation trường dữ liệu đầu vào. |
| **400** | `FILE_EXCEEDS_LIMIT` | *"File đính kèm vượt quá dung lượng 5MB."* | Upload file > 5MB. |
| **400** | `FILE_TYPE_NOT_ALLOWED` | *"Chỉ chấp nhận file .pdf, .png, .jpg, .jpeg."* | Upload sai định dạng file. |
| **401** | `UNAUTHORIZED` | *"Phiên đăng nhập đã hết hạn. Vui lòng đăng nhập lại."* | Token hết hạn hoặc không hợp lệ. |
| **403** | `FORBIDDEN_ACCESS` | *"Bạn không có quyền truy cập vào tài nguyên này."* | Sinh viên xem Ticket của người khác. |
| **404** | `TICKET_NOT_FOUND` | *"Không tìm thấy dữ liệu Ticket yêu cầu."* | Ticket ID không tồn tại. |
| **409** | `ALREADY_RATED` | *"Ticket này đã được đánh giá trước đó."* | Gửi đánh giá 2 lần cho 1 Ticket. |
| **409** | `DUPLICATE_REQUEST` | *"Yêu cầu đang được xử lý, vui lòng không thao tác lặp lại."* | Trùng Client-Request-ID. |
| **500** | `INTERNAL_SERVER_ERROR` | *"Hệ thống gặp sự cố kỹ thuật. Vui lòng thử lại sau."* | Lỗi Server/Database unhandled. |
# Phân Hệ Sinh Viên (M01 - Student Portal)

## 1. Tổng Quan
Phân hệ Sinh viên cung cấp giao diện trực quan, thân thiện trên cả máy tính và thiết bị di động, giúp sinh viên Aurora University chủ động tạo yêu cầu hỗ trợ, theo dõi tiến độ giải quyết theo thời gian thực và đánh giá chất lượng dịch vụ.

---

## 2. Danh Sách Chức Năng Cốt Lõi
* **[FR-STU-01]** Đăng nhập tài khoản sinh viên.
* **[FR-STU-02]** Gửi yêu cầu hỗ trợ (Tạo Ticket kèm file đính kèm ảnh/PDF).
* **[FR-STU-03]** Theo dõi tiến độ, xem lịch sử xử lý & bổ sung thông tin/giấy tờ theo yêu cầu.
* **[FR-STU-04]** Xem kết quả giải quyết & Đánh giá mức độ hài lòng.
# Phân Hệ Nhân Viên (M02 - Staff Operations)

## I. TỔNG QUAN PHÂN HỆ

Phân hệ Nhân viên cung cấp không gian làm việc chuyên môn cho Cán bộ / Nhân viên các phòng ban tại Aurora University. Phân hệ bao gồm các nhóm chức năng chính: Quản lý Queue Ticket phòng ban, Tiếp nhận & Phân loại, Chuyển tiếp liên phòng ban, Yêu cầu bổ sung hồ sơ, Cập nhật tiến độ xử lý, Ghi nhận kết quả và Đóng Ticket.

### 1. Luồng sử dụng và trách nhiệm

Nhân viên đăng nhập bằng tài khoản do ADMIN cấp và gán phòng ban. Nhân viên xem hàng đợi phòng ban, tiếp nhận yêu cầu chưa có người xử lý, kiểm tra nội dung, yêu cầu bổ sung nếu thiếu, chuyển phòng ban nếu cần hoặc ghi kết quả khi đã xử lý xong. Sinh viên theo dõi và bổ sung tại M01; kết quả được xem và đánh giá tại FR-STU-04.

Tiếp nhận là nhận yêu cầu về xử lý cá nhân. Chuyển phòng ban là bàn giao yêu cầu vào hàng đợi của đơn vị khác. Phân công/thu hồi/phân công lại trong cùng phòng là quyền MANAGER/ADMIN đã có trong Actors & Roles; không đồng nhất với hai thao tác trên.

### 2. Giới hạn công sức

Giữ nguyên Resource!12:17: 187 giờ cơ sở + 10 giờ dự phòng = 197 giờ kế hoạch cho Staff. FR-STF-01 dùng chung phạm vi tài khoản tại Resource!22. Các FR tiếp nhận, chuyển tiếp, bổ sung và hoàn tất có thể dùng chung dòng công sức; không cộng giờ của một dòng lần thứ hai vì dòng đó liên quan nhiều FR.

---

## II. CHI TIẾT CÁC CHỨC NĂNG (FUNCTIONAL REQUIREMENTS)

### [FR-STF-01] Nhân viên đăng nhập hệ thống

#### 1. Mô tả & Phạm vi
Cho phép Nhân viên đăng nhập bằng tài khoản công vụ (Email/Username) do nhà trường cấp. Hệ thống xác thực, trả về Token và cấp quyền truy cập vào Workspace của Phòng ban tương ứng.

**Luồng thao tác nghiệp vụ:**

1. Nhân viên dùng tài khoản đã được ADMIN cấp và gán đúng phòng ban để đăng nhập.
2. Đăng nhập thành công thì vào không gian làm việc và hàng đợi của phòng ban được gán.
3. Sai thông tin, sai vai trò hoặc tài khoản khóa thì hiển thị thông báo tại mục 6; không cấp quyền làm việc tại phòng ban khác.

#### 2. Actors & Điều kiện tiên quyết
- **Actor:** Nhân viên phòng ban (Staff).
- **Preconditions:** Tài khoản đã được Quản trị viên hệ thống (ADMIN) khởi tạo theo FR-MNG-04, được gán đúng `Department_ID` và ở trạng thái `ACTIVE`.

#### 3. Quy tắc Dữ liệu & Validation (Data Contracts)
- **Trường dữ liệu đầu vào:**
  - **Username / Email:** Bắt buộc, tự động `trim()` khoảng trắng hai đầu.
  - **Password:** Bắt buộc, độ dài 6 - 50 ký tự.
- **Scope & Session Context:** Sau khi xác thực thành công, Token phải chứa các thông báo context: `user_id`, `role = STAFF`, `department_id`, `permissions_list`.

#### 4. Giao diện & Hành vi UI/UX (UI States)
- **Trạng thái Nút Đăng nhập:** Disable khi thông tin trống. Chuyển Loading (kèm spinner) và khóa toàn bộ Form khi request đang được xử lý.
- **Redirect Rule:** Đăng nhập thành công -> Tự động điều hướng về `/staff/dashboard` (Hiển thị Queue Ticket của phòng ban).

#### 5. Luồng xử lý chi tiết (Flow of Events)
1. Nhân viên truy cập `/staff/login`.
2. Kiểm tra phiên làm việc: Nếu Token hợp lệ -> Chuyển hướng sang `/staff/dashboard`.
3. Nhập Username/Email và Password, nhấn Đăng nhập (hoặc phím Enter).
4. Client validate form -> Gửi request đăng nhập.
5. Server xác thực thông tin, kiểm tra vai trò `STAFF`:
   - Trả về Token xác thực (JWT) + Profile (`staff_id`, `full_name`, `department_id`).
6. Client lưu Token an toàn, chuyển hướng sang `/staff/dashboard`.

#### 6. Luồng ngoại lệ & Mã lỗi (Alternative & Error Flows)
- **Credential không đúng (401 Unauthorized):** Hiển thị Alert error: *"Tài khoản hoặc mật khẩu không chính xác."*
- **Tài khoản không phải STAFF (403 Forbidden):** Hiển thị Alert error: *"Tài khoản của bạn không có quyền truy cập cổng Nhân viên."*
- **Tài khoản bị khóa (403 Forbidden / INACTIVE):** Hiển thị Alert error: *"Tài khoản nhân viên đã bị vô hiệu hóa. Vui lòng liên hệ Quản trị viên."*

#### 7. Tiêu chí nghiệm thu (Acceptance Criteria)
- **AC-01:** Đăng nhập đúng tài khoản Staff -> Chuyển sang Dashboard hiển thị danh sách Ticket của đúng phòng ban đó trong dưới 1.5s.
- **AC-02:** Tài khoản sinh viên cố gắng đăng nhập tại cổng Staff -> Báo lỗi 403 từ chối truy cập.
- **AC-03:** Click Đăng nhập liên tiếp -> Chỉ phát sinh 01 request duy nhất.

---

### [FR-STF-02] Tiếp nhận và phân loại yêu cầu (Claim & Triage)

#### 1. Mô tả & Phạm vi
Cung cấp giao diện Queue công việc chung của Phòng ban. Cho phép nhân viên duyệt qua các Ticket mới (`NEW`) hoặc được chuyển đến (`TRANSFERRED`), đánh giá nội dung, điều chỉnh Mức độ ưu tiên (Priority) và Phân loại lại nhóm vấn đề (Category) nếu cần, sau đó Tiếp nhận (Claim) Ticket về danh sách cá nhân xử lý.

**Luồng thao tác nghiệp vụ:**

1. Nhân viên mở hàng đợi phòng ban, chọn yêu cầu chưa tiếp nhận và đọc nội dung, minh chứng.
2. Nhân viên điều chỉnh độ ưu tiên hoặc nhóm vấn đề nếu cần, sử dụng danh mục của phòng ban theo mục 3.
3. Bấm Tiếp nhận xử lý; thành công thì yêu cầu vào danh sách cá nhân, thể hiện người phụ trách và trạng thái đang xử lý.
4. Nếu người khác đã tiếp nhận trước, hiển thị thông báo và cập nhật lại thông tin theo mục 6; không coi thao tác của người gửi sau là thành công.

#### 2. Actors & Điều kiện tiên quyết
- **Actor:** Nhân viên phòng ban.
- **Preconditions:** Ticket đang ở trạng thái `NEW` hoặc `TRANSFERRED`, thuộc `Department_ID` của nhân viên.

#### 3. Quy tắc Dữ liệu & Validation (Data Contracts)
- **Mức độ ưu tiên (Priority):** Enum bắt buộc: `LOW` (Thấp), `MEDIUM` (Trung bình - Mặc định), `HIGH` (Cao), `URGENT` (Khẩn cấp).
- **Phân loại vấn đề (Category):** Dropdown lấy danh sách Category thuộc phòng ban hiện tại.
- **Trạng thái đích:** Chuyển từ `NEW` / `TRANSFERRED` -> `IN_PROGRESS`.
- **Gán phụ trách:** Ghi nhận `assignee_id = current_staff_id`.

#### 4. Cơ chế chống tranh chấp tiếp nhận (Concurrency Control / Optimistic Locking)
- **Bài toán:** Hai nhân viên A và B cùng mở 1 Ticket `NEW` và cùng bấm nút Tiếp nhận xử lý tại 1 thời điểm.
- **Cơ chế xử lý:**
  - Server sử dụng DB Locking / Version check (hoặc `UPDATE tickets SET status='IN_PROGRESS', assignee_id=? WHERE id=? AND status IN ('NEW', 'TRANSFERRED')`).
  - Người gửi request thành công trước sẽ chiếm quyền phụ trách.
  - Người gửi request sau 1 millisecond sẽ nhận phản hồi lỗi 409 Conflict.

#### 5. Luồng xử lý chi tiết (Flow of Events)
1. Nhân viên truy cập Tab "Ticket chưa tiếp nhận" (`/staff/queue`).
2. Chọn một Ticket để mở trang Chi tiết (`/staff/tickets/{ticket_id}`).
3. Nhân viên xem mô tả, đính kèm. Chọn/điều chỉnh Priority và Category nếu sinh viên chọn chưa đúng.
4. Nhấn nút Tiếp nhận xử lý.
5. Client gửi request claim kèm theo Ticket ID và thông tin Priority/Category đã điều chỉnh.
6. Server kiểm tra điều kiện lock:
   - Nếu Ticket vẫn ở trạng thái `NEW` / `TRANSFERRED` -> Cập nhật `status = IN_PROGRESS`, `assignee_id = current_staff_id`, lưu log thao tác. Trả về HTTP 200 OK.
   - Nếu Ticket đã bị người khác claim -> Trả về HTTP 409 Conflict.
7. Client nhận 200 OK: Cập nhật UI, hiển thị Toast *"Đã tiếp nhận Ticket thành công"*, chuyển Ticket sang Tab "Ticket của tôi".

#### 6. Luồng ngoại lệ & Mã lỗi (Alternative & Error Flows)
- **Ticket đã bị gán cho người khác (409 Conflict):** Hiển thị Alert error: *"Ticket này đã được tiếp nhận bởi nhân viên [Tên_Nhân_Viên] trước đó ít giây."* Tự động reload lại trang để khóa nút Tiếp nhận.

#### 7. Tiêu chí nghiệm thu (Acceptance Criteria)
- **AC-01:** Tiếp nhận Ticket thành công -> Trạng thái đổi sang `IN_PROGRESS`, trường người phụ trách hiển thị tên nhân viên hiện tại.
- **AC-02:** Hai nhân viên bấm Tiếp nhận cùng lúc -> Đúng 01 người nhận thành công, người còn lại nhận thông báo lỗi rõ ràng và UI tự cập nhật.
- **AC-03:** Thay đổi Priority từ `MEDIUM` sang `URGENT` trong lúc Claim -> Dữ liệu lưu đúng Priority mới vào CSDL.

- **AC-04:** Tiếp nhận một Ticket được chuyển đến (`TRANSFERRED`) thuộc phòng ban hiện tại -> Ticket vào danh sách cá nhân ở trạng thái `IN_PROGRESS` và ghi đúng người phụ trách, như với Ticket `NEW`.

---

### [FR-STF-03] Chuyển yêu cầu sang đúng phòng ban (Transfer Ticket)

#### 1. Mô tả & Phạm vi
Cho phép nhân viên chuyển tiếp Ticket sang một phòng ban khác nếu yêu cầu gửi nhầm đơn vị hoặc vượt quá thẩm quyền giải quyết. Chức năng này đặc tả chuyển phòng ban; phân công lại nhân viên trong cùng phòng thuộc quyền MANAGER/ADMIN tại Actors & Roles, không thuộc biểu mẫu chuyển phòng ban dưới đây.

**Luồng thao tác nghiệp vụ:**

1. Nhân viên có quyền trên yêu cầu mở thao tác Chuyển phòng ban, chọn đơn vị khác và nhập lý do.
2. Xác nhận chuyển; thành công thì yêu cầu vào hàng đợi chờ tiếp nhận của phòng ban mới và không còn người phụ trách cũ.
3. Nhân viên phòng ban mới tiếp nhận theo FR-STF-02. Lịch sử giữ lại phòng ban cũ, phòng ban mới, người chuyển và lý do.
4. Nếu thiếu lý do hoặc chọn chính phòng ban hiện tại thì không thực hiện chuyển; xử lý theo mục 6.

#### 2. Actors & Điều kiện tiên quyết
- **Actor:** Nhân viên đang phụ trách Ticket (`assignee_id == current_staff_id`) hoặc Nhân viên thuộc phòng ban đang giữ Ticket.
- **Preconditions:** Ticket có trạng thái `NEW`, `IN_PROGRESS`, `NEED_MORE_INFO` (Chưa ở trạng thái `CLOSED`).

#### 3. Quy tắc Dữ liệu & Validation (Data Contracts)
- **Phòng ban đích (Target Department):** Dropdown bắt buộc chọn, khác với phòng ban hiện tại.
- **Lý do chuyển tiếp (Transfer Note):** Bắt buộc nhập, chuỗi từ 10 đến 500 ký tự. Tự động `trim()`. Không chấp nhận chuỗi chỉ chứa khoảng trắng.
- **Chuyển đổi trạng thái & Cập nhật trường:**
  - `status = TRANSFERRED`
  - `department_id = target_department_id`
  - `assignee_id = NULL` (Xóa người phụ trách cũ, đẩy vào Queue chờ của phòng ban mới).

#### 4. Ghi vết lịch sử chuyển tiếp (Audit Log Spec)
- Mỗi lần chuyển phòng ban, hệ thống BẮT BUỘC lưu 01 record vào bảng Audit Log / Ticket History gồm các trường: `ticket_id`, `action = TRANSFER`, `from_department_id`, `to_department_id`, `performed_by_staff_id`, `reason_note`, `created_at`.

#### 5. Luồng xử lý chi tiết (Flow of Events)
1. Trong màn hình chi tiết Ticket, nhân viên bấm Chuyển phòng ban.
2. Modal Chuyển phòng ban hiển thị:
   - Dropdown chọn Target Department.
   - Textarea nhập Reason Note.
3. Nhập dữ liệu và bấm Xác nhận chuyển.
4. Client validate dữ liệu (Bắt buộc chọn phòng ban và nhập lý do >= 10 ký tự).
5. Client gửi request transfer.
6. Server cập nhật `department_id`, `status = TRANSFERRED`, `assignee_id = NULL`, ghi nhận Audit Log. Gửi thông báo (Notification) đến Queue của Phòng ban mới.
7. Client đóng Modal, hiển thị Toast thành công và điều hướng nhân viên về danh sách công việc chung.

#### 6. Luồng ngoại lệ & Mã lỗi (Alternative & Error Flows)
- **Bỏ trống lý do / Lý do quá ngắn (400 Bad Request):** Hiển thị lỗi validation ngay dưới Textarea: *"Lý do chuyển tiếp phải từ 10 đến 500 ký tự."*
- **Chọn trùng phòng ban hiện tại (400 Bad Request):** Disable phòng ban hiện tại trong dropdown list.

#### 7. Tiêu chí nghiệm thu (Acceptance Criteria)
- **AC-01:** Chuyển phòng ban thành công -> Ticket biến mất khỏi Tab "Cá nhân xử lý", xuất hiện trong Queue "Chờ tiếp nhận" của Phòng ban mới.
- **AC-02:** Nhập lý do chỉ gồm khoảng trắng -> Nút Xác nhận bị khóa hoặc báo lỗi validation.
- **AC-03:** Mở Lịch sử Ticket (Timeline) -> Hiển thị đúng nội dung lịch sử: *"Nhân viên A đã chuyển Ticket từ Phòng Đào tạo sang Phòng Tài chính. Lý do: [Nội dung lý do]"*.

---

### [FR-STF-04] Cập nhật tiến độ & Yêu cầu bổ sung thông tin (Request Supplement)

#### 1. Mô tả & Phạm vi
Cho phép Nhân viên gửi yêu cầu trực tiếp đến Sinh viên để yêu cầu giải thích thêm hoặc upload bổ sung các file/giấy tờ minh chứng còn thiếu trước khi có thể xử lý tiếp.

**Luồng thao tác nghiệp vụ:**

1. Nhân viên đang phụ trách đọc hồ sơ và xác định thông tin/giấy tờ còn thiếu trước khi xử lý tiếp.
2. Nhân viên nhập rõ nội dung cần sinh viên cung cấp rồi gửi yêu cầu bổ sung.
3. Gửi thành công thì yêu cầu chuyển sang cần bổ sung; sinh viên nhận thông báo và đọc nội dung trên cổng Sinh viên.
4. Sinh viên gửi phần bổ sung tại FR-STU-03; nhân viên đọc phần bổ sung trên cùng yêu cầu để tiếp tục xử lý.

#### 2. Actors & Điều kiện tiên quyết
- **Actor:** Nhân viên đang phụ trách Ticket (`assignee_id == current_staff_id`).
- **Preconditions:** Ticket ở trạng thái `IN_PROGRESS`.

#### 3. Quy tắc Dữ liệu & Validation (Data Contracts)
- **Nội dung yêu cầu bổ sung (Request Note):** Bắt buộc nhập, chuỗi từ 10 đến 1000 ký tự. Không chứa toàn khoảng trắng. Tự động `trim()`.
- **Danh mục giấy tờ cần bổ sung (Requested Documents Checkbox/Text):** Chọn từ danh sách mẫu hoặc nhập tự do để sinh viên dễ hình dung.
- **Thay đổi trạng thái:** Chuyển từ `IN_PROGRESS` -> `NEED_MORE_INFO`.

#### 4. Luồng xử lý chi tiết (Flow of Events)
1. Trong màn chi tiết Ticket, nhân viên chọn nút Yêu cầu bổ sung hồ sơ.
2. Hiển thị Form nhập nội dung yêu cầu.
3. Nhân viên nhập chi tiết các giấy tờ/thông tin sinh viên cần cung cấp thêm, nhấn Gửi yêu cầu.
4. Client thực hiện validate client-side.
5. Client gửi request cập nhật.
6. Server cập nhật `status = NEED_MORE_INFO`, lưu tin nhắn vào Conversation log, phát Notification (In-app / Email) cho Sinh viên.
7. Client hiển thị Toast success: *"Đã gửi yêu cầu bổ sung thông tin tới sinh viên"*, cập nhật Badge trạng thái trên UI thành `NEED_MORE_INFO`.

#### 5. Luồng ngoại lệ & Mã lỗi (Alternative & Error Flows)
- **Ticket bị thay đổi trạng thái bởi thao tác khác (400 Bad Request):** Nếu Ticket không còn ở `IN_PROGRESS` (ví dụ bị Quản lý can thiệp đóng), báo lỗi: *"Ticket không ở trạng thái cho phép yêu cầu bổ sung."*

#### 6. Tiêu chí nghiệm thu (Acceptance Criteria)
- **AC-01:** Gửi yêu cầu thành công -> Trạng thái Ticket đổi sang `NEED_MORE_INFO`, sinh viên thấy nội dung yêu cầu này trên Cổng Sinh viên.
- **AC-02:** Không cho phép gửi tin nhắn rỗng hoặc chỉ chứa khoảng trắng.

- **AC-03:** Gửi nội dung yêu cầu bổ sung hợp lệ -> Nội dung sinh viên đọc được tại FR-STU-03 trùng với nội dung nhân viên đã gửi, trên đúng mã Ticket; lịch sử phản hồi cũ vẫn được giữ.

---

### [FR-STF-05] Ghi kết quả và hoàn tất xử lý yêu cầu (Complete & Resolve Ticket)

#### 1. Mô tả & Phạm vi
Cho phép nhân viên nhập kết quả giải quyết chi tiết, đính kèm tệp kết quả nếu có và xác nhận hoàn tất xử lý để sinh viên xem kết quả. “Đã giải quyết” và “Đã đóng” là hai trạng thái khác nhau; giao diện phải thể hiện đúng trạng thái thực tế của Ticket theo quy tắc hiện có.

**Luồng thao tác nghiệp vụ:**

1. Nhân viên đang phụ trách mở thao tác Hoàn tất xử lý, nhập câu trả lời/kết quả và chọn tệp kết quả nếu cần.
2. Nhân viên xác nhận hoàn tất; chỉ thông báo thành công sau khi kết quả đã được ghi nhận.
3. Sinh viên nhận thông báo và xem câu trả lời, tệp kết quả, thời gian hoàn thành tại FR-STU-04.
4. Hiển thị “Đã giải quyết” khi Ticket ở RESOLVED, “Đã đóng” khi ở CLOSED. Việc đóng sau đánh giá theo FR-STU-04/WF-06 được giữ theo tài liệu gốc; không bổ sung thao tác mở lại xử lý.

#### 2. Actors & Điều kiện tiên quyết
- **Actor:** Nhân viên đang phụ trách Ticket.
- **Preconditions:** Ticket đang ở trạng thái `IN_PROGRESS`.

#### 3. Quy tắc Dữ liệu & Validation (Data Contracts)
- **Nội dung kết quả giải quyết (Resolution Detail):** Bắt buộc nhập, chuỗi từ 20 đến 2000 ký tự. Tự động `trim()`. Không chấp nhận chuỗi chỉ chứa khoảng trắng.
- **File đính kèm kết quả (Resolution Attachments):** Optional. Tối đa 3 file, mỗi file <= 5MB, định dạng `.pdf`, `.png`, `.jpg`, `.jpeg`.
- **Chuyển đổi trạng thái:**
  - Chuyển `status` từ `IN_PROGRESS` -> `RESOLVED` (Hoặc `CLOSED` tùy cấu hình luồng tự động đóng).
  - Cập nhật timestamp `resolved_at = CURRENT_TIMESTAMP`.

#### 4. Luồng xử lý chi tiết (Flow of Events)
1. Nhân viên chọn nút Hoàn tất xử lý.
2. Hiển thị Form Ghi nhận kết quả giải quyết:
   - Textarea nhập Resolution Detail.
   - Khu vực Upload file đính kèm kết quả.
3. Nhân viên nhập kết quả, đính kèm file (nếu có) và nhấn Xác nhận hoàn tất.
4. Client kiểm tra validation dữ liệu.
5. Client gửi request hoàn tất.
6. Server lưu thông tin kết quả giải quyết, file đính kèm kết quả, cập nhật `status = RESOLVED` (hoặc `CLOSED`), lưu `resolved_at`, phát Notification báo kết quả cho Sinh viên.
7. Client cập nhật UI: Hiển thị Đã giải quyết nếu trạng thái là `RESOLVED`, Đã đóng nếu trạng thái là `CLOSED`; ẩn các button thao tác xử lý.

#### 5. Luồng ngoại lệ & Mã lỗi (Alternative & Error Flows)
- **Để trống kết quả hoặc chỉ nhập khoảng trắng (400 Bad Request):** Hiển thị lỗi ngay tại Client: *"Nội dung kết quả giải quyết không được để trống (tối thiểu 20 ký tự)."*
- **Upload file kết quả lỗi (400 Bad Request / 500):** Ngắt tiến trình hoàn tất xử lý Ticket, giữ nguyên dữ liệu đã nhập trên Form, hiển thị thông báo lỗi upload file.

#### 6. Tiêu chí nghiệm thu (Acceptance Criteria)
- **AC-01:** Nhập kết quả >= 20 ký tự + bấm Xác nhận hoàn tất -> Ticket đổi sang trạng thái `RESOLVED`/`CLOSED`, thời gian hoàn thành ghi nhận chính xác. Sinh viên xem được đầy đủ câu trả lời này.
- **AC-02:** Nhập dưới 20 ký tự hoặc cố tình spam spacebar -> Báo lỗi validation, không cho gửi request.
- **AC-03:** Ticket đã đóng -> Khóa toàn bộ các nút thao tác (Tiếp nhận, Chuyển phòng, Yêu cầu bổ sung).

- **AC-04:** Sau khi hoàn tất, trạng thái thực tế là `RESOLVED` -> Nhãn hiển thị Đã giải quyết; là `CLOSED` -> Nhãn hiển thị Đã đóng. Cả hai trường hợp sinh viên xem được kết quả đã lưu theo FR-STU-04.

---

## III. BẢNG MÃ LỖI CHUẨN DÙNG CHUNG PHÂN HỆ STAFF (SYSTEM ERROR CODES)

| HTTP Status | Error Code | Message hiển thị người dùng | Kịch bản áp dụng |
| :--- | :--- | :--- | :--- |
| **400** | `INVALID_INPUT` | *"Dữ liệu nhập vào không hợp lệ. Vui lòng kiểm tra lại."* | Lỗi validation trường dữ liệu đầu vào. |
| **400** | `INVALID_TICKET_STATE` | *"Trạng thái Ticket hiện tại không cho phép thực hiện thao tác này."* | Thao tác sai luồng trạng thái (VD: Yêu cầu bổ sung khi Ticket đã đóng). |
| **400** | `MISSING_TRANSFER_REASON` | *"Vui lòng nhập lý do chuyển phòng ban (tối thiểu 10 ký tự)."* | Không nhập lý do khi chuyển tiếp. |
| **401** | `UNAUTHORIZED` | *"Phiên đăng nhập hết hạn. Vui lòng đăng nhập lại."* | Token Staff hết hạn. |
| **403** | `FORBIDDEN_STAFF_ACCESS` | *"Bạn không có quyền thao tác trên Ticket của phòng ban khác."* | Staff cố truy cập/chỉnh sửa Ticket không thuộc thẩm quyền. |
| **409** | `TICKET_ALREADY_CLAIMED` | *"Ticket này đã được tiếp nhận bởi nhân viên [Tên_Staff] trước đó."* | Xảy ra tranh chấp khi 2 Staff bấm Claim cùng lúc. |
| **500** | `INTERNAL_SERVER_ERROR` | *"Hệ thống gặp sự cố kỹ thuật. Vui lòng thử lại sau."* | Lỗi Server/Database unhandled. |
# Phân Hệ Nhân Viên (M02 - Staff Operations)

## 1. Tổng Quan
Phân hệ Nhân viên tối ưu hóa toàn bộ quy trình tiếp nhận, phân loại, đánh giá độ ưu tiên, điều phối liên phòng ban, giao tiếp bổ sung thông tin và đóng các phiếu hỗ trợ sinh viên.

---

## 2. Danh Sách Chức Năng Cốt Lõi
* **[FR-STF-01]** Đăng nhập tài khoản nhân viên.
* **[FR-STF-02]** Tiếp nhận, phân loại nhóm vấn đề & gán độ ưu tiên cho Ticket.
* **[FR-STF-03]** Chuyển tiếp Ticket sang phòng ban/người phụ trách khác.
* **[FR-STF-04]** Cập nhật tiến độ & Yêu cầu sinh viên bổ sung thông tin/giấy tờ.
* **[FR-STF-05]** Ghi nhận kết quả giải quyết & Đóng Ticket.
# Phân Hệ Quản Lý (M03 - Management Dashboard)

## I. TỔNG QUAN PHÂN HỆ

Phân hệ Quản lý cung cấp trung tâm điều hành cho Ban Quản lý và Quản trị viên hệ thống (Admin). Phân hệ bao gồm các nhóm chức năng chính: Bảng theo dõi chỉ số thời gian thực (Real-time Metrics), Giám sát tuân thủ SLA, Báo cáo phân tích xu hướng & chất lượng dịch vụ, Quản lý tài khoản người dùng & Phân quyền (RBAC), và Nhật ký hệ thống (Audit Logs).

### 1. Luồng sử dụng và giới hạn vai trò

MANAGER đăng nhập để theo dõi tình hình và báo cáo của phòng ban mình. ADMIN đăng nhập để xem dữ liệu toàn trường, quản trị tài khoản/quyền và tra soát nhật ký. Quản trị tài khoản thuộc riêng ADMIN tại FR-MNG-04; quyền MANAGER giám sát và phân công nhân sự trong phòng ban không bao gồm tạo tài khoản.

Dashboard phục vụ theo dõi tình hình hiện tại; báo cáo phục vụ phân tích kỳ dữ liệu đã chọn và xuất dữ liệu. Điểm hài lòng trong báo cáo lấy từ đánh giá đã có ở FR-STU-04, không phát sinh một chức năng đánh giá khác.

### 2. Giới hạn công sức

Giữ nguyên Resource!22:27: 207 giờ cơ sở + 8 giờ dự phòng = 215 giờ kế hoạch cho Admin/Management. Phạm vi tài khoản/đăng nhập của cả ba cổng dùng chung Resource!22; kiểm soát quyền và nhật ký dùng Resource!24. Bảng đối chiếu cuối PRD ghi giờ từng dòng và vai trò; không cộng thêm công sức vì diễn giải rõ hơn yêu cầu.

---

## II. CHI TIẾT CÁC CHỨC NĂNG (FUNCTIONAL REQUIREMENTS)

### [FR-MNG-01] Quản lý đăng nhập & Xác thực phân quyền

#### 1. Mô tả & Phạm vi
Cho phép Trưởng phòng ban (Manager) và Quản trị hệ thống (Admin) đăng nhập vào Cổng Quản trị UniSupport, xác thực hai yếu tố (nếu bật) và phân luồng dữ liệu theo cấp quản lý.

**Luồng thao tác nghiệp vụ:**

1. MANAGER hoặc ADMIN dùng tài khoản đang hoạt động để đăng nhập vào cổng quản trị.
2. MANAGER vào màn hình dữ liệu phòng ban mình; ADMIN vào màn hình dữ liệu toàn trường.
3. Menu và dữ liệu được giới hạn theo vai trò tại mục 3. Tài khoản STUDENT/STAFF hoặc tài khoản bị vô hiệu hóa bị từ chối theo mục 6.

#### 2. Actors & Điều kiện tiên quyết
- **Actor:** Quản lý phòng ban (MANAGER), Quản trị viên hệ thống (ADMIN).
- **Preconditions:** Tài khoản tồn tại trên CSDL, `status = ACTIVE`, thuộc nhóm vai trò `MANAGER` hoặc `ADMIN`.

#### 3. Scope & Phân quyền Dữ liệu (Data Isolation Rules)
- **Cấp Quản lý Phòng ban (MANAGER):**
  - Chỉ xem được Dashboard, Metric, Báo cáo và Danh sách Ticket thuộc `department_id` của mình phụ trách.
  - Không có quyền truy cập vào menu Quản trị tài khoản toàn hệ thống.
- **Cấp Quản trị Hệ thống (ADMIN):**
  - Xem toàn bộ Dashboard, Báo cáo toàn trường (All departments).
  - Toàn quyền tạo, sửa, vô hiệu hóa tài khoản và gán quyền.

#### 4. Giao diện & Hành vi UI/UX (UI States)
- **Redirect Rule:**
  - ADMIN đăng nhập thành công -> Điều hướng về `/admin/dashboard`.
  - MANAGER đăng nhập thành công -> Điều hướng về `/manager/dashboard` (Mặc định filter theo phòng ban cá nhân).

#### 5. Luồng xử lý chi tiết (Flow of Events)
1. Quản lý truy cập `/admin/login`.
2. Kiểm tra Token: Nếu hợp lệ và có role `MANAGER`/`ADMIN` -> Chuyển thẳng vào Dashboard.
3. Nhập Username/Email và Password, nhấn Đăng nhập.
4. Client validate form -> Gửi request đăng nhập.
5. Server xác thực thông tin, cấp JWT Access Token chứa: `user_id`, `role`, `department_id`, `permissions_list`.
6. Client lưu Token an toàn, chuyển hướng dựa theo role.

#### 6. Luồng ngoại lệ & Mã lỗi (Alternative & Error Flows)
- **Credential không đúng (401 Unauthorized):** Hiển thị Alert error: *"Tài khoản hoặc mật khẩu không chính xác."*
- **Tài khoản Student/Staff cố truy cập (403 Forbidden):** Hiển thị Alert error: *"Bạn không có quyền truy cập vào Cổng Quản trị."*
- **Tài khoản bị khóa (403 Forbidden):** Hiển thị Alert error: *"Tài khoản quản trị đã bị vô hiệu hóa."*

#### 7. Tiêu chí nghiệm thu (Acceptance Criteria)
- **AC-01:** Đăng nhập đúng tài khoản `MANAGER` -> Truy cập Dashboard chỉ hiển thị dữ liệu phòng ban phụ trách.
- **AC-02:** Đăng nhập đúng tài khoản `ADMIN` -> Truy cập Dashboard hiển thị dữ liệu toàn trường và đầy đủ Menu Quản trị.
- **AC-03:** Đăng nhập từ tài khoản không phải Admin/Manager -> Trả về lỗi 403, từ chối cấp token.

---

### [FR-MNG-02] Nắm tổng quan tình hình & Giám sát tiến độ (Real-time Dashboard & SLA Supervision)

#### 1. Mô tả & Phạm vi
Cung cấp màn hình Tổng quan chỉ số hoạt động (KPIs), giám sát phân bổ công việc theo Nhân viên/Phòng ban và cảnh báo các Ticket vi phạm hoặc nguy cơ vi phạm thời gian cam kết xử lý (SLA).

**Luồng thao tác nghiệp vụ:**

1. Quản lý mở Dashboard, xem các thẻ tổng quan, bảng khối lượng công việc và danh sách cảnh báo SLA.
2. Chọn kỳ thời gian cần theo dõi; mọi chỉ số và danh sách vẫn nằm trong phạm vi dữ liệu của vai trò đăng nhập.
3. Mở thẻ quá hạn để xem các yêu cầu quá hạn cụ thể theo AC-02, hoặc làm mới dữ liệu theo cơ chế tại mục 4.
4. Kết quả là nhận biết số lượng, tiến độ và yêu cầu cần chú ý; không coi thao tác xem cảnh báo là đã xử lý hoặc hoàn tất Ticket.

#### 2. Actors & Điều kiện tiên quyết
- **Actor:** `MANAGER`, `ADMIN`.
- **Preconditions:** Đã đăng nhập thành công.

#### 3. Quy tắc Dữ liệu & Logic SLA (SLA Calculation Rules)
- **Quy định Khung giờ SLA (SLA Target):** Mặc định thời hạn xử lý Ticket là 24 giờ làm việc kể từ khi tiếp nhận (không tính Thứ 7, Chủ nhật và ngày Lễ).
- **Phân loại Trạng thái SLA:**
  - **Trong hạn (On-Track):** Thời gian còn lại > 25% tổng thời hạn SLA.
  - **Sắp quá hạn (Warning):** Thời gian còn lại <= 25% tổng thời hạn SLA (Ví dụ: Còn dưới 6 giờ).
  - **Đã quá hạn (Breached/Overdue):** Thời gian xử lý thực tế đã vượt quá thời hạn SLA nhưng Ticket chưa ở trạng thái `RESOLVED`/`CLOSED`.
- **Thống kê Chỉ số Cốt lõi (Summary Cards):**
  - **Total Received:** Tổng số Ticket tiếp nhận trong kỳ chọn.
  - **In-Progress:** Số Ticket đang xử lý.
  - **SLA Warning:** Số Ticket đang ở ngưỡng sắp quá hạn.
  - **SLA Breached:** Số Ticket đã quá hạn chưa xử lý xong.
  - **Avg Resolution Time:** Thời gian xử lý trung bình (Giờ).

#### 4. Cơ chế Cập nhật Dữ liệu (Data Refresh Specs)
- **Mặc định:** Dashboard tự động làm mới dữ liệu (Auto-refresh) sau mỗi 60 giây hoặc cung cấp nút Làm mới dữ liệu (Refresh) thủ công.
- **Tối ưu Hiệu năng Query:** Server không query trực tiếp full CSDL cho mỗi lần render. Các chỉ số Tổng quan phải được tính toán qua Aggregation Query hoặc Cached (Redis Cache duration: 30–60s).

#### 5. Luồng xử lý chi tiết (Flow of Events)
1. Quản lý mở trang Dashboard (`/admin/dashboard`).
2. Mặc định hệ thống tải dữ liệu theo Bộ lọc thời gian: 7 ngày gần nhất.
3. Hiển thị 5 Thẻ chỉ số tổng quan (Summary Cards).
4. Hiển thị Bảng phân bổ workload: Số lượng Ticket đang gán cho từng Nhân viên (Assignee) và Trạng thái tương ứng.
5. Hiển thị Danh sách Cảnh báo SLA: Liệt kê các Ticket ở trạng thái `Warning` và `Breached` lên trên cùng.
6. Quản lý có thể thay đổi Bộ lọc thời gian (Hôm nay, 7 ngày, 30 ngày, Tùy chỉnh khoảng ngày).
7. Client gửi request fetch lại data theo khoảng thời gian đã chọn.

#### 6. Luồng ngoại lệ & Mã lỗi (Alternative & Error Flows)
- **Chọn khoảng thời gian không hợp lệ (400 Bad Request):** Ví dụ Ngày bắt đầu > Ngày kết thúc -> Hiển thị lỗi ngay trên Date Picker: *"Khoảng thời gian không hợp lệ."*

#### 7. Tiêu chí nghiệm thu (Acceptance Criteria)
- **AC-01:** Số liệu trên Thẻ chỉ số phản ánh chính xác trạng thái thực tế dưới Database.
- **AC-02:** Click vào thẻ `SLA Breached` -> Chuyển hướng đến danh sách chi tiết các Ticket đã quá hạn.
- **AC-03:** Nhân viên A được gán 5 Ticket -> Bảng phân bổ workload hiển thị đúng 5 Ticket dưới tên Nhân viên A.
- **AC-04:** Bấm nút Refresh -> Dữ liệu cập nhật mới nhất trong dưới 1 giây.

- **AC-05:** MANAGER chọn kỳ thời gian và mở danh sách từ thẻ quá hạn -> Thẻ, bảng khối lượng và danh sách chi tiết đều chỉ chứa dữ liệu phòng ban mình theo FR-MNG-01.

---

### [FR-MNG-03] Xem báo cáo thống kê & Xuất dữ liệu (Analytics & Data Export)

#### 1. Mô tả & Phạm vi
Cho phép Quản lý xem các biểu đồ phân tích chuyên sâu về xu hướng nhóm vấn đề, hiệu năng xử lý của phòng ban/nhân viên, phân bố điểm đánh giá mức độ hài lòng (CSAT) và xuất báo cáo ra file Excel/CSV.

**Luồng thao tác nghiệp vụ:**

1. Quản lý chọn báo cáo Xu hướng, Hiệu năng hoặc CSAT rồi chọn kỳ thời gian và các bộ lọc trong phạm vi được phép.
2. Xem biểu đồ và bảng số liệu; không có dữ liệu thì hiển thị trạng thái rỗng và không cho xuất theo mục 6.
3. Chọn xuất Excel hoặc CSV; file chứa dữ liệu theo cùng bộ lọc và phạm vi đang xem.
4. Vượt 10.000 bản ghi thì thu hẹp kỳ lọc theo thông báo đã có. Dữ liệu CSAT chỉ phản ánh đánh giá đã gửi thành công tại FR-STU-04.

#### 2. Actors & Điều kiện tiên quyết
- **Actor:** `MANAGER`, `ADMIN`.
- **Preconditions:** Đã đăng nhập thành công.

#### 3. Báo cáo Chi tiết & Loại Biểu đồ (Report Specifications)
- **Báo cáo Xu hướng Yêu cầu (Volume Trend):** Biểu đồ đường (Line Chart) thể hiện biến động số lượng Ticket theo ngày/tuần/tháng, phân loại theo Category.
- **Báo cáo Thời gian Xử lý (Performance Report):** Biểu đồ cột (Bar Chart) so sánh Thời gian xử lý trung bình giữa các Phòng ban hoặc giữa các Nhân viên trong cùng phòng.
- **Báo cáo Đánh giá Hài lòng (CSAT Report):**
  - Biểu đồ tròn (Pie Chart) tỷ lệ % đánh giá 1 sao đến 5 sao.
  - Điểm CSAT trung bình = (Tổng số sao / (Tổng số lượt đánh giá * 5)) * 100%.
  - Bảng danh sách phản hồi chi tiết (Gồm: Mã Ticket, Tên Sinh viên, Số sao, Nhận xét, Tên Nhân viên phụ trách).

#### 4. Quy tắc Xuất Dữ liệu (Export Rules)
- **Định dạng hỗ trợ:** Microsoft Excel (`.xlsx`), CSV (`.csv`).
- **Nội dung file xuất:** Chứa đầy đủ các bản ghi theo đúng bộ lọc đang chọn trên giao diện.
- **Giới hạn số lượng (Pagination / Export Limit):** Tối đa 10.000 bản ghi / 1 lần xuất. Nếu vượt quá 10.000 bản ghi, hệ thống yêu cầu người dùng hẹp khoảng thời gian lọc.
- **Đặt tên File tự động:** `[Ma_Bao_Cao]_[Tu_Ngay]_[Den_Ngay].[xlsx]` (Ví dụ: `CSAT_Report_20261001_20261009.xlsx`).

#### 5. Luồng xử lý chi tiết (Flow of Events)
1. Quản lý truy cập menu Báo cáo & Thống kê (`/admin/reports`).
2. Chọn Tab báo cáo cần xem (Xu hướng / Hiệu năng / CSAT).
3. Chọn Bộ lọc: Khoảng thời gian, Phòng ban, Nhóm vấn đề. Bấm Xem báo cáo.
4. Client gửi request fetch data -> Server trả về data dạng JSON -> Client render Biểu đồ và Bảng số liệu.
5. Quản lý bấm nút Xuất Báo Cáo (Export) -> Chọn định dạng Excel hoặc CSV.
6. Client gọi API Export -> Server sinh file async/stream -> Trả về link download file.
7. Trình duyệt tự động tải file về máy người dùng.

#### 6. Luồng ngoại lệ & Mã lỗi (Alternative & Error Flows)
- **Không có dữ liệu trong kỳ báo cáo (200 OK Data Empty):** Biểu đồ hiển thị trạng thái Empty State: *"Không có dữ liệu trong khoảng thời gian đã chọn"*. Nút Export bị vô hiệu hóa.
- **Xuất vượt quá 10.000 record (400 Bad Request):** Alert error: *"Dữ liệu xuất vượt quá 10.000 dòng. Vui lòng thu hẹp khoảng thời gian lọc."*

#### 7. Tiêu chí nghiệm thu (Acceptance Criteria)
- **AC-01:** Điểm CSAT trung bình và tỷ lệ % phân bố sao tính toán chính xác theo công thức quy định.
- **AC-02:** Xuất file Excel mở ra đầy đủ các cột dữ liệu, không bị lỗi font Tiếng Việt, định dạng ngày tháng chuẩn `YYYY-MM-DD HH:mm:ss`.
- **AC-03:** Lọc báo cáo theo Phòng Đào Tạo -> Toàn bộ số liệu và danh sách phản hồi chỉ liên quan đến Phòng Đào Tạo.

- **AC-04:** MANAGER xuất báo cáo đã lọc -> File chỉ chứa dữ liệu thuộc phòng ban mình và bộ lọc đang áp dụng, không có dữ liệu phòng ban khác; ADMIN xuất theo phạm vi được chọn trong quyền toàn trường.

---

### [FR-MNG-04] Quản trị người dùng & Phân quyền (User Management & RBAC)

#### 1. Mô tả & Phạm vi
Cung cấp công cụ quản lý toàn bộ tài khoản người dùng trong hệ thống (Tạo mới, Cập nhật thông tin, Khóa/Mở khóa tài khoản, Đổi mật khẩu) và phân quyền chi tiết theo vai trò.

**Luồng thao tác nghiệp vụ:**

1. ADMIN mở danh sách tài khoản, tìm/lọc người dùng theo các điều kiện đã có.
2. Khi cấp tài khoản, ADMIN nhập thông tin bắt buộc, chọn vai trò và gán phòng ban cho STAFF/MANAGER, rồi lưu theo mục 4–5.
3. Tài khoản được cấp được dùng để đăng nhập vào đúng cổng tại FR-STU-01, FR-STF-01 hoặc FR-MNG-01; sinh viên không tự đăng ký tài khoản.
4. Khi khóa tài khoản, ADMIN chọn đúng người dùng và xác nhận; người đó bị vô hiệu hóa phiên theo quy tắc đã có. Trùng thông tin hoặc tự khóa chính mình thì xử lý theo mục 6.

#### 2. Actors & Điều kiện tiên quyết
- **Actor:** CHỈ ADMIN (Quản trị viên hệ thống).
- **Preconditions:** Đăng nhập thành công với vai trò `ADMIN`.

#### 3. Ma trận Phân quyền Vai trò (RBAC Matrix)

| Chức năng / Quyền | STUDENT | STAFF | MANAGER | ADMIN |
| :--- | :---: | :---: | :---: | :---: |
| **Tạo Ticket cá nhân** | X | — | — | — |
| **Xem / Đánh giá Ticket cá nhân** | X | — | — | — |
| **Tiếp nhận / Xử lý Ticket phòng ban** | — | X | X | X |
| **Chuyển phòng ban / Yêu cầu bổ sung** | — | X | X | X |
| **Xem Dashboard & Báo cáo phòng ban** | — | — | X | X |
| **Xem Báo cáo toàn trường** | — | — | — | X |
| **Quản lý Tài khoản & Phân quyền** | — | — | — | X |
| **Xem Audit Log hệ thống** | — | — | — | X |

#### 4. Quy tắc Dữ liệu & Validation Tài khoản (Data Contracts)
- **Tạo Tài khoản mới (Create User):**
  - **Username / Student ID / Staff ID:** Bắt buộc, duy nhất (Unique), 6-20 ký tự, không chứa ký tự đặc biệt.
  - **Email công vụ:** Bắt buộc, duy nhất, đúng định dạng Email (`@aurora.edu.vn`).
  - **Full Name:** Bắt buộc, 2-50 ký tự.
  - **Role:** Dropdown bắt buộc chọn 1 (`STUDENT`, `STAFF`, `MANAGER`, `ADMIN`).
  - **Department:** Bắt buộc chọn nếu Role là `STAFF` hoặc `MANAGER`.
  - **Password:** Độ dài tối thiểu 8 ký tự, gồm ít nhất 1 chữ hoa, 1 chữ thường, 1 số.
- **Trạng thái Tài khoản (Account Status):** `ACTIVE` (Hoạt động), `INACTIVE` (Khóa/Vô hiệu hóa).
- **Quy tắc vô hiệu hóa (Revoke Session):** Khi Admin chuyển trạng thái tài khoản sang `INACTIVE`, hệ thống phải ngay lập tức hủy toàn bộ Active Tokens/Sessions của tài khoản đó. Người dùng bị khóa sẽ bị đẩy văng ra trang Login nếu đang thao tác.

#### 5. Luồng xử lý chi tiết (Flow of Events)
1. Admin truy cập trang Quản lý Tài khoản (`/admin/users`).
2. Hệ thống hiển thị Bảng danh sách người dùng (Phân trang 15 user/trang, có ô Tìm kiếm theo Name/Email/Code, Filter theo Role/Department).
3. **Thao tác Tạo mới:**
   - Admin bấm **+ Tạo tài khoản mới**.
   - Hiển thị Modal nhập thông tin -> Điền dữ liệu -> Bấm Lưu.
   - Server validate trùng lặp Username/Email -> Tạo record -> Trả về HTTP 201 Created.
4. **Thao tác Khóa tài khoản:**
   - Admin chọn 1 user -> Bấm Vô hiệu hóa.
   - Hiển thị Modal xác nhận: *"Bạn có chắc chắn muốn khóa tài khoản [Tên_User]?"*
   - Admin bấm Xác nhận khóa.
   - Server cập nhật `status = INACTIVE`, xóa Redis Session/Token của user đó -> Trả về HTTP 200 OK.

#### 6. Luồng ngoại lệ & Mã lỗi (Alternative & Error Flows)
- **Trùng Username/Email (409 Conflict):** Hiển thị lỗi dưới field tương ứng: *"Username hoặc Email này đã tồn tại trên hệ thống."*
- **Self-Deactivation Prevention (400 Bad Request):** Admin không được phép tự khóa tài khoản chính mình đang đăng nhập. Nếu bấm khóa chính mình -> Alert error: *"Bạn không thể tự vô hiệu hóa tài khoản của chính mình."*

#### 7. Tiêu chí nghiệm thu (Acceptance Criteria)
- **AC-01:** Tạo thành công user role `STAFF` gán cho Phòng Tài chính -> User mới đăng nhập đúng cổng Staff và thấy Queue của Phòng Tài chính.
- **AC-02:** Khóa tài khoản Staff B đang online -> Trong vòng 5 giây, Staff B bị logout ra màn hình Đăng nhập và không thể đăng nhập lại.
- **AC-03:** Nhập Email trùng với user đã có -> Báo lỗi validation 409 rõ ràng, không lưu DB.
- **AC-04:** Tìm kiếm tên "Nguyễn Văn A" -> Bảng kết quả trả về đúng các user có chứa chuỗi tìm kiếm.

- **AC-05:** ADMIN tạo tài khoản vai trò `STUDENT` với thông tin hợp lệ -> Sinh viên dùng tài khoản đó đăng nhập được tại FR-STU-01 và chỉ xem Ticket cá nhân.
- **AC-06:** MANAGER truy cập quản trị tài khoản -> Bị từ chối theo quyền ADMIN-only đã có; quyền quản lý phòng ban không cho phép tạo tài khoản người dùng.

---

### [FR-MNG-05] Ghi nhận Nhật ký Hệ thống (Audit Trail / Activity Log)

#### 1. Mô tả & Phạm vi
Tự động ghi nhận lại toàn bộ các thao tác quản trị quan trọng và sự thay đổi dữ liệu cấu hình hệ thống để phục vụ công tác tra soát, an ninh bảo mật.

**Luồng thao tác nghiệp vụ:**

1. Các thao tác quản trị thuộc danh sách tại mục 3 được tự động ghi vào nhật ký; người dùng không nhập nhật ký thủ công.
2. ADMIN xem nhật ký để xác định ai thực hiện, thao tác gì, trên đối tượng nào, thời điểm và nội dung thay đổi.
3. Nhật ký chỉ phục vụ tra soát; không có thao tác sửa/xóa trên giao diện, giữ nguyên các loại sự kiện và cấu trúc ghi nhận đã có.

#### 2. Actors & Điều kiện tiên quyết
- **Actor:** System / ADMIN.

#### 3. Quy tắc Dữ liệu Audit Log (Audit Specs)
- **CÁC THAO TÁC BẮT BUỘC GHI LOG:**
  - `USER_CREATE`: Tạo tài khoản mới.
  - `USER_UPDATE_ROLE`: Thay đổi quyền/vai trò user.
  - `USER_DISABLE`: Khóa tài khoản.
  - `TICKET_TRANSFER`: Chuyển phòng ban Ticket (Ghi vết người chuyển, phòng ban gốc, phòng ban đích).
  - `TICKET_DELETE` / `FORCE_CLOSE`: Quản lý can thiệp đóng hoặc xóa Ticket.
- **Cấu trúc 1 Record Audit Log:** `log_id`, `actor_id` (Người thực hiện), `actor_ip`, `action_type`, `target_object` (User ID hoặc Ticket ID), `description` (Chi tiết thay đổi Old Value -> New Value), `created_at`.
- **Ràng buộc Toàn vẹn:** Log chỉ được phép ghi mới (Append-Only) và ĐỌC (Read-Only). Tuyệt đối không cho phép bất kỳ ai (kể cả Admin) sửa hoặc xóa các record Audit Log trên giao diện.

#### 4. Tiêu chí nghiệm thu (Acceptance Criteria)
- **AC-01:** Khi Admin đổi role của User X từ `STAFF` sang `MANAGER` -> Bảng Audit Log lập tức xuất hiện 01 record ghi nhận đúng IP, thời gian, người thực hiện và nội dung thay đổi.
- **AC-02:** Giao diện xem Audit Log không có nút Sửa hoặc Xóa.

---

## III. BẢNG MÃ LỖI CHUẨN DÙNG CHUNG PHÂN HỆ MANAGEMENT (SYSTEM ERROR CODES)

| HTTP Status | Error Code | Message hiển thị người dùng | Kịch bản áp dụng |
| :--- | :--- | :--- | :--- |
| **400** | `INVALID_DATE_RANGE` | *"Khoảng thời gian lọc không hợp lệ."* | Ngày bắt đầu lớn hơn ngày kết thúc. |
| **400** | `EXPORT_LIMIT_EXCEEDED` | *"Dữ liệu xuất vượt quá 10.000 dòng. Vui lòng thu hẹp bộ lọc."* | Xuất file quá giới hạn số dòng. |
| **400** | `CANNOT_DISABLE_SELF` | *"Bạn không thể tự vô hiệu hóa tài khoản của chính mình."* | Admin tự khóa chính mình. |
| **401** | `UNAUTHORIZED` | *"Phiên làm việc hết hạn. Vui lòng đăng nhập lại."* | Token hết hạn. |
| **403** | `FORBIDDEN_ADMIN_ONLY` | *"Chức năng này chỉ dành cho Quản trị viên hệ thống (Admin)."* | Manager cố truy cập chức năng Quản lý User. |
| **409** | `USERNAME_EXISTS` | *"Tên đăng nhập / Mã định danh đã tồn tại trên hệ thống."* | Tạo trùng Username/Student ID. |
| **409** | `EMAIL_EXISTS` | *"Địa chỉ Email này đã được đăng ký cho tài khoản khác."* | Tạo trùng Email. |
| **500** | `INTERNAL_SERVER_ERROR` | *"Hệ thống gặp sự cố kỹ thuật. Vui lòng thử lại sau."* | Lỗi Server/Database unhandled. |

## IV. ĐỐI CHIẾU PRD VỚI GIỚI HẠN RESOURCES

**Nguồn ràng buộc:** `Phân bổ Resources.xlsx`, sheet `Resource`. Đơn vị: giờ. Bảng dưới giữ nguyên tên và 11 giá trị giờ của từng dòng nguồn; liên kết tới FR là đối chiếu phạm vi, không phải công việc mới, estimate mới hoặc quyết định phân bổ lại.

| Dòng Resource | Công việc giữ nguyên tên nguồn | BA | UI/UX | TL | FE1 | FE2 | BE1 | BE2 | QA | Cơ sở | Dự phòng | Kế hoạch | Yêu cầu/phạm vi đối chiếu |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| 3 | Tra cứu hướng dẫn & FAQ | 3 | 3 | 0 | 4 | 0 | 0 | 0 | 4 | 14 | 0 | 14 | Tên công việc FAQ chưa có FR riêng; không dùng mã đăng nhập FR-STU-01 để thay thế. |
| 4 | Tạo & gửi yêu cầu hỗ trợ | 5 | 5 | 1 | 10 | 1 | 6 | 1 | 5 | 34 | 3 | 37 | FR-STU-02 |
| 5 | Xem & theo dõi yêu cầu | 4 | 3 | 1 | 8 | 3 | 5 | 3 | 5 | 32 | 1 | 33 | FR-STU-03 |
| 6 | Nhận thông báo trạng thái | 3 | 1 | 0 | 4 | 0 | 4 | 4 | 3 | 19 | 0 | 19 | FR-STU-03; quyền nhận thông báo tại Actors & Roles |
| 7 | Bổ sung thông tin & phản hồi | 3 | 1 | 0 | 5 | 3 | 5 | 3 | 5 | 25 | 0 | 25 | FR-STU-03; phản hồi/đánh giá đã có tại FR-STU-04 (đối chiếu dùng chung, không thêm giờ) |
| 12 | Tiếp nhận, tìm kiếm & lọc yêu cầu | 3 | 3 | 1 | 4 | 5 | 8 | 3 | 6 | 33 | 0 | 33 | FR-STF-02; danh sách Queue tại Actors & Roles |
| 13 | Phân loại & phân công xử lý | 4 | 0 | 3 | 4 | 3 | 9 | 5 | 9 | 37 | 1 | 38 | FR-STF-02; quyền phân công tại Actors & Roles |
| 14 | Quản lý ưu tiên & thời hạn | 4 | 0 | 4 | 3 | 3 | 6 | 3 | 3 | 26 | 3 | 29 | FR-STF-02; FR-MNG-02 |
| 15 | Xử lý & cập nhật yêu cầu | 4 | 1 | 1 | 4 | 4 | 9 | 4 | 9 | 36 | 3 | 39 | FR-STF-04 |
| 16 | Chuyển xử lý, Escalation & hoàn tất | 3 | 0 | 3 | 3 | 3 | 8 | 4 | 5 | 29 | 3 | 32 | FR-STF-03; FR-STF-05; không thêm cấp Escalation mới |
| 17 | Đóng & mở lại yêu cầu | 3 | 0 | 1 | 3 | 3 | 8 | 3 | 5 | 26 | 0 | 26 | Phần đóng tại FR-STF-05/FR-STU-04; mở lại xử lý chưa có đặc tả thống nhất |
| 22 | Quản lý tài khoản, vai trò & RBAC | 5 | 3 | 6 | 3 | 8 | 13 | 9 | 13 | 60 | 4 | 64 | FR-MNG-04; đăng nhập FR-STU-01, FR-STF-01, FR-MNG-01 dùng chung |
| 23 | Quản lý phòng ban & danh mục | 4 | 1 | 3 | 0 | 4 | 5 | 5 | 4 | 26 | 0 | 26 | Danh mục phòng ban/nhóm vấn đề đã có tại Actors & Roles, Terminology |
| 24 | Kiểm soát quyền truy cập & Audit Trail | 4 | 0 | 4 | 1 | 4 | 9 | 5 | 9 | 36 | 4 | 40 | FR-MNG-04; FR-MNG-05; quyền truy cập đã có |
| 25 | Quản lý thời hạn lưu trữ | 3 | 0 | 1 | 0 | 0 | 4 | 4 | 3 | 15 | 0 | 15 | Thời hạn lưu trữ đã có trong Observability; không sửa chính sách kỹ thuật |
| 26 | Dashboard & thống kê quản trị | 4 | 3 | 1 | 0 | 9 | 3 | 9 | 4 | 33 | 0 | 33 | FR-MNG-02 |
| 27 | Báo cáo, mức độ hài lòng & xuất dữ liệu | 4 | 3 | 1 | 0 | 8 | 5 | 10 | 6 | 37 | 0 | 37 | FR-MNG-03; dùng dữ liệu đánh giá FR-STU-04 |
| Tổng 17 dòng | Công sức chức năng | 63 | 27 | 31 | 56 | 61 | 107 | 75 | 98 | 518 | 22 | 540 | Mỗi dòng tính đúng một lần |

- Student: 124 + 4 = 128 giờ; Staff: 187 + 10 = 197 giờ; Admin/Management: 207 + 8 = 215 giờ.
- Chức năng: 518 giờ cơ sở + 22 giờ dự phòng = 540 giờ. PM: 70 giờ (Resource!35); DevOps: 30 giờ (Resource!36). Toàn dự án: 618 giờ cơ sở + 22 giờ dự phòng = 640 giờ.
- Các giới hạn giờ theo vai trò được giữ như nguồn. Dự phòng giữ ở dòng công việc gốc, không tự gán cho người hoặc chuyển sang dòng khác.
- 14 mã FR hiện có giữ nguyên ý nghĩa; số thứ tự 17 dòng Resources không phải mã FR. Ví dụ FR-STU-01 vẫn là đăng nhập, không đổi thành FAQ.

### Các điểm nguồn chưa khớp, không tự biến thành chức năng mới

1. **FAQ (Resource!3, 14 giờ):** Có trong bảng giờ nhưng chưa có FR riêng trong PRD. Giữ nguyên giờ và tên nguồn; bản sửa không viết thêm một chức năng FAQ hay đổi mã đăng nhập.
2. **Đóng & mở lại (Resource!17, 26 giờ):** Giữ nguyên giờ. Xem lại trang Ticket không phải mở lại xử lý; chưa thêm trạng thái, nút hoặc đường chuyển để mở lại Ticket đã đóng.
3. **Phản hồi và CSAT (Resource!7, 25 giờ):** FR-STU-04 đã có từ PRD gốc. Đối chiếu với dòng phản hồi là ghép phạm vi để rà soát, chưa xác nhận thêm effort riêng; không cộng giờ đánh giá lần thứ hai. Resource!27 dành cho báo cáo có sử dụng dữ liệu đó.
4. **RESOLVED/CLOSED:** PRD Staff gốc có nhánh đóng tùy cấu hình, còn WF-05/WF-06 mô tả hoàn tất rồi đóng sau. Bản sửa làm rõ tên thao tác và nhãn hiển thị theo trạng thái thực tế; giữ nguyên các nhánh xử lý kỹ thuật hiện có, không tự chọn một thuật toán đóng thay thế.
5. **Giới hạn file:** Actors & Roles gốc còn ghi 3 file/10MB cho sinh viên, khác PRD Student và BR-13 (5 file/5MB). Bản sửa giữ giới hạn chi tiết trong FR-STU-02 và thông báo của chính chức năng đó; không sửa phần quyền hoặc triển khai kỹ thuật ở tài liệu nguồn khác để che đi sai lệch này.

Các điểm trên là sai lệch giữa tài liệu nguồn được ghi nhận, không phải quyết định thêm phạm vi. Không thêm mã FR, kênh thông báo, thời hạn SLA, chính sách lưu trữ hoặc công sức mới.

# Phân Hệ Quản Lý (M03 - Management Dashboard)

## 1. Tổng Quan
Phân hệ Quản lý cung cấp các công cụ báo cáo trực quan, theo dõi khối lượng công việc và hiệu suất xử lý theo thời gian thực, đồng thời quản trị tài khoản và phân quyền người dùng trong toàn hệ thống UniSupport.

---

## 2. Danh Sách Chức Năng Cốt Lõi
* **[FR-MNG-01]** Đăng nhập tài khoản Quản lý.
* **[FR-MNG-02]** Dashboard tổng quan & Giám sát tiến độ phòng ban.
* **[FR-MNG-03]** Báo cáo thống kê xu hướng, SLA & chỉ số hài lòng.
* **[FR-MNG-04]** Quản trị tài khoản & Phân quyền vai trò người dùng.
# Quy Trình Nghiệp Vụ Tiêu Chuẩn (Workflows & Business Sequences)

## 1. Tổng Quan
Thư mục này tài liệu hóa chi tiết 6 quy trình nghiệp vụ tiêu chuẩn (Standard Workflows) thuộc hệ thống **UniSupport** tại **Aurora University**. Các quy trình đảm bảo tính liên tục, nhất quán dữ liệu giữa 3 vai trò: Sinh viên, Nhân viên các phòng ban và Quản lý.

---

## 2. Danh Sách Quy Trình Nghiệp Vụ

| Mã Workflow | Tên Quy Trình | Vai Trò Chính | Đầu Ra Chính |
| :--- | :--- | :--- | :--- |
| **`WF-01`** | Sinh viên gửi yêu cầu hỗ trợ & Nhận mã Ticket | Sinh viên | Ticket mới (`NEW`) + Mã Ticket duy nhất. |
| **`WF-02`** | Nhân viên tiếp nhận & Phân loại / Đánh giá độ ưu tiên | Nhân viên | Ticket đang xử lý (`IN_PROGRESS`) + Assignee. |
| **`WF-03`** | Yêu cầu sinh viên bổ sung thông tin / giấy tờ | Nhân viên & Sinh viên | Ticket chờ bổ sung (`NEED_MORE_INFO`). |
| **`WF-04`** | Chuyển tiếp yêu cầu sang phòng ban khác | Nhân viên | Ticket chuyển giao (`TRANSFERRED`). |
| **`WF-05`** | Cập nhật kết quả & Đóng yêu cầu | Nhân viên | Ticket hoàn tất (`CLOSED`) + Kết quả giải quyết. |
| **`WF-06`** | Sinh viên nhận kết quả & Đánh giá mức độ hài lòng | Sinh viên | Đánh giá sao & Nhận xét hài lòng. |
# QTTN 01: Quy Trình Sinh Viên Gửi Yêu Cầu Hỗ Trợ & Sinh Mã Ticket (WF-01)

## 1. Mục Tiêu Quy Trình
Mô tả chi tiết luồng tương tác và xử lý kỹ thuật từng bước giữa Client (Web Frontend) và Server (Backend API) khi Sinh viên tạo một yêu cầu hỗ trợ mới. Quy trình đảm bảo tính chính xác của dữ liệu, kiểm tra dung lượng/định dạng file đính kèm, áp dụng cơ chế chống ghi nhận trùng lặp (Idempotency Key / Debounce) và tự động tính toán mốc thời hạn giải quyết SLA.

## 2. Tác Nhân Tham Gia (Actors) & Điều Kiện Tiên Quyết
- **Actors:**
  - **Sinh viên (Student):** Người dùng đã được xác thực, khởi tạo yêu cầu.
  - **Client (Web Frontend):** Giao diện Web Responsive hỗ trợ validate real-time và tạo UUID Idempotency.
  - **Server (Backend API):** Xử lý business logic, upload file, sinh mã Ticket, tính SLA và lưu CSDL.
- **Preconditions:**
  - Sinh viên đã đăng nhập thành công vào cổng UniSupport (Có JWT Access Token hợp lệ).
  - Tài khoản sinh viên ở trạng thái `ACTIVE`.

## 3. Lược Đồ Quy Trình Tương Tác (Sequence Diagram)
```plaintext
[Sinh viên]             [Client Frontend]             [Backend API / Storage]           [Database]
    │                           │                                │                           │
    │ ── 1. Mở Form Tạo Ticket ─>│                                │                           │
    │                           │ ── 2. Sinh UUID Client-ID ────>│                           │
    │                           │ ── 3. Fetch Danh mục Category >│                           │
    │                           │<── 4. Trả về Category List ────│                           │
    │ ── 5. Điền Form & File ──>│                                │                           │
    │ ── 6. Nhấn "Gửi yêu cầu" ─>│                                │                           │
    │                           │ ── 7. Validate Form Realtime ─>│                           │
    │                           │    (Nút Gửi chuyển Loading)    │                           │
    │                           │                                │                           │
    │                           │ ── 8. POST /api/v1/tickets ───>│                           │
    │                           │    Header: Client-Request-ID   │                           │
    │                           │    Body: Form Data + Files     │                           │
    │                           │                                │ ── 9. Check Unique Key ──>│
    │                           │                                │ ── 10. Validate & Upload ─>│
    │                           │                                │ ── 11. Calc SLA (+24h) ───>│
    │                           │                                │ ── 12. Save Ticket (NEW) ─>│
    │                           │<── 13. HTTP 201 Created ───────│                           │
    │                           │    (Mã Ticket: TK-20261009-0001)│                           │
    │<── 14. Hiển thị Toast ────│                                │                           │
    │    & Redirect sang Detail │                                │                           │
```

---

## 4. Các Bước Thực Hiện Chi Tiết (Flow of Events)

### Bước 1: Mở Form Tạo Ticket & Khởi Tạo Ngữ Cảnh
1. Sinh viên nhấn nút **Tạo yêu cầu mới** trên giao diện `/tickets`.
2. Client tự động sinh mã `Client-Request-ID` dạng UUID v4 (Ví dụ: `a1b2c3d4-e5f6-7890-abcd-ef1234567890`) để phục vụ kiểm soát Idempotency Key.
3. Client gọi API `GET /api/v1/categories` để lấy danh sách nhóm vấn đề khả dụng.

### Bước 2: Nhập Thông Tin & Đính Kèm File
1. Sinh viên chọn Nhóm vấn đề (`category_id`) từ Dropdown.
2. Sinh viên nhập Tiêu đề (`title`) và Mô tả chi tiết (`description`).
3. Sinh viên chọn các file đính kèm (nếu có). Client thực hiện kiểm tra sơ bộ:
   - **File extension:** Chỉ chấp nhận `.pdf`, `.png`, `.jpg`, `.jpeg`.
   - **Dung lượng:** $\le 5\text{MB}$ ($5.242.880\text{ Byte}$) mỗi file.
   - **Số lượng:** Tối đa $5\text{ file}$.

### Bước 3: Client Validation & Gửi Request
1. Sinh viên nhấn nút **Gửi yêu cầu**.
2. Client vô hiệu hóa (Disable) nút Gửi yêu cầu, chuyển trạng thái sang Loading (hiển thị Spinner).
3. Client validate toàn bộ trường dữ liệu. Nếu có lỗi, hiển thị thông báo lỗi ngay dưới input tương ứng và ngắt tiến trình.
4. Nếu hợp lệ, Client gửi request `POST /api/v1/tickets` dạng `multipart/form-data` kèm Header `Client-Request-ID`.

### Bước 4: Server Processing & Lưu CSDL
1. **Kiểm tra Idempotency Key:** Server tìm `client_request_id` trong Database hoặc Cache:
   - Nếu đã tồn tại trong vòng $30\text{ giây}$ gần nhất: Từ chối xử lý request mới, trả về thông tin Ticket đã tạo trước đó (HTTP 200 OK / HTTP 409 Conflict).
2. **Validate Phía Server:**
   - Kiểm tra MIME Type thực tế của file (Binary Magic Bytes) để ngăn chặn giả mạo extension.
   - Sanitize chuỗi HTML/Script injection trong `title` và `description`.
   - Thực hiện `trim()` toàn bộ chuỗi đầu vào.
3. **Upload File:** Đẩy các file đính kèm hợp lệ lên Cloud Storage/S3, thu về danh sách `file_id` và `file_url`.
4. **Sinh Mã Ticket:** Sinh mã `ticket_id` theo chuẩn `TK-YYYYMMDD-XXXX` (Sequential number trong ngày).
5. **Tính Toán SLA:**
   - Xác định `department_id` mặc định dựa vào `category_id`.
   - Tính toán `sla_target_at` = Thời điểm hiện tại + $24\text{ giờ làm việc}$ (Loại trừ Thứ 7, Chủ Nhật và Ngày lễ nhà trường).
   - Đặt `sla_status` = `ON_TRACK`.
6. **Lưu CSDL:** Ghi nhận bản ghi Ticket mới với `status` = `NEW`, `assignee_id` = `NULL`, gắn liền với `student_id` từ Token.

### Bước 5: Trả Về Kết Quả
1. Server trả về `HTTP 201 Created` chứa object Ticket hoàn chỉnh.
2. Client nhận phản hồi, hiển thị Toast thông báo: *"Tạo yêu cầu hỗ trợ thành công! Mã Ticket: TK-20261009-0001"*.
3. Client tự động chuyển hướng người dùng sang trang chi tiết Ticket `/tickets/{ticket_id}`.

## 5. Ràng Buộc Kỹ Thuật & Quy Tắc Nghiệp Vụ (Business Rules)

| Tên quy tắc | Mô tả chi tiết & Handling Specs |
| :--- | :--- |
| **Bắt buộc nhập dữ liệu** | `category_id` (Dropdown bắt buộc chọn), `title` ($10 - 150\text{ ký tự}$), `description` ($20 - 2.000\text{ ký tự}$). |
| **Kiểm tra khoảng trắng** | Chuỗi nhập vào chỉ gồm toàn ký tự trắng (space, tab, newline) bị coi là không hợp lệ (`INVALID_INPUT`). |
| **Giới hạn File** | Tối đa $5\text{ file/Ticket}$. Mỗi file $\le 5\text{MB}$. Định dạng MIME Type: `application/pdf`, `image/png`, `image/jpeg`. |
| **Chống gửi trùng (Idempotency)** | Mọi request gửi lên phải kèm `Client-Request-ID`. Nếu trùng Key trong $30\text{ giây}$, Server từ chối ghi nhận record mới. |
| **UI State Control** | Ngay khi bấm Gửi yêu cầu, nút bị Disable và đổi trạng thái Loading. Loại bỏ hoàn toàn khả năng double click từ người dùng. |
| **Mã Ticket duy nhất** | Mã định danh dạng `TK-YYYYMMDD-XXXX` sinh tự động phía Server. `XXXX` là số thứ tự tăng dần từ 0001 mỗi ngày. |
| **Tính thời hạn SLA** | Hạn chót xử lý mặc định là $24\text{ giờ làm việc}$. Hệ thống tự động bỏ qua giờ nghỉ lễ và cuối tuần khi tính `sla_target_at`. |

## 6. Luồng Ngoại Lệ & Mã Lỗi Hệ Thống (Exception & Error Flows)

| Tình huống ngoại lệ | Mã lỗi HTTP & Error Code | Message hiển thị cho Sinh viên | Hành động xử lý của Client |
| :--- | :--- | :--- | :--- |
| **Thiếu thông tin bắt buộc / Nhập toàn space** | `400 Bad Request`<br><br>`INVALID_INPUT` | "Vui lòng điền đầy đủ tiêu đề và nội dung mô tả (tối thiểu 20 ký tự)." | Hiển thị lỗi dưới input field tương ứng, kích hoạt lại nút Gửi. |
| **File quá dung lượng (> 5MB)** | `400 Bad Request`<br><br>`FILE_EXCEEDS_LIMIT` | "File [Tên_File] vượt quá dung lượng cho phép (tối đa 5MB)." | Đánh dấu đỏ file lỗi trong danh sách upload, từ chối gửi request. |
| **File sai định dạng / Giả mạo đuôi file** | `400 Bad Request`<br><br>`FILE_TYPE_NOT_ALLOWED` | "Chỉ chấp nhận file định dạng PDF hoặc hình ảnh (PNG, JPG)." | Loại bỏ file không hợp lệ khỏi danh sách đính kèm. |
| **Mạng lag / Bấm gửi nhiều lần liên tiếp** | `409 Conflict`<br><br>`DUPLICATE_REQUEST` | "Yêu cầu của bạn đang được xử lý. Vui lòng không bấm liên tục." | Client giữ nguyên giao diện Loading, chặn gửi request trùng thứ hai. |
| **Lỗi Server / Storage ngắt kết nối** | `500 Internal Server Error`<br><br>`INTERNAL_SERVER_ERROR` | "Không thể tạo yêu cầu do sự cố hệ thống. Vui lòng thử lại sau." | Báo Toast error, giữ nguyên dữ liệu đã nhập trên Form để người dùng bấm thử lại. |
# QTTN 02: Quy Trình Tiếp Nhận, Phân Loại & Gán Mức Độ Ưu Tiên Ticket (WF-02)

## 1. Mục Tiêu Quy Trình
Mô tả chi tiết luồng xử lý kỹ thuật khi Nhân viên phòng ban (STAFF) duyệt Queue công việc chung, kiểm tra nội dung Ticket mới (`NEW` hoặc `TRANSFERRED`), điều chỉnh lại phân loại nhóm vấn đề (`category_id`) nếu cần, gán độ ưu tiên (`priority`) và thực hiện Tiếp nhận (Claim) Ticket về danh sách cá nhân xử lý. Quy trình đảm bảo giải quyết triệt để tranh chấp dữ liệu (Optimistic Locking / Concurrency Control) khi nhiều nhân viên cùng bấm tiếp nhận 1 Ticket tại một thời điểm.

## 2. Tác Nhân Tham Gia (Actors) & Điều Kiện Tiên Quyết
- **Actors:**
  - **Nhân viên phòng ban (Staff):** Người thực hiện kiểm tra và tiếp nhận Ticket.
  - **Client (Staff Workspace Web App):** Giao diện hiển thị Queue phòng ban, hỗ trợ preview nội dung và form Claim/Triage.
  - **Server (Backend API):** Xác thực Token Staff, xử lý DB Lock/Concurrency, cập nhật trạng thái FSM, lưu Audit Log và phát Notification.
- **Preconditions:**
  - Nhân viên đã đăng nhập cổng Staff, có `role == STAFF` hoặc `MANAGER`.
  - Ticket nằm trong Queue thuộc cùng phòng ban với Nhân viên (`ticket.department_id == staff.department_id`).
  - Ticket đang ở trạng thái `NEW` hoặc `TRANSFERRED` (`assignee_id IS NULL`).

## 3. Lược Đồ Quy Trình Tương Tác (Sequence Diagram)
```plaintext
[Nhân viên]          [Client Web Staff]            [Backend API / CSDL]           [Sinh viên Owner]
    │                        │                               │                            │
    │ ── 1. Mở Queue PB ────>│                               │                            │
    │                        │ ── 2. GET /staff/queue ──────>│                            │
    │                        │<── 3. Trả về Danh sách NEW ───│                            │
    │ ── 4. Chọn 1 Ticket ──>│                               │                            │
    │ ── 5. Bấm "Tiếp nhận" ─>│                               │                            │
    │ ── 6. Chỉnh Category   │                               │                            │
    │    & Priority ────────>│                               │                            │
    │ ── 7. Bấm "Xác nhận" ──>│                               │                            │
    │                        │ ── 8. POST /tickets/{id}/claim │                            │
    │                        │    Body: category, priority   │                            │
    │                        │                               │ ── 9. Atomic DB Lock ─────>│
    │                        │                               │    WHERE status IN         │
    │                        │                               │    ('NEW', 'TRANSFERRED')  │
    │                        │                               │                            │
    │                        │                               │ ── 10. Update Assignee &   │
    │                        │                               │      Status=IN_PROGRESS   │
    │                        │                               │ ── 11. Write Audit Log ────│
    │                        │                               │ ── 12. Push Notification ──>│
    │                        │<── 13. HTTP 200 OK ───────────│                            │
    │<── 14. Toast Success ──│                               │                            │
    │    & Move to My List   │                               │                            │
    │                        │                               │                            │
    │                        │ [Ngoại lệ: Đã bị Claim trước] │                            │
    │                        │<── 15. HTTP 409 Conflict ─────│                            │
    │<── 16. Alert & Reload ─│    (TICKET_ALREADY_CLAIMED)   │                            │
```
---
## 4. Các Bước Thực Hiện Chi Tiết (Flow of Events)

### Bước 1: Truy Cập Queue Chờ Tiếp Nhận (Fetch Department Queue)
1. Nhân viên truy cập Tab "Chờ tiếp nhận" tại `/staff/queue`.
2. Client gọi API `GET /api/v1/staff/tickets?status=NEW,TRANSFERRED&department_id={current_staff_dept}`.
3. Server trả về danh sách Ticket chưa có người phụ trách (`assignee_id IS NULL`), sắp xếp theo thứ tự ưu tiên mặc định và thời gian tạo giảm dần (`created_at DESC`).

### Bước 2: Xem Chi Tiết & Khởi Tạo Form Claim (Preview & Triage)
1. Nhân viên click mở một Ticket cụ thể `/staff/tickets/{ticket_id}`.
2. Màn hình hiển thị chi tiết: Tiêu đề, nội dung mô tả, file đính kèm, danh mục ban đầu do sinh viên chọn (`category_id`) và độ ưu tiên mặc định (`priority = MEDIUM`).
3. Nhân viên bấm nút **Tiếp nhận xử lý**.
4. Khung điều chỉnh thông tin (Triage Modal/Panel) xuất hiện gồm:
   - **Dropdown Phân loại lại nhóm vấn đề (`category_id`):** Mặc định giữ giá trị cũ, cho phép chọn lại nhóm vấn đề khác thuộc cùng phòng ban.
   - **Radio buttons Độ ưu tiên (`priority`):** Cho phép chọn 1 trong 4 mức (`LOW`, `MEDIUM`, `HIGH`, `URGENT`).

### Bước 3: Submit Request & Xử Lý Tranh Chấp (Atomic Claim Processing)
1. Nhân viên nhấn **Xác nhận tiếp nhận**. Client vô hiệu hóa nút bấm và chuyển trạng thái Loading.
2. Client gửi request `POST /api/v1/staff/tickets/{ticket_id}/claim` kèm body `{ category_id, priority }`.
3. Thao tác Atomic Update tại Server:
   - Server xác thực Bearer Token: Bắt buộc `user.role IN ('STAFF', 'MANAGER')` và `user.department_id == ticket.department_id`.
   - Server thực hiện câu lệnh Update chống tranh chấp (Optimistic Locking / Conditional Update):
     `UPDATE tickets SET status = 'IN_PROGRESS', assignee_id = {current_staff_id}, category_id = {new_category_id}, priority = {new_priority}, updated_at = CURRENT_TIMESTAMP WHERE ticket_id = {ticket_id} AND status IN ('NEW', 'TRANSFERRED') AND assignee_id IS NULL;`
4. Kiểm tra kết quả Update:
   - **Thành công (Số bản ghi updated == 1):**
     - Ghi 01 bản ghi Audit Log vào `ticket_histories`: `action = CLAIM`, `performer_id = staff_id`, `details = { priority, category_id }`.
     - Phát Notification cho Sinh viên chủ sở hữu: "Yêu cầu [Mã_Ticket] của bạn đã được tiếp nhận bởi nhân viên [Tên_Staff] thuộc [Tên_Phòng_Ban]".
     - Trả về `HTTP 200 OK` chứa object Ticket đã cập nhật.
   - **Thất bại (Số bản ghi updated == 0 - Đã bị người khác Claim trước):**
     - Trả về mã lỗi `HTTP 409 Conflict` kèm Error Code `TICKET_ALREADY_CLAIMED`.

### Bước 4: Cập Nhật Giao Diện Client
1. **Trường hợp thành công (200 OK):**
   - Client hiển thị Toast success: "Tiếp nhận Ticket [Mã_Ticket] thành công!".
   - Ticket tự động chuyển từ Queue chung sang Tab "Ticket của tôi" (`/staff/my-tickets`).
   - Khung thao tác xử lý nghiệp vụ (Cập nhật tiến độ, Yêu cầu bổ sung, Hoàn tất) được kích hoạt cho Nhân viên.
2. **Trường hợp thất bại (409 Conflict):**
   - Client hiển thị Alert lỗi: "Ticket này đã được tiếp nhận xử lý bởi nhân viên [Tên_Staff_Đã_Claim] trước đó ít giây.".
   - Client tự động đóng Modal và reload lại danh sách Queue phòng ban để loại bỏ Ticket đã bị Claim khỏi giao diện.

## 5. Ràng Buộc Kỹ Thuật & Quy Tắc Nghiệp Vụ (Business Rules)

| Tên quy tắc | Mô tả chi tiết & Handling Specs |
| :--- | :--- |
| **Phân quyền Phòng ban** | Nhân viên phòng ban A tuyệt đối **KHÔNG ĐƯỢC** bấm Claim Ticket thuộc phòng ban B. Server bắt buộc verify `staff.department_id == ticket.department_id`. |
| **Ràng buộc Trạng thái FSM** | Chỉ cho phép Claim khi Ticket đang ở trạng thái `NEW` hoặc `TRANSFERRED`. Không cho phép Claim các Ticket đang ở `IN_PROGRESS`, `NEED_MORE_INFO`, `RESOLVED`, `CLOSED`. |
| **Chống Tranh Chấp (Concurrency Control)** | Phải sử dụng Atomic Condition Update ở CSDL để đảm bảo khi 10 Staff bấm Claim cùng 1 millisecond, đúng 01 Staff nhận thành công, 9 Staff còn lại nhận lỗi `409 Conflict`. |
| **Gán Phụ Trách (Assignee Assignment)** | Ngay sau khi Claim thành công, `assignee_id` bắt buộc phải lưu chính xác `user_id` của Nhân viên đang thực hiện request. |
| **Giá trị Mặc định Priority** | Nếu Nhân viên không chọn lại `priority`, hệ thống mặc định lưu `priority = MEDIUM`. Các giá trị hợp lệ: `LOW`, `MEDIUM`, `HIGH`, `URGENT`. |
| **Ghi vết Audit Trail** | Thao tác Claim là điểm mốc quan trọng, phải lưu timestamp `claimed_at` và tạo 1 record trong lịch sử trao đổi/biến động của Ticket. |

## 6. Luồng Ngoại Lệ & Mã Lỗi Hệ Thống (Exception & Error Flows)

| Tình huống ngoại lệ | Mã lỗi HTTP & Error Code | Message hiển thị cho Nhân viên | Hành động xử lý của Client |
| :--- | :--- | :--- | :--- |
| **Tranh chấp tiếp nhận (Đã bị Staff khác claim)** | `409 Conflict`<br><br>`TICKET_ALREADY_CLAIMED` | "Ticket này đã được tiếp nhận bởi nhân viên khác trước đó ít giây." | Hiển thị Alert error, tự động reload lại Queue để cập nhật UI. |
| **Claim Ticket phòng ban khác** | `403 Forbidden`<br><br>`FORBIDDEN_DEPARTMENT_ACCESS` | "Bạn không có quyền tiếp nhận Ticket của phòng ban khác." | Hiển thị Toast error, chặn thao tác Claim. |
| **Ticket đã bị đóng hoặc hủy từ trước** | `400 Bad Request`<br><br>`INVALID_TICKET_STATE` | "Ticket không còn ở trạng thái chờ tiếp nhận." | Reload lại chi tiết Ticket. |
| **Gửi Category ID không tồn tại** | `400 Bad Request`<br><br>`INVALID_INPUT` | "Nhóm vấn đề được chọn không hợp lệ." | Báo lỗi validation trên Form Triage. |
| **Phiên làm việc hết hạn** | `401 Unauthorized`<br><br>`UNAUTHORIZED` | "Phiên làm việc đã hết hạn. Vui lòng đăng nhập lại." | Điều hướng về trang `/staff/login`. |
# QTTN 03: Quy Trình Yêu Cầu & Bổ Sung Thông Tin/Giấy Tờ (WF-03)

## 1. Mục Tiêu Quy Trình
Mô tả chi tiết luồng xử lý kỹ thuật hai chiều giữa Nhân viên và Sinh viên khi Ticket thiếu thông tin, sai hồ sơ hoặc cần bổ sung giấy tờ minh chứng. Quy trình đảm bảo tính toàn vẹn của State Machine (chuyển đổi tự động giữa `IN_PROGRESS` và `NEED_MORE_INFO`), đồng bộ thời gian thực qua Notification, kiểm soát dung lượng/định dạng file bổ sung và ghi vết toàn bộ lịch sử tương tác vào Conversation Log.

## 2. Tác Nhân Tham Gia (Actors) & Điều Kiện Tiên Quyết
- **Actors:**
  - **Nhân viên phụ trách (Staff Assignee):** Người phát yêu cầu bổ sung.
  - **Sinh viên sở hữu Ticket (Student Owner):** Người nhận thông báo và upload hồ sơ bổ sung.
  - **Client (Web App):** Giao diện xử lý hiển thị form động theo trạng thái Ticket.
  - **Server (Backend API):** Kiểm tra quyền hạn, validate file, chuyển đổi trạng thái FSM, lưu Conversation Log và phát Notification.
- **Preconditions:**
  - Ticket đang ở trạng thái `IN_PROGRESS`.
  - Nhân viên thực hiện thao tác phải đúng là người đang phụ trách Ticket (`assignee_id == current_user_id`).

## 3. Lược Đồ Quy Trình Tương Tác (Sequence Diagram)
```plaintext
[Nhân viên]          [Client Web]              [Backend API / Storage]            [Sinh viên]
    │                     │                               │                            │
    │ ── 1. Yêu cầu BS ──>│                               │                            │
    │ ── 2. Nhập ghi chú ─>│                               │                            │
    │ ── 3. Bấm Gửi ─────>│                               │                            │
    │                     │ ── 4. POST /request-more ────>│                            │
    │                     │    (Check status IN_PROGRESS) │                            │
    │                     │                               │ ── 5. Set NEED_MORE_INFO ──>│
    │                     │                               │ ── 6. Save Conversation ──>│
    │                     │                               │ ── 7. Push Notification ──>│
    │<── 8. HTTP 200 OK ──│                               │                            │
    │                     │                               │                            │
    │                     │                               │<── 9. Nhận Thông Báo ──────│
    │                     │                               │ ── 10. Mở Ticket Detail ──>│
    │                     │                               │ ── 11. Upload File + Note ─>│
    │                     │                               │ ── 12. Bấm Gửi bổ sung ────│
    │                     │                               │                            │
    │                     │                               │ ── 13. POST /supplement ──>│
    │                     │                               │    (Check NEED_MORE_INFO)  │
    │                     │                               │ ── 14. Set IN_PROGRESS ────│
    │                     │                               │ ── 15. Save Files & Log ───│
    │                     │                               │ ── 16. Push Notify Staff ──>│
    │                     │                               │<── 17. HTTP 200 OK ────────│
    │<── 18. Notify Web ──│                               │                            │
```
---
## 4. Các Bước Thực Hiện Chi Tiết (Flow of Events)

### Nhánh 1: Nhân viên phát yêu cầu bổ sung thông tin (Staff Request)
1. **Mở Modal Yêu cầu:** Tại trang chi tiết Ticket `/staff/tickets/{ticket_id}`, Nhân viên bấm nút **Yêu cầu bổ sung hồ sơ** (Nút này chỉ xuất hiện khi `status == IN_PROGRESS` và `assignee_id == current_staff_id`).
2. **Nhập Nội dung:** Nhân viên nhập chi tiết các giấy tờ/thông tin cần Sinh viên giải trình hoặc đính kèm thêm vào Textarea (`request_note`).
3. **Client Validation:**
   - Đảm bảo `request_note` không để trống và có độ dài từ $10 - 1.000\text{ ký tự}$ sau khi `trim()`.
4. **Gửi Request:** Client gửi request `POST /api/v1/staff/tickets/{ticket_id}/request-more-info`.
5. **Server Processing:**
   - Xác thực Token Staff và kiểm tra quyền phụ trách (`assignee_id`).
   - Kiểm tra trạng thái hiện tại: Nếu `status != IN_PROGRESS`, trả về lỗi `400 INVALID_TICKET_STATE`.
   - Cập nhật trạng thái Ticket: `status = NEED_MORE_INFO`.
   - Ghi nhận 1 bản ghi vào bảng `ticket_conversations`: `sender_role = STAFF`, `message_type = PUBLIC_MESSAGE`, `message_text = request_note`.
   - Phát Notification (In-app Bell / Email) cho Sinh viên sở hữu Ticket.
6. **Cập nhật UI Staff:** Modal đóng, hiển thị Toast success: "Đã gửi yêu cầu bổ sung tới sinh viên", Badge trạng thái Ticket đổi sang `NEED_MORE_INFO`.

### Nhánh 2: Sinh viên thực hiện bổ sung hồ sơ (Student Supplement)
1. **Tiếp nhận Thông báo:** Sinh viên nhận Notification, click mở trang chi tiết Ticket `/tickets/{ticket_id}`.
2. **Hiển thị Form Bổ sung:**
   - Hệ thống phát hiện `status == NEED_MORE_INFO`, tự động mở Khung Bổ sung thông tin kèm hộp thông điệp yêu cầu từ Nhân viên.
   - Các trường thông tin ban đầu (`title`, `category_id`) ở trạng thái Read-Only (Không cho sửa).
3. **Tải File & Nhập Ghi chú:**
   - Sinh viên nhập lời nhắn giải trình bổ sung (`supplement_note` Optional, max $1.000\text{ ký tự}$).
   - Sinh viên kéo thả/chọn file đính kèm bổ sung (Tối đa $5\text{ file}$, dung lượng $\le 5\text{MB/file}$, định dạng `.pdf`, `.png`, `.jpg`, `.jpeg`).
4. **Submit Request:** Sinh viên bấm Xác nhận gửi bổ sung. Client chuyển nút sang Loading để chống double-click.
5. **Server Processing:**
   - Xác thực Token Sinh viên (`student_id == ticket.student_id`).
   - Kiểm tra trạng thái Ticket: Bắt buộc `status == NEED_MORE_INFO`. Nếu trạng thái đã bị đổi (ví dụ: Staff đã hủy/đóng), trả về `400 INVALID_TICKET_STATE`.
   - Validate và Upload các file đính kèm bổ sung lên S3/Storage.
   - Tự động chuyển đổi trạng thái FSM: Cập nhật `status = IN_PROGRESS`.
   - Ghi bản ghi vào `ticket_conversations`: `sender_role = STUDENT`, `message_text = supplement_note`, `attachments = new_files_list`.
   - Phát Notification báo cho Nhân viên phụ trách: "Sinh viên [Tên_SV] đã nộp bổ sung hồ sơ cho Ticket [Mã_Ticket]".
6. **Cập nhật UI Student:** Hiển thị Toast thành công: "Đã gửi hồ sơ bổ sung thành công!". Form bổ sung tự động ẩn/khóa, Badge trạng thái cập nhật thành `IN_PROGRESS`.

## 5. Ràng Buộc Kỹ Thuật & Quy Tắc Nghiệp Vụ (Business Rules)

| Tên quy tắc | Mô tả chi tiết & Handling Specs |
| :--- | :--- |
| **Ràng buộc Quyền thao tác** | Chỉ Nhân viên đang phụ trách trực tiếp (`assignee_id`) mới có quyền phát yêu cầu bổ sung. Chỉ Sinh viên chủ sở hữu (`student_id`) mới có quyền nộp bổ sung. |
| **Giao diện động (Dynamic UI)** | Khung upload file bổ sung **CHỈ** hiển thị phía Sinh viên khi `status == NEED_MORE_INFO`. Khi Ticket ở trạng thái khác, khu vực này hoàn toàn bị ẩn hoặc khóa. |
| **Không cho sửa nội dung gốc** | Trong suốt quá trình bổ sung, Sinh viên **KHÔNG ĐƯỢC PHÉP** chỉnh sửa `title`, `description` hoặc `category_id` đã khởi tạo ban đầu. |
| **Quy tắc File bổ sung** | Tối đa $5\text{ file}$ cho mỗi lần gửi bổ sung. Dung lượng $\le 5\text{MB/file}$. Định dạng MIME: `application/pdf`, `image/png`, `image/jpeg`. |
| **Chuyển đổi trạng thái tự động** | Ngay sau khi Sinh viên bấm Xác nhận gửi bổ sung thành công, Backend phải tự động đổi `status` từ `NEED_MORE_INFO` $\rightarrow$ `IN_PROGRESS` mà không cần thao tác thủ công của Nhân viên. |
| **Lưu vết Conversation Log** | Toàn bộ lời nhắn yêu cầu của Staff và file/ghi chú bổ sung của Student phải được lưu vào bảng `ticket_conversations` theo đúng thứ tự thời gian (`created_at ASC`). |

## 6. Luồng Ngoại Lệ & Mã Lỗi Hệ Thống (Exception & Error Flows)

| Tình huống ngoại lệ | Mã lỗi HTTP & Error Code | Message hiển thị cho người dùng | Hành động xử lý của Client |
| :--- | :--- | :--- | :--- |
| **Nhân viên để trống ghi chú yêu cầu** | `400 Bad Request`<br><br>`INVALID_INPUT` | "Vui lòng nhập nội dung chi tiết cần sinh viên bổ sung (tối thiểu 10 ký tự)." | Hiển thị lỗi dưới Textarea của Modal Staff, giữ nguyên dữ liệu. |
| **Thao tác sai trạng thái FSM** | `400 Bad Request`<br><br>`INVALID_TICKET_STATE` | "Trạng thái Ticket đã thay đổi. Không thể thực hiện thao tác này." | Tự động reload lại dữ liệu Ticket để cập nhật UI mới nhất. |
| **Sinh viên gửi bổ sung nhưng không có file & note** | `400 Bad Request`<br><br>`INVALID_INPUT` | "Vui lòng tải lên ít nhất 01 file đính kèm hoặc nhập lời nhắn bổ sung." | Báo lỗi validation trên Form của Sinh viên, không phát request. |
| **Upload file bổ sung sai định dạng/quá 5MB** | `400 Bad Request`<br><br>`FILE_EXCEEDS_LIMIT` | "File [Tên_File] vượt quá 5MB hoặc không đúng định dạng (.pdf, .png, .jpg)." | Đánh dấu đỏ file lỗi, ngăn thao tác submit. |
| **Staff không có quyền phụ trách Ticket** | `403 Forbidden`<br><br>`FORBIDDEN_ACCESS` | "Bạn không phải là người phụ trách xử lý Ticket này." | Vô hiệu hóa nút bấm trên giao diện Staff. |
# QTTN 04: Quy Trình Chuyển Tiếp Yêu Cầu Sang Phòng Ban Khác (WF-04)

## 1. Mục Tiêu Quy Trình
Mô tả chi tiết luồng xử lý kỹ thuật khi Nhân viên phòng ban (STAFF) hoặc Quản lý (MANAGER) phát hiện Ticket bị gửi nhầm đơn vị hoặc vượt quá thẩm quyền xử lý, cần điều chuyển sang đúng Phòng ban chuyên trách. Quy trình đảm bảo tính toàn vẹn của máy trạng thái FSM (chuyển sang `TRANSFERRED`, xóa `assignee_id` để đưa về Queue chờ của phòng ban mới), bắt buộc ghi vết Audit Trail chi tiết và gửi Notification cảnh báo thời gian thực tới phòng ban tiếp nhận.

## 2. Tác Nhân Tham Gia (Actors) & Điều Kiện Tiên Quyết
- **Actors:**
  - **Nhân viên phòng ban hiện tại (Staff Transferor):** Người khởi tạo thao tác điều chuyển.
  - **Phòng ban tiếp nhận mới (Target Department):** Đơn vị thụ lý mới.
  - **Client (Staff Web App):** Giao diện Modal chuyển phòng ban kèm validation real-time.
  - **Server (Backend API):** Verify quyền hạn, kiểm tra FSM state, cập nhật CSDL, lưu Audit Log và bắn Notification.
- **Preconditions:**
  - Ticket chưa ở trạng thái kết thúc (`status NOT IN ('RESOLVED', 'CLOSED', 'REJECTED')`).
  - Nhân viên thực hiện thuộc phòng ban đang thụ lý Ticket (`staff.department_id == ticket.department_id`) hoặc đúng là người đang phụ trách (`assignee_id == staff.id`).

## 3. Lược Đồ Quy Trình Tương Tác (Sequence Diagram)
```plaintext
[Staff PB Hiện Tại]     [Client Web Staff]            [Backend API / CSDL]         [Queue PB Mới]
        │                       │                              │                         │
        │ ── 1. Chuyển phòng ──>│                              │                         │
        │ ── 2. Chọn PB Đích ──>│                              │                         │
        │ ── 3. Nhập Lý do ────>│                              │                         │
        │ ── 4. Bấm "Xác nhận" ─>│                              │                         │
        │                       │ ── 5. POST /transfer ───────>│                         │
        │                       │    Body: target_dept, reason │                         │
        │                       │                              │ ── 6. Check FSM State ──>│
        │                       │                              │ ── 7. Check Dept ID ────>│
        │                       │                              │                          │
        │                       │                              │ ── 8. UPDATE Ticket ────>│
        │                       │                              │    - dept = target_dept │
        │                       │                              │    - status = TRANSFERRED│
        │                       │                              │    - assignee = NULL     │
        │                       │                              │                          │
        │                       │                              │ ── 9. Write Audit Log ──>│
        │                       │                              │ ── 10. Push Notify PB ──>│
        │                       │<── 11. HTTP 200 OK ──────────│                         │
        │<── 12. Toast Success ─│                              │                         │
        │    & Redirect Queue   │                              │                         │
        │                       │                              │                         │
        │                       │                              │<── 13. Nhận Notify ─────│
        │                       │                              │    & Hiển thị Queue     │
```
---
## 4. Các Bước Thực Hiện Chi Tiết (Flow of Events)

### Bước 1: Mở Modal Chuyển Phòng Ban
1. Tại trang chi tiết Ticket `/staff/tickets/{ticket_id}`, Nhân viên bấm nút **Chuyển phòng ban** (Nút này ẩn khi `status IN ('RESOLVED', 'CLOSED', 'REJECTED')`).
2. Client hiển thị Modal Chuyển tiếp yêu cầu liên phòng ban:
   - **Dropdown Phòng ban đích (`target_department_id`):** Danh sách các phòng ban khả dụng trong hệ thống (Đã vô hiệu hóa / Loại bỏ phòng ban hiện tại của Ticket).
   - **Textarea Lý do chuyển tiếp (`transfer_reason`):** Bắt buộc nhập, độ dài từ $10 - 500\text{ ký tự}$.

### Bước 2: Client Validation & Submit Request
1. Nhân viên chọn Phòng ban đích, nhập lý do điều chuyển và bấm **Xác nhận chuyển**.
2. Client thực hiện validate:
   - Bắt buộc phải chọn `target_department_id`.
   - `transfer_reason` sau khi `trim()` phải có độ dài $\ge 10\text{ ký tự}$.
3. Nếu hợp lệ, Client vô hiệu hóa nút bấm, chuyển trạng thái Loading và gửi request `POST /api/v1/staff/tickets/{ticket_id}/transfer`.

### Bước 3: Server Processing & Database Update
1. **Xác thực & Kiểm tra Quyền:**
   - Verify Bearer Token: User phải có role `STAFF` hoặc `MANAGER`.
   - Kiểm tra phòng ban: User phải thuộc phòng ban đang giữ Ticket.
   - Kiểm tra trạng thái Ticket: Nếu `status IN ('RESOLVED', 'CLOSED', 'REJECTED')`, trả về lỗi `400 INVALID_TICKET_STATE`.
   - Kiểm tra `target_department_id`: Phải tồn tại và khác với `ticket.department_id` hiện tại.
2. **Cập nhật Bản ghi Ticket (Atomic Transaction):**
   - Cập nhật phòng ban thụ lý mới: `department_id = target_department_id`.
   - Cập nhật trạng thái FSM: `status = TRANSFERRED`.
   - Xóa thông tin phụ trách cũ: `assignee_id = NULL` (Đẩy Ticket về dạng chờ tiếp nhận tại Phòng ban mới).
   - Cập nhật timestamp: `updated_at = CURRENT_TIMESTAMP`.
3. **Ghi vết Audit Log (Bắt buộc):**
   - Lưu 01 bản ghi vào bảng `ticket_histories`:
     - `action = TRANSFER`
     - `from_department_id = old_dept_id`
     - `to_department_id = target_department_id`
     - `performed_by = current_staff_id`
     - `reason_note = transfer_reason`
4. **Phát Thông Báo (Push Notification):**
   - Bắn thông báo thời gian thực (In-app WebSocket / Bell Notification) tới Queue công việc chung của Phòng ban mới: "Có 01 Ticket [Mã_Ticket] được chuyển đến từ [Tên_PB_Cũ]. Lý do: [Lý_do]".
   - Bắn thông báo cập nhật cho Sinh viên chủ sở hữu: "Yêu cầu [Mã_Ticket] của bạn đã được chuyển đến [Tên_PB_Mới] để xử lý".

### Bước 4: Cập Nhật Giao Diện Client
1. Server trả về `HTTP 200 OK`.
2. Client tại phía Staff cũ:
   - Hiển thị Toast success: "Đã chuyển Ticket [Mã_Ticket] sang [Tên_PB_Mới] thành công!".
   - Tự động đóng Modal và điều hướng Nhân viên về trang Danh sách công việc `/staff/dashboard`.
3. Tại phía Staff Phòng ban mới:
   - Ticket xuất hiện trong Tab "Ticket chờ tiếp nhận" (`/staff/queue`) với Badge màu vàng đại diện cho trạng thái `TRANSFERRED`.
   - Nhân viên phòng ban mới thực hiện tiếp nhận xử lý theo quy trình WF-02.

## 5. Ràng Buộc Kỹ Thuật & Quy Tắc Nghiệp Vụ (Business Rules)

| Tên quy tắc | Mô tả chi tiết & Handling Specs |
| :--- | :--- |
| **Bắt buộc Lý do chuyển** | `transfer_reason` bắt buộc nhập, độ dài từ $10 - 500\text{ ký tự}$ sau khi `trim()`. Không chấp nhận chuỗi chỉ chứa khoảng trắng. |
| **Phòng ban đích hợp lệ** | `target_department_id` phải khác hoàn toàn với `department_id` hiện tại của Ticket. Vô hiệu hóa Option phòng ban hiện tại trong Dropdown phía UI. |
| **Xóa Assignee cũ** | Ngay khi chuyển phòng ban thành công, `assignee_id` **BẮT BUỘC** phải đưa về `NULL` để Nhân viên cũ không còn quyền thao tác và đưa Ticket vào Queue chờ của Phòng ban mới. |
| **Trạng thái FSM TRANSFERRED** | Trạng thái Ticket đổi sang `TRANSFERRED`. Ticket ở `TRANSFERRED` có hành vi tương tự `NEW` (Nằm trong Queue chung chờ bấm Claim). |
| **Bảo lưu SLA & Lịch sử** | Mốc thời gian `sla_target_at` và toàn bộ Lịch sử trao đổi/File đính kèm cũ **ĐƯỢC GIỮ NGUYÊN** không bị thay đổi hay xóa bỏ. |
| **Ghi vết Audit Trail** | Mọi lượt chuyển phòng ban bắt buộc ghi 1 bản ghi lịch sử cố định vào `ticket_histories` phục vụ tra soát/kiểm toán chất lượng vận hành của Admin. |

## 6. Luồng Ngoại Lệ & Mã Lỗi Hệ Thống (Exception & Error Flows)

| Tình huống ngoại lệ | Mã lỗi HTTP & Error Code | Message hiển thị cho Nhân viên | Hành động xử lý của Client |
| :--- | :--- | :--- | :--- |
| **Bỏ trống lý do / Lý do quá ngắn** | `400 Bad Request`<br><br>`MISSING_TRANSFER_REASON` | "Vui lòng nhập lý do chuyển phòng ban (tối thiểu 10 ký tự)." | Hiển thị lỗi dưới Textarea của Modal, giữ nguyên dữ liệu. |
| **Chọn trùng phòng ban hiện tại** | `400 Bad Request`<br><br>`INVALID_TARGET_DEPARTMENT` | "Phòng ban đích phải khác với phòng ban hiện tại của Ticket." | Vô hiệu hóa lựa chọn trùng trên Dropdown UI. |
| **Ticket đã bị đóng hoặc hoàn thành** | `400 Bad Request`<br><br>`INVALID_TICKET_STATE` | "Ticket đã đóng hoặc hoàn thành, không thể chuyển phòng ban." | Ẩn nút Chuyển phòng ban, reload lại Ticket detail. |
| **Staff không thuộc phòng ban thụ lý** | `403 Forbidden`<br><br>`FORBIDDEN_DEPARTMENT_ACCESS` | "Bạn không có quyền chuyển Ticket của phòng ban khác." | Hiển thị Toast error, chặn gửi request. |
| **Lỗi Server / Database Transaction** | `500 Internal Server Error`<br><br>`INTERNAL_SERVER_ERROR` | "Không thể chuyển phòng ban do sự cố hệ thống. Vui lòng thử lại." | Hiển thị Toast error, giữ nguyên trạng thái Form để thử lại. |
# QTTN 05: Quy Trình Cập Nhật Kết Quả & Hoàn Tất Xử Lý Ticket (WF-05)

## 1. Mục Tiêu Quy Trình
Mô tả chi tiết luồng xử lý kỹ thuật khi Nhân viên phụ trách (STAFF Assignee) hoàn thành các thao tác nghiệp vụ chuyên môn và ghi nhận kết quả phản hồi chính thức cho Sinh viên. Quy trình kiểm soát chặt chẽ máy trạng thái FSM (chuyển sang `RESOLVED`, kích hoạt bộ đếm thời gian tự động đóng `closed_at` sau 3 ngày), ràng buộc nhập dữ liệu kết quả giải quyết (`resolution_note`), cho phép đính kèm file kết quả và gửi thông báo thời gian thực tới Sinh viên.

## 2. Tác Nhân Tham Gia (Actors) & Điều Kiện Tiên Quyết
- **Actors:**
  - **Nhân viên phụ trách (Staff Assignee):** Người nhập kết quả và hoàn tất xử lý.
  - **Sinh viên chủ sở hữu (Student Owner):** Người nhận thông báo kết quả và kiểm tra lời giải quyết.
  - **Client (Staff Web App):** Giao diện Modal nhập kết quả giải quyết kèm upload file đính kèm phản hồi.
  - **Server (Backend API):** Verify quyền hạn, kiểm tra FSM state, lưu kết quả, cập nhật timestamp `resolved_at`, phát Notification và khởi chạy bộ đếm Auto-close.
- **Preconditions:**
  - Ticket đang ở trạng thái `IN_PROGRESS`.
  - Nhân viên thực hiện bắt buộc phải đúng là người đang phụ trách Ticket (`assignee_id == current_staff_id`).

## 3. Lược Đồ Quy Trình Tương Tác (Sequence Diagram)
```plaintext
[Staff Assignee]        [Client Web Staff]            [Backend API / Storage]          [Sinh viên Owner]
       │                        │                               │                            │
       │ ── 1. Bấm "Hoàn thành"─>│                               │                            │
       │ ── 2. Nhập Note & File>│                               │                            │
       │ ── 3. Bấm "Xác nhận" ─>│                               │                            │
       │                        │ ── 4. POST /resolve ─────────>│                            │
       │                        │    Body: note, attachments    │                            │
       │                        │                               │ ── 5. Verify Assignee ────>│
       │                        │                               │ ── 6. Check IN_PROGRESS ──>│
       │                        │                               │                            │
       │                        │                               │ ── 7. Save Note & Files ──>│
       │                        │                               │ ── 8. Set STATUS=RESOLVED ─>│
       │                        │                               │ ── 9. Set resolved_at ────>│
       │                        │                               │ ── 10. Push Notification ─>│
       │                        │<── 11. HTTP 200 OK ───────────│                            │
       │<── 12. Toast Success ──│                               │                            │
       │    & Lock UI Controls  │                               │                            │
       │                        │                               │                            │
       │                        │                               │<── 13. Nhận Thông Báo ─────│
       │                        │                               │    & Xem kết quả giải quyết│
```
---
## 4. Các Bước Thực Hiện Chi Tiết (Flow of Events)

### Bước 1: Mở Modal Hoàn Tất Xử Lý
1. Tại trang chi tiết Ticket `/staff/tickets/{ticket_id}`, Nhân viên bấm nút **Hoàn thành & Đóng Ticket** (Nút này chỉ hiển thị khi `status == IN_PROGRESS` và `assignee_id == current_staff_id`).
2. Client hiển thị Modal Ghi nhận kết quả giải quyết:
   - **Textarea Nội dung kết quả giải quyết (`resolution_note`):** Bắt buộc nhập, độ dài từ $20 - 2.000\text{ ký tự}$.
   - **Khung upload File đính kèm kết quả (`resolution_attachments`):** Không bắt buộc (Optional), tối đa $3\text{ file}$, dung lượng $\le 5\text{MB/file}$, định dạng `.pdf`, `.png`, `.jpg`, `.jpeg`.

### Bước 2: Client Validation & Submit Request
1. Nhân viên nhập chi tiết câu trả lời/phương án xử lý, đính kèm file văn bản kết quả (nếu có) và bấm **Xác nhận hoàn tất**.
2. Client thực hiện validate:
   - `resolution_note` sau khi `trim()` bắt buộc có độ dài $\ge 20\text{ ký tự}$.
   - Kiểm tra định dạng và dung lượng danh sách file đính kèm (nếu có).
3. Nếu hợp lệ, Client vô hiệu hóa nút bấm, chuyển trạng thái Loading và gửi request `POST /api/v1/staff/tickets/{ticket_id}/resolve`.

### Bước 3: Server Processing & Database Update
1. **Xác thực & Kiểm tra Quyền:**
   - Verify Bearer Token: User phải là Nhân viên đang trực tiếp phụ trách Ticket (`assignee_id == current_staff_id`).
   - Kiểm tra trạng thái FSM: Bắt buộc `status == IN_PROGRESS`. Nếu Ticket đang ở trạng thái khác, trả về mã lỗi `400 INVALID_TICKET_STATE`.
2. **Upload File Kết Quả (nếu có):**
   - Read Magic Bytes xác thực định dạng file thực tế.
   - Lưu file lên Storage/S3, sinh mảng `resolution_attachments` chứa metadata file.
3. **Cập nhật Bản ghi Ticket (Atomic Transaction):**
   - Lưu câu trả lời: `resolution_note = trim(request.resolution_note)`.
   - Lưu danh sách file: `resolution_attachments = request.attachments`.
   - Chuyển đổi trạng thái FSM: `status = RESOLVED`.
   - Cập nhật timestamp: `resolved_at = CURRENT_TIMESTAMP`, `updated_at = CURRENT_TIMESTAMP`.
4. **Ghi vết Audit Trail:**
   - Ghi 01 bản ghi lịch sử vào `ticket_histories`: `action = RESOLVE`, `performer_id = current_staff_id`, `details = resolution_note`.
5. **Phát Thông Báo (Push Notification):**
   - Bắn thông báo thời gian thực (In-app Bell / Email) tới Sinh viên chủ sở hữu: "Yêu cầu [Mã_Ticket] của bạn đã được giải quyết. Vui lòng kiểm tra kết quả và đánh giá mức độ hài lòng."

### Bước 4: Cập Nhật Giao Diện Client & Luồng Tiếp Theo
1. Server trả về `HTTP 200 OK`.
2. Client tại phía Staff:
   - Hiển thị Toast success: "Đã hoàn tất xử lý Ticket [Mã_Ticket] thành công!".
   - Khóa toàn bộ các nút thao tác xử lý (Disable nút Chuyển phòng ban, Yêu cầu bổ sung, Hoàn thành).
   - Badge trạng thái Ticket chuyển sang màu xanh lá đại diện cho `RESOLVED`.
3. Phía Sinh viên:
   - Nhận thông báo, xem được đầy đủ `resolution_note` và file kết quả.
   - Kích hoạt Component cho phép Sinh viên thực hiện Đánh giá mức độ hài lòng (CSAT $1-5$ sao) theo quy trình WF-06.

## 5. Ràng Buộc Kỹ Thuật & Quy Tắc Nghiệp Vụ (Business Rules)

| Tên quy tắc | Mô tả chi tiết & Handling Specs |
| :--- | :--- |
| **Bắt buộc Kết quả xử lý** | `resolution_note` bắt buộc nhập, độ dài từ $20 - 2.000\text{ ký tự}$ sau khi `trim()`. Không chấp nhận chuỗi chỉ chứa khoảng trắng. |
| **Ràng buộc File kết quả** | Tối đa $3\text{ file/lần hoàn tất}$. Dung lượng $\le 5\text{MB/file}$. Định dạng MIME Type thực tế: `application/pdf`, `image/png`, `image/jpeg`. |
| **Chuyển đổi Trạng thái RESOLVED** | Bắt buộc chuyển trạng thái sang `RESOLVED` (chưa chuyển thẳng sang `CLOSED` để chờ Sinh viên nghiệm thu và đánh giá). |
| **Ghi nhận resolved_at** | Timestamp `resolved_at` được lưu cố định làm căn cứ tính Tổng thời gian xử lý thực tế (Resolution Time) phục vụ Báo cáo SLA của Quản lý. |
| **Khóa thao tác Chỉnh sửa** | Khi Ticket đã chuyển sang `RESOLVED`, Nhân viên **KHÔNG ĐƯỢC PHÉP** chỉnh sửa lại `resolution_note` hoặc thay đổi trạng thái Ticket trừ khi có can thiệp của Admin. |
| **Bộ đếm Auto-Close (Cronjob)** | Ngay khi `status = RESOLVED`, hệ thống bắt đầu tính $3\text{ ngày làm việc}$. Nếu Sinh viên không đánh giá, Cronjob sẽ tự động chuyển `status = CLOSED` (theo quy định tại WF-06). |

## 6. Luồng Ngoại Lệ & Mã Lỗi Hệ Thống (Exception & Error Flows)

| Tình huống ngoại lệ | Mã lỗi HTTP & Error Code | Message hiển thị cho Nhân viên | Hành động xử lý của Client |
| :--- | :--- | :--- | :--- |
| **Để trống kết quả / Kết quả quá ngắn** | `400 Bad Request`<br><br>`INVALID_INPUT` | "Vui lòng nhập nội dung kết quả giải quyết chi tiết (tối thiểu 20 ký tự)." | Hiển thị lỗi dưới Textarea của Modal, giữ nguyên dữ liệu đã nhập. |
| **Thao tác khi Ticket không ở IN_PROGRESS** | `400 Bad Request`<br><br>`INVALID_TICKET_STATE` | "Ticket không ở trạng thái cho phép hoàn tất xử lý." | Tự động reload lại dữ liệu Ticket để cập nhật UI mới nhất. |
| **Upload file kết quả quá 5MB / sai đuôi** | `400 Bad Request`<br><br>`FILE_EXCEEDS_LIMIT` | "File [Tên_File] vượt quá dung lượng 5MB hoặc sai định dạng (.pdf, .png, .jpg)." | Đánh dấu đỏ file lỗi trên Modal upload, ngăn submit. |
| **Staff không phải người phụ trách (Assignee)** | `403 Forbidden`<br><br>`FORBIDDEN_ACCESS` | "Bạn không phải là người trực tiếp phụ trách xử lý Ticket này." | Vô hiệu hóa nút Hoàn thành trên giao diện Staff. |
| **Lỗi Server / Database Transaction** | `500 Internal Server Error`<br><br>`INTERNAL_SERVER_ERROR` | "Không thể lưu kết quả do sự cố hệ thống. Vui lòng thử lại." | Hiển thị Toast error, giữ nguyên trạng thái Modal để thử lại. |
# QTTN 06: Quy Trình Sinh Viên Nhận Kết Quả & Đánh Giá Mức Độ Hài Lòng (WF-06)

## 1. Mục Tiêu Quy Trình
Mô tả chi tiết luồng xử lý kỹ thuật khi Sinh viên tiếp nhận kết quả xử lý từ nhà trường và thực hiện đánh giá chất lượng phục vụ (CSAT - Customer Satisfaction). Quy trình đảm bảo tính toàn vẹn FSM (chuyển đổi từ `RESOLVED` sang `CLOSED`), khóa form đánh giá chống gửi lặp (Read-only state), xử lý tranh chấp khi mở nhiều tab (Race Condition) và tự động đóng Ticket qua hệ thống Cronjob sau 3 ngày làm việc.

## 2. Tác Nhân Tham Gia (Actors) & Điều Kiện Tiên Quyết
- **Actors:**
  - **Sinh viên sở hữu Ticket (Student Owner):** Người đọc kết quả và gửi đánh giá.
  - **Client (Web App):** Giao diện hiển thị kết quả giải quyết và Component đánh giá sao/nhận xét.
  - **Server (Backend API):** Xác thực quyền, kiểm tra ràng buộc 1 lần đánh giá, cập nhật CSDL, chuyển trạng thái `CLOSED` và phát Notification.
  - **System Cronjob:** Tiến trình chạy ngầm tự động đóng các Ticket ở trạng thái `RESOLVED` quá 3 ngày làm việc.
- **Preconditions:**
  - Ticket có trạng thái `RESOLVED` hoặc `CLOSED`.
  - Sinh viên đăng nhập đúng tài khoản sở hữu Ticket (`student_id == ticket.student_id`).

## 3. Lược Đồ Quy Trình Tương Tác (Sequence Diagram)
```plaintext
[Sinh viên]            [Client Web]              [Backend API / CSDL]           [System Cronjob]
    │                       │                             │                            │
    │ ── 1. Mở Ticket ─────>│                             │                            │
    │                       │ ── 2. GET /tickets/{id} ───>│                            │
    │                       │<── 3. Trả về Detail ────────│                            │
    │ ── 4. Xem Kết quả ───>│    (Bao gồm Resolution Note)│                            │
    │                       │                             │                            │
    │                       │ [Kiểm tra rating_score]     │                            │
    │                       │ - Nếu NULL: Hiện Form ĐG    │                            │
    │                       │ - Nếu HAS: Hiện Read-only   │                            │
    │                       │                             │                            │
    │ ── 5. Chọn 1-5 Sao ──>│                             │                            │
    │ ── 6. Nhập Comment ──>│                             │                            │
    │ ── 7. Bấm "Gửi ĐG" ──>│                             │                            │
    │                       │ ── 8. POST /rate ──────────>│                            │
    │                       │    (Check rating_score NULL)│                            │
    │                       │                             │ ── 9. Save Rating Data ───>│
    │                       │                             │ ── 10. Set STATUS=CLOSED ─>│
    │                       │                             │ ── 11. Set rated_at, closed_at
    │                       │<── 12. HTTP 200 OK ─────────│                            │
    │<── 13. Toast Cảm ơn ──│                             │                            │
    │    & Render Read-only │                             │                            │
    │                       │                             │                            │
    │                       │                             │<── 14. Quá 3 ngày làm việc ─│
    │                       │                             │    (Chưa đánh giá)        │
    │                       │                             │ ── 15. Auto SET CLOSED ───│
```
---
## 4. Các Bước Thực Hiện Chi Tiết (Flow of Events)

### Nhánh 1: Sinh viên thực hiện đánh giá thành công (Main Flow)
1. **Truy cập Chi tiết Ticket:** Sinh viên click thông báo hoặc truy cập đường dẫn `/tickets/{ticket_id}`.
2. **Hiển thị Kết quả & Form Đánh giá:**
   - Hệ thống hiển thị Khung Kết quả giải quyết gồm: Nội dung phản hồi của Nhân viên (`resolution_note`), danh sách File đính kèm kết quả (`resolution_attachments`) và thời gian hoàn thành (`resolved_at`).
   - Client kiểm tra trường `rating_score` trong response data:
     - Nếu `rating_score == NULL`: Hiển thị Component Đánh giá (5 Ngôi sao tương tác + Textarea nhập `rating_comment` + Nút Gửi đánh giá).
     - Nếu `rating_score != NULL`: Chuyển Component Đánh giá sang dạng Read-Only (Hiển thị số sao đã chọn và nhận xét cũ, vô hiệu hóa toàn bộ input).
3. **Thao tác Đánh giá:**
   - Sinh viên chọn số sao từ $1$ đến $5$ sao (`rating_score` Bắt buộc).
   - Sinh viên nhập nhận xét bổ sung (`rating_comment` Không bắt buộc, tối đa $500\text{ ký tự}$).
4. **Submit Request:** Sinh viên bấm **Gửi đánh giá**. Client chuyển nút sang Loading để chống double click.
5. **Server Processing & Atomic Update:**
   - Server kiểm tra JWT Token: Xác thực `student_id == ticket.student_id`.
   - Server kiểm tra trạng thái đánh giá hiện tại:
     - Thực hiện query kiểm tra `SELECT rating_score FROM tickets WHERE ticket_id = ? FOR UPDATE`.
     - Nếu `rating_score IS NOT NULL` (Đã được đánh giá trước đó): Trả về mã lỗi `409 ALREADY_RATED`.
   - Cập nhật dữ liệu vào bản ghi Ticket:
     - `rating_score = request.rating_score`
     - `rating_comment = trim(request.rating_comment)`
     - `rated_at = CURRENT_TIMESTAMP`
     - `status = CLOSED` (Nếu trạng thái hiện tại đang là `RESOLVED`)
     - `closed_at = CURRENT_TIMESTAMP` (Nếu `closed_at` đang `NULL`)
6. **Cập nhật UI:**
   - Server trả về `HTTP 200 OK`.
   - Client hiển thị Toast thông báo: *"Cảm ơn bạn đã gửi đánh giá chất lượng dịch vụ!"*.
   - Component Đánh giá tự động chuyển sang dạng Read-Only (Không thể chỉnh sửa hay gửi lại).

### Nhánh 2: Tự động đóng Ticket qua Cronjob (System Auto-Close Flow)
1. **Lịch chạy định kỳ:** Hệ thống Cronjob chạy tự động vào $23:00$ mỗi ngày làm việc.
2. **Xác định bản ghi:** Cronjob quét các Ticket đáp ứng đầy đủ điều kiện:
   - `status == RESOLVED`
   - `rating_score IS NULL`
   - Thời gian từ `resolved_at` đến thời điểm hiện tại $> 3\text{ ngày làm việc}$ ($72\text{ giờ làm việc}$, loại trừ Thứ 7, Chủ Nhật và ngày Lễ).
3. **Xử lý cập nhật hàng loạt (Batch Processing):**
   - Cập nhật trạng thái: `status = CLOSED`.
   - Cập nhật timestamp: `closed_at = CURRENT_TIMESTAMP`.
   - Ghi log hệ thống (Audit Log): `action = SYSTEM_AUTO_CLOSE`.
4. **Trạng thái sau Auto-close:**
   - Khi Sinh viên mở lại Ticket đã bị Auto-close, hệ thống **VẪN CHO PHÉP** Sinh viên đánh giá hài lòng nếu `rating_score` vẫn đang `NULL`.
   - Sau khi Sinh viên đánh giá xong, hệ thống cập nhật `rating_score`, `rating_comment`, `rated_at` và giữ nguyên trạng thái `CLOSED`.

## 5. Ràng Buộc Kỹ Thuật & Quy Tắc Nghiệp Vụ (Business Rules)

| Tên quy tắc | Mô tả chi tiết & Handling Specs |
| :--- | :--- |
| **Bắt buộc số sao** | `rating_score` bắt buộc chọn, nhận giá trị số nguyên từ $1$ đến $5$. Không được gửi request khi chưa chọn số sao. |
| **Ghi chú đánh giá** | `rating_comment` không bắt buộc (Optional), độ dài tối đa $500\text{ ký tự}$. Tự động `trim()` khoảng trắng thừa. |
| **Giới hạn số lần đánh giá** | Mỗi Ticket chỉ được gửi đánh giá duy nhất $01\text{ lần}$. Sau khi ghi nhận thành công, dữ liệu đánh giá là bất biến (Immutable - không cho sửa/xóa). |
| **Chuyển đổi trạng thái FSM** | Khi Sinh viên gửi đánh giá cho Ticket `RESOLVED`, Backend phải tự động cập nhật `status = CLOSED` và ghi nhận `closed_at`. |
| **Xử lý Race Condition (Nhiều tab)** | Nếu Sinh viên mở 2 tab cùng 1 Ticket: Tab A bấm gửi trước $\rightarrow$ Thành công; Tab B bấm gửi sau $\rightarrow$ Server trả lỗi `409 ALREADY_RATED`. Tab B nhận lỗi sẽ tự động fetch lại data và chuyển giao diện sang dạng Read-only. |
| **Quy tắc Auto-Close** | Sau $3\text{ ngày làm việc}$ kể từ khi `status = RESOLVED`, nếu Sinh viên không đánh giá, Hệ thống tự chuyển `status = CLOSED`. Sinh viên mở lại Ticket vẫn có thể bổ sung Đánh giá. |

## 6. Luồng Ngoại Lệ & Mã Lỗi Hệ Thống (Exception & Error Flows)

| Tình huống ngoại lệ | Mã lỗi HTTP & Error Code | Message hiển thị cho Sinh viên | Hành động xử lý của Client |
| :--- | :--- | :--- | :--- |
| **Chưa chọn số sao mà bấm Gửi** | `400 Bad Request`<br><br>`INVALID_INPUT` | "Vui lòng chọn mức độ hài lòng (từ 1 đến 5 sao) trước khi gửi." | Báo lỗi validation trực tiếp trên UI, không phát request. |
| **Gửi đánh giá 2 lần (Trùng lặp/Nhiều tab)** | `409 Conflict`<br><br>`ALREADY_RATED` | "Ticket này đã được gửi đánh giá trước đó." | Reload lại dữ liệu Ticket, ẩn nút Gửi, chuyển Form sang dạng Read-only. |
| **Nhập nhận xét vượt quá 500 ký tự** | `400 Bad Request`<br><br>`INVALID_INPUT` | "Nhận xét không được vượt quá 500 ký tự." | Chặn không cho nhập tiếp trên Textarea (Counter max length = 500). |
| **Gửi đánh giá cho Ticket của sinh viên khác** | `403 Forbidden`<br><br>`FORBIDDEN_ACCESS` | "Bạn không có quyền đánh giá Ticket này." | Ẩn hoàn toàn Component Đánh giá, hiển thị thông báo không có quyền. |
| **Mạng ngắt kết nối khi gửi đánh giá** | `500 Internal Server Error`<br><br>`INTERNAL_SERVER_ERROR` | "Không thể lưu đánh giá do lỗi kết nối. Vui lòng thử lại." | Hiển thị Toast error, giữ nguyên số sao và nhận xét đã chọn để Sinh viên bấm thử lại. |
# Yêu Cầu Triển Khai Hạ Tầng (Deployment Requirements)

## 1. Môi Trường Triển Khai
* **Hạ tầng triển khai:** Hệ thống UniSupport được triển khai trực tiếp lên hạ tầng máy chủ (Server) do **Aurora University** cung cấp theo thỏa thuận.
* **Môi trường:**
  * **Staging / UAT Environment:** Phục vụ công tác kiểm thử chấp nhận người dùng (UAT) trong 10 ngày làm việc.
  * **Production Environment:** Môi trường vận hành chính thức cho nhà trường.

---

## 2. Đóng Gói & Tên Miền
* **Tên miền (Domain):** Hệ thống được cấu hình chạy trên Tên miền chính thức do nhà trường cấp và trỏ về máy chủ triển khai.
* **Đóng gói phần mềm:** Mã nguồn Frontend và Backend được đóng gói dạng container (như Docker) hoặc các bản build tối ưu để dễ dàng cài đặt và vận hành trên hệ điều hành máy chủ của Client.
* **Tài liệu hướng dẫn:** Cung cấp tài liệu hướng dẫn cài đặt, cấu hình môi trường và vận hành chi tiết cho bộ phận kỹ thuật của nhà trường khi bàn giao.
# Yêu Cầu Về Ghi Vết & Giám Sát (Observability Requirements)

## 1. Tổng Quan Kiến Trúc Giám Sát (Observability Architecture)
Hệ thống UniSupport bắt buộc phải triển khai cơ chế Giám sát & Ghi vết tập trung nhằm đảm bảo khả năng tra soát sự cố, kiểm toán an toàn thông tin và theo dõi hiệu năng hệ thống theo thời gian thực. Hệ thống Observability bao gồm 3 trụ cột chính:
1. **System Error & Exception Logging:** Ghi nhận lỗi phần mềm, ngoại lệ hệ thống phục vụ Debugging.
2. **Business Audit Trail (Audit Logging):** Ghi vết các biến động dữ liệu nghiệp vụ nhạy cảm và thao tác quản trị.
3. **Application Performance & Metric Monitoring:** Giám sát thời gian phản hồi API và trạng thái vận hành tài nguyên.

## 2. Ghi Nhận Lỗi Hệ Thống (System Error Logging Specs)

### 2.1. Cấu Trúc Bản Ghi Log Chuẩn (Structured JSON Logging Format)
Mọi bản ghi Log hệ thống do Backend xuất ra BẮT BUỘC phải tuân thủ chuẩn Structured JSON Format (một dòng JSON duy nhất cho mỗi sự kiện log) để phục vụ thu thập và truy vấn tự động:

| Trường Dữ Liệu | Kiểu Dữ Liệu | Bắt Buộc | Mô Tả & Rules Kỹ Thuật |
| :--- | :--- | :---: | :--- |
| `timestamp` | String (ISO 8601) | Có | Định dạng UTC chuẩn `YYYY-MM-DDTHH:mm:ss.SSSZ` (Ví dụ: `2026-10-09T14:30:00.123Z`). |
| `level` | Enum | Có | Cấp độ Log: `INFO`, `WARN`, `ERROR`, `FATAL`. |
| `trace_id` | UUID v4 | Có | Mã định danh luồng xử lý duy nhất truyền xuyên suốt từ API Gateway $\rightarrow$ Service $\rightarrow$ Database query. |
| `service_name` | String | Có | Tên Service phát sinh log (Ví dụ: `unisupport-backend-api`). |
| `endpoint` | String | Không | Đường dẫn API / Function thực thi (Ví dụ: `POST /api/v1/tickets`). |
| `user_id` | String | Không | ID của người dùng thực hiện request (Mặc định `ANONYMOUS` nếu chưa đăng nhập). |
| `ip_address` | String | Có | Địa chỉ Client IP thực tế (Đọc từ HTTP Header `X-Forwarded-For` hoặc `X-Real-IP`). |
| `message` | String | Có | Thông điệp lỗi / mô tả vắn tắt sự kiện. |
| `exception_class` | String | Không | Tên Class ngoại lệ (Ví dụ: `NullPointerException`, `DatabaseConnectionException`). |
| `stack_trace` | Text | Không | Toàn bộ thông tin Stack trace kỹ thuật khi có lỗi Unhandled Exception (`level = ERROR` hoặc `FATAL`). |

### 2.2. Phân Cấp Mức Độ Log (Log Levels Policy)
- **INFO:** Ghi nhận các sự kiện vận hành bình thường (Khởi động Server, Scheduled Cronjob hoàn thành, API Healthcheck).
- **WARN:** Ghi nhận các bất thường không gây gián đoạn dịch vụ (Request bị từ chối do Client Validation lỗi, Retry kết nối Redis/DB thành công, File upload cận ngưỡng 5MB).
- **ERROR:** Ghi nhận toàn bộ lỗi ngoại lệ không mong muốn (HTTP 500, Lỗi Query CSDL, Lỗi kết nối Storage, Lỗi Timeout API bên ngoài).
- **FATAL:** Lỗi nghiêm trọng khiến hệ thống bị sập hoặc ngừng dịch vụ hoàn toàn (Database crash, Out of Memory).

## 3. Nhật Ký Thao Tác & Kiểm Toán (Audit Logging Specs)

### 3.1. Danh Mục Thao Tác Bắt Buộc Ghi Audit Log
Audit Log lưu trữ vĩnh viễn dữ liệu tra soát các hành động làm thay đổi trạng thái hệ thống hoặc dữ liệu nhạy cảm. Tuyệt đối không được phép chỉnh sửa hay xóa bản ghi Audit Log (Append-Only Data Store):

| Nhóm Thao Tác | Mã Hành Động (`action_code`) | Đối Tượng Tác Động (`target_type`) | Mô Tả Dữ Liệu Cần Lưu |
| :--- | :--- | :--- | :--- |
| **Xác thực** | `AUTH_LOGIN_SUCCESS` | USER | Ghi nhận Đăng nhập thành công, IP, Device User-Agent. |
| | `AUTH_LOGIN_FAILED` | USER | Ghi nhận Đăng nhập thất bại, Lý do sai mật khẩu/khóa tài khoản. |
| | `AUTH_LOGOUT` | USER | Đăng xuất, vô hiệu hóa Token. |
| **Nghiệp vụ Ticket** | `TICKET_CREATE` | TICKET | Khởi tạo Ticket mới (`ticket_id`, `student_id`, `category_id`). |
| | `TICKET_CLAIM` | TICKET | Nhân viên tiếp nhận xử lý (`staff_id`, `priority`). |
| | `TICKET_TRANSFER` | TICKET | Chuyển phòng ban (`from_dept`, `to_dept`, `transfer_reason`). |
| | `TICKET_REQUEST_MORE` | TICKET | Yêu cầu sinh viên bổ sung hồ sơ (`request_note`). |
| | `TICKET_SUPPLEMENT` | TICKET | Sinh viên gửi bổ sung file/ghi chú (`attachments_count`). |
| | `TICKET_RESOLVE` | TICKET | Hoàn tất xử lý (`resolution_note`). |
| | `TICKET_RATE` | TICKET | Sinh viên gửi đánh giá CSAT (`rating_score`, `rating_comment`). |
| **Quản trị Tài khoản** | `USER_CREATE` | USER | Admin tạo tài khoản mới (`created_user_id`, `role`, `dept`). |
| | `USER_UPDATE_ROLE` | USER | Admin thay đổi Role/Department (`old_role` $\rightarrow$ `new_role`). |
| | `USER_DISABLE` | USER | Admin khóa tài khoản (`disabled_user_id`, `reason`). |
| | `USER_ENABLE` | USER | Admin mở khóa tài khoản. |

### 3.2. Cấu Trúc Bảng CSDL Audit Log (`audit_logs`)
```sql
CREATE TABLE audit_logs (
    log_id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    trace_id        UUID NOT NULL,
    timestamp       TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
    actor_id        VARCHAR(50) NOT NULL,
    actor_role      VARCHAR(20) NOT NULL,
    action_code     VARCHAR(50) NOT NULL,
    target_type     VARCHAR(50) NOT NULL,
    target_id       VARCHAR(50) NOT NULL,
    ip_address      VARCHAR(45) NOT NULL,
    user_agent      TEXT,
    old_value       JSONB,
    new_value       JSONB,
    description     TEXT
);
```
---
## 4. Quản Lý Thời Gian Lưu Trữ & An Toàn Dữ Liệu (Retention & Security Specs)

### 4.1. Chính Sách Lưu Trữ File Log (Retention Policy)
- **Error Log Files:** Lưu giữ trong vòng 30 ngày trên đĩa cứng Server/Storage. Tự động nén log cũ (`.gz`) mỗi ngày và tự động xóa bớt các file log quá 30 ngày qua Cronjob hệ thống.
- **Audit Log Database:** Lưu trữ vĩnh viễn trong CSDL tối thiểu 12 tháng phục vụ công tác thanh tra, kiểm toán của nhà trường.

### 4.2. Bảo Mật & Sanitize Dữ Liệu Nhạy Cảm (Masking Sensitive Data)
Trước khi ghi bất kỳ chuỗi thông tin nào vào File Log hoặc Audit Log, hệ thống Backend BẮT BUỘC phải lọc và mã hóa (Masking) các dữ liệu nhạy cảm sau:
- **Mật khẩu người dùng (`password`):** Tự động thay thế bằng `********`.
- **Token xác thực (`Authorization` / `JWT`):** Chỉ ghi 10 ký tự đầu và 5 ký tự cuối (Ví dụ: `eyJhbGciOi...xYZ123`).
- **Nội dung nhạy cảm:** Bỏ qua hoàn toàn dữ liệu mã hóa mật khẩu hoặc thông tin thẻ/tài khoản ngân hàng (nếu có).

## 5. Phạm Vi Không Triển Khai (Non-Goals)
1. **Không triển khai Full-Tracing APM phức tạp:** Không cài đặt các hệ thống APM đắt đỏ (như Datadog, New Relic) cho quy mô hiện tại.
2. **Không ghi Log SQL Query đọc dữ liệu (`SELECT`):** Chỉ ghi Audit Log cho các lệnh làm biến động dữ liệu (`INSERT`, `UPDATE`, `DELETE`). Không ghi log cho các hành vi xem/tra cứu danh sách thông thường để tránh làm quá tải dung lượng CSDL.
# Yêu Cầu Về Hiệu Năng & Tối Ưu Hệ Thống (Performance Requirements)

## 1. Tổng Quan Sức Chịu Tải & Quy Mô (Capacity Planning & Workload Specs)
Hệ thống UniSupport được thiết kế, tối ưu kiến trúc và kiểm thử hiệu năng bám sát quy mô vận hành thực tế tại Aurora University:
- **Dung lượng Người dùng (Target Capacity):** Phục vụ toàn bộ 3.000 sinh viên cùng khoảng 100 cán bộ, nhân viên, quản lý các phòng ban.
- **Tải Đồng Thời Cao Điểm (Peak Concurrent Users - CCU):** Đáp ứng tối thiểu 150 CCU thao tác đồng thời trên giao diện Web trong các đợt cao điểm (Đợt nộp đơn phúc khảo, đăng ký tốt nghiệp, đầu kỳ học).
- **Tải Tác Vụ API Cao Điểm (Peak API Throughput):** Đạt ngưỡng $50 - 80\text{ Requests/Second (RPS)}$ đối với các tác vụ đọc/ghi tổng hợp mà không làm sụt giảm thời gian phản hồi hoặc gây tràn bộ nhớ CSDL.
- **Phạm Vi Tải Ngoài Mục Tiêu (Out-of-Scope / Non-Goal):** Hệ thống không thiết kế cho quy mô đại chúng (Public Load) và không chịu trách nhiệm xử lý các bài kiểm thử chịu tải cực hạn (Stress Test) vượt quá 500 CCU hoặc $> 200\text{ RPS}$.

## 2. Cam Kết Chỉ Số Thời Gian Phản Hồi (SLA Response Time Matrix)
Toàn bộ các chỉ số đo lường dưới đây được tính toán tại Percentile 95th ($P_{95}$) dưới điều kiện mạng tiêu chuẩn (Băng thông $\ge 10\text{ Mbps}$, RTT Latency $\le 50\text{ ms}$):

| Nhóm Thao Tác / Endpoint Type | Hạn Mức Phản Hồi Tối Đa ($P_{95}$) | Quy Định Tối Ưu Phía Backend & Database |
| :--- | :--- | :--- |
| **First Page Load (Tải trang đầu)** | $< 2.5\text{ giây}$ | Tối ưu Frontend Asset Bundle ($\le 2\text{MB}$ Gzip/Brotli), áp dụng Lazy Loading cho các Component phụ, CDN Caching static files. |
| **API Truy vấn tĩnh (Filter / Detail)** | $< 500\text{ ms}$ | Bắt buộc đánh Index B-Tree cho Foreign Keys, Cache danh mục tĩnh (Categories, Departments) trên Redis Cache. |
| **API Danh sách (Pagination Listing)** | $< 1.000\text{ ms}$ | Bắt buộc Phân trang (Page / Limit). Query CSDL không sử dụng `SELECT *`, bắt buộc liệt kê danh sách cột cần thiết. |
| **API Tạo Ticket / Bổ sung hồ sơ** | $< 1.500\text{ ms}$ | Đọc Stream File upload trực tiếp sang Storage, validate Form bằng Memory Buffer, ghi CSDL trong $1\text{ Transaction}$. |
| **API Xuất Báo Cáo (Excel / CSV)** | $< 3.000\text{ ms}$ | Stream data trả về Client theo Chunk (Tối đa $10.000\text{ bản ghi/lần xuất}$). Không nạp toàn bộ dataset vào RAM Backend. |
| **Dashboard Metrics (Aggregate)** | $< 800\text{ ms}$ | Không Query trực tiếp Aggregate SQL ($COUNT/SUM$) trên toàn bảng `tickets`. Đọc dữ liệu từ Redis Aggregate Cache (TTL $30 - 60\text{ giây}$). |

## 3. Chiến Lược Tối Ưu Hóa Dữ Liệu & Tài Nguyên Storage

### 3.1. Phân Trang Dữ Liệu Chuẩn (Pagination Standards)
Tất cả các API trả về danh sách bản ghi (`tickets`, `conversations`, `users`, `audit_logs`) bắt buộc áp dụng cơ chế Phân trang phía Server (Server-side Pagination):
- **Kích thước Trang Mặc định (Default Limit):** $10$ đến $20\text{ bản ghi/trang}$.
- **Kích thước Trang Tối đa (Max Limit Guard):** Tối đa $50\text{ bản ghi/trang}$. Nếu Client gửi limit > 50, Server tự động ghi đè `limit = 50`.
- **Cấu trúc Response Chuẩn:**
```json
{
  "data": [...],
  "pagination": {
    "current_page": 1,
    "limit": 20,
    "total_records": 150,
    "total_pages": 8
  }
}
```
---
### 3.2. Giới Hạn & Quản Lý Luồng Tải File (File I/O Optimization)
- **Giới Hạn Dung Lượng Strict:** Tối đa $5\text{MB}$ ($5.242.880\text{ Bytes}$) mỗi file. Server ngắt kết nối HTTP ngay khi phát hiện `Content-Length > 5MB` để bảo vệ tài nguyên băng thông.
- **Streaming File Process:** Khâu xem/tải file qua API `/api/v1/attachments/{file_id}` bắt buộc sử dụng Stream Read Chunk ($64\text{KB/Chunk}$) đẩy về HTTP Response Stream. Tuyệt đối không đọc toàn bộ dung lượng file vào bộ nhớ RAM (`readFileSync` is BANNED).

## 4. Chỉ Số Hiệu Năng CSDL & Cấu Hình Cache (Database & Redis Specs)

### 4.1. Tối Ưu Truy Vấn & Indexing CSDL
- **Chỉ mục B-Tree bắt buộc cài đặt:**
  - `tickets`: `(student_id, created_at DESC)`, `(department_id, status)`, `(sla_status, status)`.
  - `ticket_conversations`: `(ticket_id, created_at ASC)`.
  - `audit_logs`: `(timestamp DESC)`, `(actor_id)`.
- **Kiểm Soát Slow Query:** Mọi câu lệnh SQL thực thi $> 200\text{ ms}$ phải được tự động bắt giữ và ghi vào Slow Query Log của CSDL để lập trình viên tối ưu lại Index.
- **Connection Pooling:** Thiết lập Database Connection Pool phía Backend với cấu hình: `min_connections = 5`, `max_connections = 20`, `idle_timeout = 30000ms`.

### 4.2. Chiến Lược Caching Trực Tiếp Trên Redis
- **Session & Token Blacklist Cache:** Lưu trữ JWT Blacklist ID khi logout/khóa tài khoản. Key `blacklist:{jti}`, TTL bằng thời gian sống còn lại của Token.
- **Category & System Config Cache:** Lưu danh mục Categories, Departments. Key `config:categories`, TTL = $24\text{ giờ}$ (Tự động Purge Cache khi Admin sửa danh mục).
- **Dashboard Aggregate Metrics Cache:** Lưu số liệu Summary Cards trên Dashboard Manager/Admin. Key `metrics:dept:{dept_id}`, TTL = $60\text{ giây}$.
# Yêu Cầu Phi Chức Năng (Non-Functional Requirements)

## 1. Tổng Quan
Thư mục này xác định các tiêu chuẩn và yêu cầu phi chức năng (NFR) bắt buộc cho hệ thống **UniSupport** tại **Aurora University**. Các tiêu chuẩn này đảm bảo hệ thống vận hành ổn định, an toàn, dễ sử dụng và phù hợp với quy mô cùng hạ tầng đã thỏa thuận.

---

## 2. Danh Sách Các Hạng Mục Yêu Cầu Phi Chức Năng

| Mã Tài Liệu | Hạng Mục NFR | Nội Dung Trọng Tâm |
| :--- | :--- | :--- |
| **`performance.md`** | Hiệu năng (Performance) | Đáp ứng tối đa 3.000 sinh viên, thời gian phản hồi API < 2 giây. |
| **`security.md`** | Bảo mật (Security) | Đăng nhập tài khoản cá nhân, bảo mật file đính kèm, phân quyền RBAC. |
| **`reliability.md`** | Độ ổn định (Reliability) | Tính sẵn sàng của hệ thống trên môi trường máy chủ của Client. |
| **`usability.md`** | Tính dễ sử dụng (Usability) | Giao diện Responsive (PC & Mobile), hỗ trợ 2 ngôn ngữ VI/EN. |
| **`observability.md`** | Ghi vết & Giám sát (Observability) | Nhật ký hoạt động (Audit log) cơ bản và ghi nhận lỗi hệ thống. |
| **`deployment.md`** | Triển khai (Deployment) | Quy trình đóng gói và bàn giao triển khai trên Server/Domain của Client. |
# Yêu Cầu Về Độ Ổn Định & Tin Cậy (Reliability Requirements)

## 1. Tính Sẵn Sàng Của Hệ Thống (Availability)
* **Thời gian hoạt động (Uptime):** Hệ thống hướng tới duy trì độ sẵn sàng khoảng 98.5% trong thời gian vận hành chính thức tại nhà trường.
* **Phụ thuộc hạ tầng:** Tính ổn định và độ sẵn sàng của hệ thống phụ thuộc trực tiếp vào chất lượng hạ tầng máy chủ, đường truyền mạng và Tên miền do Aurora University cung cấp.

---

## 2. Toàn Vẹn Dữ Liệu & Xử Lý Sự Cố
* **Toàn vẹn giao dịch:** Các thao tác quan trọng như tạo Ticket, chuyển phòng ban, đóng Ticket phải đảm bảo tính toàn vẹn dữ liệu (Atomic Transaction). Nếu có lỗi xảy ra giữa chừng, hệ thống phải Rollback hoàn toàn dữ liệu về trạng thái trước đó.
* **Khôi phục trạng thái:** Khi gặp sự cố ngắt kết nối mạng hoặc treo máy chủ, hệ thống không được làm mất mát dữ liệu đang ở trạng thái đã lưu thành công trước đó.
* **Bảo trì & Sao lưu (Out of Scope):** Việc thiết lập cơ chế tự động sao lưu định kỳ (Auto Backup) và theo dõi vận hành máy chủ không thuộc phạm vi trách nhiệm của đơn vị phát triển.
# Yêu Cầu Về Bảo Mật (Security Requirements)

## 1. Xác Thực & Phân Quyền (Authentication & Authorization)
* **Xác thực:** Người dùng bắt buộc phải đăng nhập bằng tài khoản và mật khẩu riêng trước khi sử dụng các chức năng hệ thống.
* **Phân quyền 3 vai trò (RBAC):** Kiểm soát quyền hạn chặt chẽ dựa trên 3 vai trò: Sinh viên, Nhân viên và Quản lý. Sinh viên chỉ được phép xem/thao tác trên Ticket do chính mình tạo.
* **Mã hóa mật khẩu:** Mật khẩu người dùng phải được mã hóa bằng thuật toán băm an toàn (như Bcrypt) trước khi lưu vào cơ sở dữ liệu.

---

## 2. Kiểm Soát Quyền Truy Cập File Đính Kèm
* **Private Storage:** Các file đính kèm (ảnh PNG/JPG, file PDF) tuyệt đối không được để công khai qua các đường dẫn tĩnh công cộng (Public URL).
* **Xác thực quyền xem File:** Mỗi truy vấn xem/tải file đính kèm đều phải thông qua API kiểm tra quyền truy cập: Chỉ Sinh viên tạo Ticket, Nhân viên thuộc phòng ban phụ trách và Quản lý hệ thống mới có quyền truy cập file.

---

## 3. An Toàn Dữ Liệu & Tra Soát
* **Chống tạo dữ liệu rác/trùng lặp:** Áp dụng cơ chế Idempotency/Token để chặn việc bấm nút gửi nhiều lần (double-click) hoặc gửi lại request trùng lặp.
* **Nhật ký tra soát (Audit Log):** Ghi vết các thao tác quan trọng (đăng nhập, chuyển phòng ban, đóng Ticket, thay đổi quyền) để phục vụ tra soát khi có sự cố.
* **Phạm vi bảo mật:** Không bắt buộc các chứng nhận bảo mật quốc tế chuyên sâu (như ISO 27001, PCI-DSS) hay kiểm thử thâm nhập sâu (Penetration Testing) ngoài các quy định đã thống nhất.
# Yêu Cầu Về Tính Dễ Sử Dụng (Usability Requirements)

## 1. Thiết Kế Giao Diện (UI/UX)
* **Giao diện Responsive:** Giao diện hệ thống phải tự động tương thích và hiển thị tối ưu trên cả màn hình máy tính (Desktop) và các thiết bị di động (Mobile Browser).
* **Tính đơn giản & Trực quan:** Thiết kế chuẩn hóa theo nhận diện của Aurora University, tối giản các bước thao tác. Sinh viên có thể tạo thành công 1 Ticket hỗ trợ trong tối đa 3 bước cơ bản.

---

## 2. Đa Ngôn Ngữ (Multilingual)
* **Hỗ trợ ngôn ngữ:** Hệ thống hỗ trợ giao diện cơ bản bằng 2 ngôn ngữ: **Tiếng Việt** và **Tiếng Anh**.
* **Phạm vi chuyển đổi:** Cho phép người dùng chuyển đổi ngôn ngữ hiển thị trên thanh điều hướng chính (Menu) cho các nhãn, nút bấm và thông báo hệ thống.

---

## 3. Phản Hồi Trạng Thái Cho Người Dùng
* **Thông báo rõ ràng:** Mọi thao tác thành công hoặc thất bại của người dùng phải đi kèm thông báo phản hồi rõ ràng (Toast Message / Alert Banner).
* **Trạng thái xử lý:** Các tác vụ chờ xử lý (như upload file, gửi yêu cầu) bắt buộc phải có hiệu ứng Loading / Progress Bar để tránh việc người dùng thao tác lặp lại nhiều lần.
# Nghiệm Thu & Kiểm Thử Hệ Thống (Acceptance & Testing)

## 1. Tổng Quan
Thư mục này tài liệu hóa ma trận truy xuất yêu cầu (Requirements Traceability Matrix - RTM) và các kịch bản kiểm thử chấp nhận người dùng (User Acceptance Testing - UAT) cho hệ thống **UniSupport** tại **Aurora University**.

---

## 2. Danh Sách Tài Liệu Trong Thư Mục

| Mã Tài Liệu | Tên Tài Liệu | Nội Dung Trọng Tâm |
| :--- | :--- | :--- |
| **`traceability-matrix.md`** | Ma Trận Truy Xuất Yêu Cầu (RTM) | Ánh xạ giữa Yêu cầu nghiệp vụ (Proposal) -> PRD -> Kịch bản kiểm thử UAT. |
| **`test-scenarios.md`** | Kịch Bản Kiểm Thử & UAT Scenarios | Bộ test cases chính thức phục vụ đợt nghiệm thu 10 ngày làm việc của nhà trường. |

---

## 3. Tiêu Chí Nghiệm Thu Chính (Acceptance Criteria)
Theo mục 5.2 của Project Proposal, việc nghiệm thu đợt UAT 10 ngày làm việc dựa trên các tiêu chí bắt buộc sau:
1. **Chức năng:** Các luồng chính của ba phân hệ (Sinh viên, Nhân viên, Quản lý) hoạt động đúng và ổn định.
2. **Bảo mật & Phân quyền:** Cơ chế đăng nhập và phân quyền RBAC 3 vai trò hoạt động chính xác.
3. **Chất lượng:** Không còn lỗi làm gián đoạn chức năng chính (Critical/Blocker bugs).
4. **Tài liệu:** Bàn giao đầy đủ mã nguồn, cơ sở dữ liệu (ERD) và tài liệu hướng dẫn sử dụng theo cam kết.
# Kịch Bản Kiểm Thử Chấp Nhận Người Dùng (UAT Test Scenarios Specification)

## 1. Tiêu Chuẩn Đánh Giá UAT (Acceptance Criteria & Test Standards)
- **Môi trường thử nghiệm:** Staging Environment (`https://staging-unisupport.aurora.edu.vn`).
- **Thời gian UAT:** 10 ngày làm việc.
- **Quy tắc Đạt (Pass Criteria):** $100\%$ các Test Case mức Critical/High đạt Pass, không còn lỗi An toàn thông tin hoặc Lỗi gián đoạn Luồng công việc (Blocking Issues).

## 2. Phân Hệ Sinh Viên (Student Portal UAT)

### Scenario ID: `UAT-STU-02` - Sinh viên Khởi tạo Ticket & Kiểm soát Idempotency
- **Mục tiêu:** Kiểm tra sinh viên tạo Ticket mới thành công kèm file đính kèm, kiểm tra validation Form và cơ chế Idempotency Key chống ghi nhận trùng dữ liệu.
- **Tiền điều kiện:** Sinh viên `stu01` đã đăng nhập vào hệ thống.

| Step | Thao Tác Kiểm Thử | Dữ Liệu Đầu Vào | Kết Quả Mong Đợi (Expected Result) | HTTP / DB Check | Pass/Fail |
| :---: | :--- | :--- | :--- | :--- | :---: |
| 1 | Bấm nút "Tạo Ticket" | - | Hiển thị Form Modal tạo Ticket kèm `client_request_id` sinh tự động. | UI Render | Pass |
| 2 | Nhập Form hợp lệ và đính kèm file | Category: "Đào tạo"<br><br>Title: "Xin hoãn thi môn CSDL"<br><br>Desc: "Do sự cố sức khỏe..."<br><br>File: `xac_nhan.pdf` ($2\text{MB}$) | Form điền đầy đủ dữ liệu, file đính kèm hợp lệ. | Client Validation Pass | Pass |
| 3 | Click đúp nút "Gửi yêu cầu" 3 lần liên tiếp | Thao tác click liên tục ($< 500\text{ ms}$) | Hệ thống chỉ tạo 01 Ticket duy nhất (VD: `TK-20261009-0001`), hiển thị Toast thành công. | HTTP 201<br><br>`tickets COUNT = 1` | Pass |
| 4 | Thử tạo Ticket với file vượt $5\text{MB}$ | File: `video_minh_chung.mp4` ($12\text{MB}$) | Hệ thống từ chối file ngay tại Client, báo lỗi: "Dung lượng file vượt quá giới hạn 5MB." | 400 Bad Request<br><br>`FILE_EXCEEDS_LIMIT` | Pass |
| 5 | Thử tạo Ticket để trống Mô tả | Title: "Cần hỗ trợ"<br><br>Desc: "" (bỏ trống) | Hệ thống chặn submit, hiển thị lỗi validation dưới trường Mô tả. | Client Form Validation | Pass |

## 3. Phân Hệ Nhân Viên (Staff Operations UAT)

### Scenario ID: `UAT-STF-03` - Chuyển Tiếp Ticket Sang Phòng Ban Khác
- **Mục tiêu:** Kiểm tra chức năng chuyển Ticket không đúng thẩm quyền sang phòng ban chuyên trách, xác minh FSM state chuyển `TRANSFERRED` và `assignee_id` bị xóa về `NULL`.
- **Tiền điều kiện:** Nhân viên Phòng Đào tạo `staff_edu` đang mở Ticket `TK-20261009-0002` ở trạng thái `IN_PROGRESS`.

| Step | Thao Tác Kiểm Thử | Dữ Liệu Đầu Vào | Kết Quả Mong Đợi (Expected Result) | HTTP / DB Check | Pass/Fail |
| :---: | :--- | :--- | :--- | :--- | :---: |
| 1 | Bấm nút "Chuyển phòng ban" | - | Hiển thị Modal chọn phòng ban đích và nhập lý do. | UI Render | Pass |
| 2 | Chọn trùng phòng ban hiện tại | Target Dept: "Phòng Đào tạo" | Option "Phòng Đào tạo" bị disable hoặc hệ thống báo lỗi nếu cố chọn. | Client Guard | Pass |
| 3 | Nhập lý do quá ngắn ($< 10$ ký tự) | Lý do: "Sai phong" | Báo lỗi dưới Textarea: "Lý do chuyển tiếp tối thiểu 10 ký tự." | Client Validation | Pass |
| 4 | Nhập thông tin hợp lệ và bấm "Xác nhận" | Target Dept: "Phòng Tài chính"<br><br>Lý do: "Yêu cầu liên quan đến miễn giảm học phí." | Chuyển phòng thành công, Toast thông báo thành công, tự động điều hướng về Queue làm việc. | HTTP 200 OK<br><br>`status = TRANSFERRED`<br><br>`assignee_id = NULL` | Pass |
| 5 | Kiểm tra Queue Phòng Tài chính | Log in bằng `staff_fin` | Ticket `TK-20261009-0002` xuất hiện trong Tab "Ticket chờ tiếp nhận" của Phòng Tài chính. | HTTP 200 OK | Pass |

### Scenario ID: `UAT-STF-05` - Ghi Nhận Kết Quả & Hoàn Tất Giải Quyết Ticket
- **Mục tiêu:** Kiểm tra quy tắc bắt buộc nhập `resolution_note`, chuyển trạng thái FSM sang `RESOLVED` và khởi chạy bộ đếm thời gian.
- **Tiền điều kiện:** Nhân viên `staff_fin` đang phụ trách Ticket `TK-20261009-0003` ở trạng thái `IN_PROGRESS`.

| Step | Thao Tác Kiểm Thử | Dữ Liệu Đầu Vào | Kết Quả Mong Đợi (Expected Result) | HTTP / DB Check | Pass/Fail |
| :---: | :--- | :--- | :--- | :--- | :---: |
| 1 | Bấm nút "Hoàn thành & Đóng Ticket" | - | Hiển thị Modal nhập kết quả giải quyết. | UI Render | Pass |
| 2 | Nhập chuỗi chỉ chứa khoảng trắng | `resolution_note`: "   " | Hệ thống chặn submit, báo lỗi: "Kết quả giải quyết không được để trống." | 400 Bad Request<br><br>`INVALID_INPUT` | Pass |
| 3 | Nhập đầy đủ nội dung giải quyết hợp lệ | `resolution_note`: "Đã miễn giảm 50% học phí kỳ 1 cho sinh viên theo QĐ #123." | Lưu kết quả thành công, Ticket đổi trạng thái thành `RESOLVED`, lưu `resolved_at`. | HTTP 200 OK<br><br>`status = RESOLVED`<br><br>`resolved_at IS NOT NULL` | Pass |
| 4 | Kiểm tra quyền chỉnh sửa sau khi Complete | `staff_fin` bấm sửa nội dung kết quả | Hệ thống vô hiệu hóa toàn bộ các nút chỉnh sửa/thao tác trên Ticket. | UI Readonly Mode | Pass |

## 4. Phân Hệ Bảo Mật & Phân Quyền (Security & Privacy UAT)

### Scenario ID: `UAT-SEC-02` - Kiểm Soát Quyền Xem & Stream File Đính Kèm (Zero Public Access)
- **Mục tiêu:** Đảm bảo file đính kèm lưu ở thư mục Private, bắt buộc xác thực token và chỉ cho phép người dùng có quyền hợp lệ xem/stream file.
- **Tiền điều kiện:** Sinh viên A (`stu_A`) có Ticket chứa file `minh_chung_A.pdf` (ID: `att_1001`). Sinh viên B (`stu_B`) không sở hữu Ticket này.

| Step | Thao Tác Kiểm Thử | Dữ Liệu Đầu Vào | Kết Quả Mong Đợi (Expected Result) | HTTP / DB Check | Pass/Fail |
| :---: | :--- | :--- | :--- | :--- | :---: |
| 1 | Sinh viên A xem file đính kèm của mình | Session Sinh viên A | Backend stream thành công dữ liệu file `minh_chung_A.pdf`. | HTTP 200 OK<br><br>`Content-Type: application/pdf` | Pass |
| 2 | Truy cập URL file trực tiếp không qua Token | `GET /api/v1/attachments/att_1001` (Không gửi Bearer Token) | Hệ thống từ chối truy cập. | HTTP 401 Unauthorized | Pass |
| 3 | Sinh viên B dùng Token của mình truy cập URL file của Sinh viên A | Session Sinh viên B<br><br>`GET /api/v1/attachments/att_1001` | Hệ thống chặn phân quyền dữ liệu. | HTTP 403 Forbidden<br><br>`FORBIDDEN_ACCESS` | Pass |
| 4 | Nhân viên thuộc phòng ban thụ lý Ticket xem file | Session Nhân viên `staff_edu` | Tải/Xem file thành công do đúng phạm vi phòng ban. | HTTP 200 OK | Pass |
# Yêu Cầu Về Ma Trận Truy Xuất (Requirements Traceability Matrix - RTM)

## 1. Mục Tiêu Ma Trận Truy Xuất Yêu Cầu (RTM Scope)
Ma trận RTM liên kết 1:1 từ Yêu cầu Mục tiêu Dự án (Project Proposal), Yêu cầu Chức năng/Phi chức năng (PRD Specification), Lớp API/Data Model và Kịch bản Kiểm thử Chấp nhận Người dùng (UAT Test Scenarios). Ma trận đảm bảo **100%** các tính năng cam kết đều được hiện thực hóa kỹ thuật và có test case nghiệm thu tương ứng.

## 2. Bảng Ma Trận Truy Xuất Chi Tiết (Traceability Matrix)

| Mã Yêu Cầu Proposal | Mã Chức Năng PRD | Tên Chức Năng PRD | Endpoints API Liên Quan | Mã Kịch Bản UAT | Trạng Thái Dev |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **M1: Student** | `FR-STU-01` | Đăng nhập SSO/Local Sinh viên | `POST /api/v1/auth/login` | `UAT-STU-01` | Ready |
| | `FR-STU-02` | Khởi tạo Ticket & Upload minh chứng | `POST /api/v1/tickets` | `UAT-STU-02` | Ready |
| | `FR-STU-03` | Theo dõi tiến độ & Bổ sung hồ sơ | `GET /api/v1/tickets/{id}`<br>`POST /api/v1/tickets/{id}/supplement` | `UAT-STU-03` | Ready |
| | `FR-STU-04` | Xem kết quả giải quyết & Đánh giá CSAT | `POST /api/v1/tickets/{id}/rate` | `UAT-STU-04` | Ready |
| **M2: Staff** | `FR-STF-01` | Đăng nhập Phân hệ Cán bộ | `POST /api/v1/auth/login` | `UAT-STF-01` | Ready |
| | `FR-STF-02` | Tiếp nhận Queue, Phân loại & Priority | `POST /api/v1/staff/tickets/{id}/claim`<br>`PATCH /api/v1/staff/tickets/{id}/priority` | `UAT-STF-02` | Ready |
| | `FR-STF-03` | Chuyển tiếp phòng ban liên quan | `POST /api/v1/staff/tickets/{id}/transfer` | `UAT-STF-03` | Ready |
| | `FR-STF-04` | Yêu cầu Sinh viên bổ sung hồ sơ | `POST /api/v1/staff/tickets/{id}/request-info` | `UAT-STF-04` | Ready |
| | `FR-STF-05` | Hoàn tất giải quyết Ticket | `POST /api/v1/staff/tickets/{id}/resolve` | `UAT-STF-05` | Ready |
| **M3: Manager** | `FR-MNG-01` | Đăng nhập Phân hệ Quản lý | `POST /api/v1/auth/login` | `UAT-MNG-01` | Ready |
| | `FR-MNG-02` | Dashboard Giám sát & Phân công Công việc | `GET /api/v1/reports/dashboard`<br>`POST /api/v1/staff/tickets/{id}/assign` | `UAT-MNG-02` | Ready |
| | `FR-MNG-03` | Báo cáo Thống kê SLA & Bảng điểm CSAT | `GET /api/v1/reports/sla-csat` | `UAT-MNG-03` | Ready |
| | `FR-MNG-04` | Quản trị Tài khoản & Phân quyền Vai trò | `POST/PUT/DELETE /api/v1/users` | `UAT-MNG-04` | Ready |
| **NFR: Bảo mật** | `NFR-SEC-01` | Chống giả mạo & Phân quyền RBAC 4 Vai trò | `AuthMiddleware`, `RoleGuard` | `UAT-SEC-01` | Ready |
| | `NFR-SEC-02` | Bảo mật Stream File & Zero Public Access | `GET /api/v1/attachments/{id}` | `UAT-SEC-02` | Ready |
| | `NFR-SEC-03` | Ghi vết Tra soát Append-Only Audit Log | `GET /api/v1/audit-logs` | `UAT-SEC-03` | Ready |
| **NFR: Hiệu năng** | `NFR-PER-01` | Đảm bảo tải $\ge 150\text{ CCU}$ & $P_{95} < 1\text{s}$ | All Private APIs | `UAT-PER-01` | Ready |
# Thiết Kế RESTful API Chuẩn (RESTful API Design Specification)

## 1. Nguyên Tắc Thiết Kế Chung (General API Standards)
- **Base URL:** `https://api-unisupport.aurora.edu.vn/api/v1`
- **Định dạng Truyền/Nhận dữ liệu:** `application/json` (trừ API Upload file sử dụng `multipart/form-data`).
- **Authentication & Authorization:** Header `Authorization: Bearer <JWT_ACCESS_TOKEN>` áp dụng cho tất cả API Private.
- **Pagination Standard:** Quản lý bằng Request Query Params `page` (Mặc định `1`) và `limit` (Mặc định `20`, Tối đa `50`).
- **Idempotency Handling:** API tạo mới (`POST /tickets`) bắt buộc gửi Header `X-Client-Request-ID: <UUID_v4>`.

---

## 2. Phân Hệ Xác Thực (`/api/v1/auth`)

### 2.1. `POST /api/v1/auth/login`
- **Mô tả:** Đăng nhập hệ thống bằng tài khoản nhà trường (SSO hoặc Local Account).
- **Headers:** `Content-Type: application/json`
- **Request Body:**
```json
{
  "username": "stu20260001",
  "password": "Password123!"
}
```
- **Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "user_id": "usr_stu_20260001",
    "full_name": "Nguyễn Văn A",
    "role": "STUDENT",
    "department_id": null,
    "access_token": "eyJhbGciOi...xYZ123",
    "token_type": "Bearer",
    "expires_in": 900
  }
}
```

### 2.2. `POST /api/v1/auth/logout`
- **Mô tả:** Đăng xuất hệ thống, thêm Token hiện tại vào Redis Blacklist.
- **Headers:** `Authorization: Bearer <token>`
- **Response (200 OK):**
```json
{
  "success": true,
  "message": "Đăng xuất thành công."
}
```

---

## 3. Phân Hệ Sinh Viên (`/api/v1/student`)

### 3.1. `POST /api/v1/student/tickets`
- **Mô tả:** Khởi tạo Ticket mới kèm minh chứng.
- **Headers:** `Authorization: Bearer <token>`, `Content-Type: multipart/form-data`, `X-Client-Request-ID: <UUID_v4>`
- **Request Form-Data:**
  - `category_id`: `"cat_edu_01"` (String, Required)
  - `title`: `"Xin hoãn thi môn CSDL"` (String, Required, 10-200 chars)
  - `description`: `"Em bị ốm vào ngày thi..."` (String, Required, 20-2000 chars)
  - `attachments`: Binary File Array (Optional, Max 3 files, $\le 5\text{MB/file}$)
- **Response (201 Created):**
```json
{
  "success": true,
  "data": {
    "ticket_id": "TK-20261009-0001",
    "status": "NEW",
    "created_at": "2026-10-09T13:15:00.000Z",
    "sla_target_at": "2026-10-10T13:15:00.000Z"
  }
}
```

### 3.2. `GET /api/v1/student/tickets`
- **Mô tả:** Lấy danh sách Ticket cá nhân của Sinh viên.
- **Query Params:** `status` (Optional), `page` (Default 1), `limit` (Default 20).
- **Response (200 OK):**
```json
{
  "success": true,
  "data": [
    {
      "ticket_id": "TK-20261009-0001",
      "category_name": "Đào tạo",
      "title": "Xin hoãn thi môn CSDL",
      "status": "NEW",
      "created_at": "2026-10-09T13:15:00.000Z"
    }
  ],
  "pagination": {
    "current_page": 1,
    "limit": 20,
    "total_records": 1,
    "total_pages": 1
  }
}
```

### 3.3. `POST /api/v1/student/tickets/{ticket_id}/supplement`
- **Mô tả:** Gửi bổ sung tài liệu/ghi chú khi Ticket ở trạng thái `NEED_MORE_INFO`.
- **Headers:** `Content-Type: multipart/form-data`
- **Request Form-Data:**
  - `note`: `"Em đã bổ sung giấy khám sức khỏe."` (String, Required)
  - `attachments`: Binary File Array (Optional)
- **Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "ticket_id": "TK-20261009-0001",
    "status": "IN_PROGRESS",
    "updated_at": "2026-10-09T14:00:00.000Z"
  }
}
```

### 3.4. `POST /api/v1/student/tickets/{ticket_id}/rate`
- **Mô tả:** Gửi đánh giá sao và nhận xét cho Ticket đã hoàn tất.
- **Request Body:**
```json
{
  "rating_score": 5,
  "rating_comment": "Nhân viên hỗ trợ rất nhanh và nhiệt tình!"
}
```

---

## 4. Phân Hệ Nhân Viên (`/api/v1/staff`)

### 4.1. `POST /api/v1/staff/tickets/{ticket_id}/claim`
- **Mô tả:** Tiếp nhận Ticket từ Queue chung của phòng ban và thiết lập độ ưu tiên.
- **Request Body:**
```json
{
  "priority": "HIGH"
}
```
- **Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "ticket_id": "TK-20261009-0001",
    "status": "IN_PROGRESS",
    "assignee_id": "usr_stf_1002",
    "priority": "HIGH"
  }
}
```

### 4.2. `POST /api/v1/staff/tickets/{ticket_id}/transfer`
- **Mô tả:** Điều chuyển Ticket sang phòng ban khác.
- **Request Body:**
```json
{
  "target_department_id": "dept_finance_01",
  "transfer_reason": "Yêu cầu này thuộc thẩm quyền giải quyết học phí của Phòng Tài chính."
}
```

### 4.3. `POST /api/v1/staff/tickets/{ticket_id}/resolve`
- **Mô tả:** Nhập kết quả giải quyết và chuyển trạng thái Ticket sang `RESOLVED`.
- **Request Body:**
```json
{
  "resolution_note": "Đã chấp nhận đơn hoãn thi môn CSDL. Sinh viên xem lịch thi bổ sung trên Portal.",
  "attachments": []
}
```

---

## 5. Phân Hệ Quản Lý (`/api/v1/manager`)

### 5.1. `GET /api/v1/manager/dashboard/summary`
- **Mô tả:** Lấy danh mục chỉ số KPI Dashboard (Sử dụng Cache Redis).
- **Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "total_tickets": 1250,
    "new_tickets": 45,
    "in_progress_tickets": 120,
    "resolved_tickets": 1050,
    "overdue_tickets": 12,
    "csat_avg_score": 4.85
  }
}
```

### 5.2. `POST /api/v1/manager/users`
- **Mô tả:** Tạo mới tài khoản nhân viên/quản lý và phân quyền.
- **Request Body:**
```json
{
  "user_code": "STF20260010",
  "full_name": "Trần Thị B",
  "email": "b.tran@aurora.edu.vn",
  "role": "STAFF",
  "department_id": "dept_edu_01"
}
```

---

## 6. File & Storage (`/api/v1/common`)

### 6.1. `GET /api/v1/attachments/{file_id}`
- **Mô tả:** Stream file đính kèm trực tiếp (Kiểm tra quyền sở hữu qua `DataScopeMiddleware`).
- **Headers:** `Authorization: Bearer <token>`
- **Response (200 OK):** Binary Data Stream (`Content-Type: application/pdf` hoặc `image/png`).

---

## 7. Mã Lỗi Hệ Thống Chuẩn (Global Error Response Spec)
Mọi trường hợp lỗi hệ thống hoặc Validation đều trả về Cấu trúc JSON thống nhất:
```json
{
  "success": false,
  "error": {
    "code": "INVALID_INPUT",
    "message": "Dữ liệu đầu vào không hợp lệ.",
    "details": [
      {
        "field": "description",
        "issue": "Mô tả vấn đề phải có độ dài tối thiểu 20 ký tự."
      }
    ]
  },
  "timestamp": "2026-10-09T13:15:00.123Z",
  "trace_id": "tr_9988776655443322"
}
```

| HTTP Code | Enum `error.code` | Nguyên Nhân & Kịch Bản |
| :--- | :--- | :--- |
| **400** | `INVALID_INPUT` | Lỗi Validation dữ liệu Form / Query Params. |
| **400** | `FILE_EXCEEDS_LIMIT` | File upload vượt quá $5\text{MB}$ hoặc sai extension. |
| **401** | `UNAUTHORIZED` | Token hết hạn, sai chữ ký hoặc bị đưa vào Blacklist. |
| **403** | `FORBIDDEN_ACCESS` | Vi phạm ma trận phân quyền RBAC hoặc Data Scope. |
| **404** | `RESOURCE_NOT_FOUND` | Không tìm thấy Ticket ID hoặc File ID yêu cầu. |
| **409** | `DUPLICATE_REQUEST` | Vi phạm Idempotency Key (`X-Client-Request-ID` bị trùng). |
| **429** | `TOO_MANY_REQUESTS` | Vi phạm ngưỡng Rate Limit ($> 60\text{ requests/phút}$). |
| **500** | `INTERNAL_SERVER_ERROR` | Lỗi ngoại lệ Server / Database connection failure. |
# Kiến Trúc Tổng Quan (Architecture Overview)

## 1. Mô Hình Mẫu Kiến Trúc (Architectural Pattern)
UniSupport được thiết kế theo mô hình kiến trúc Phân tầng tiêu chuẩn (3-Tier Layered Architecture) dành cho Web Application:

```text
[ Presentation Layer ] ──> Responsive Single Page Application (SPA / Web Client)
           │
           ▼ (HTTPS / RESTful APIs)
[ Application Layer ]  ──> Backend API Server (Node.js / Java Spring / Python)
           │
           ▼
[ Data Layer ]         ──> Relational Database (PostgreSQL / MySQL) + Private File Storage
```

---

## 2. Chi Tiết Các Tầng Kỹ Thuật
### 2.1. Presentation Layer (Frontend)

- **Công nghệ:** HTML5, CSS3, JavaScript Framework (ReactJS / Vue.js) chuẩn hóa Responsive.
- **Đặc điểm:** Hoạt động linh hoạt trên cả trình duyệt máy tính và thiết bị di động. Tích hợp mô-đun chuyển đổi 2 ngôn ngữ Tiếng Việt & Tiếng Anh.

### 2.2. Application Layer (Backend)

- **Công nghệ:** RESTful API Service kết nối bảo mật HTTPS.
- **Các dịch vụ cốt lõi:**
  - **Auth & Security Service:** Xác thực người dùng, cấp Token/Session và kiểm tra quyền RBAC.
  - **Ticket Core Service:** Xử lý nghiệp vụ tạo Ticket, sinh mã Ticket duy nhất (`ADR-001`), chuyển đổi trạng thái và đóng Ticket.
  - **File Management Service:** Tiếp nhận upload, xác thực định dạng/dung lượng file (PDF/Image <= 5MB) và kiểm soát quyền truy cập file (`ADR-003`).
  - **Notification Service:** Phát thông báo nội bộ hệ thống (In-app Notification) cho người dùng.
  - **Reporting Service:** Tổng hợp số liệu Dashboard, thời gian xử lý trung bình và chỉ số hài lòng.

### 2.3. Data Layer (Database & Storage)

- **Cơ sở dữ liệu:** RDBMS (PostgreSQL hoặc MySQL) lưu trữ dữ liệu quan hệ.
- **Lưu trữ File:** Thư mục bảo vệ (Private Folder) trên Server của nhà trường, ngăn chặn truy cập trực tiếp qua Public URL (`ADR-003`).
# Mô Hình Dữ Liệu & ERD (Data Model)

## 1. Sơ Đồ Quan Hệ Entiy (ERD Overview)

```text
 ┌─────────────────┐       1:N       ┌─────────────────┐
 │      users      │─────────────────┤     tickets     │
 └────────┬────────┘                 └────────┬────────┘
          │                                   │ 1:N
          │ 1:N                               ▼
          │                          ┌─────────────────┐
          │                          │   attachments   │
          ▼                          └─────────────────┘
 ┌─────────────────┐                          │ 1:N
 │   audit_logs    │                          ▼
 └─────────────────┘                 ┌─────────────────┐
                                     │  notifications  │
                                     └─────────────────┘
```

## 2. Cấu Trúc Các Bảng Cơ Sở Dữ Liệu

### 2.1. Bảng `users` (Tài khoản người dùng)

- `id` (VARCHAR/UUID, Primary Key): ID người dùng.
- `username` (VARCHAR, Unique): Tên đăng nhập / Mã sinh viên / Email công vụ.
- `password_hash` (VARCHAR): Mật khẩu đã mã hóa.
- `full_name` (VARCHAR): Họ và tên.
- `role` (ENUM): Vai trò (`STUDENT`, `STAFF`, `MANAGER`, `ADMIN`).
- `department_id` (VARCHAR, Foreign Key): ID phòng ban (nếu là Nhân viên).
- `status` (VARCHAR): Trạng thái tài khoản (`ACTIVE`, `INACTIVE`).

### 2.2. Bảng `tickets` (Thông tin Phiếu hỗ trợ)

- `ticket_id` (VARCHAR, Primary Key): Mã Ticket duy nhất (ví dụ: `TK-20261007-001`).
- `student_id` (VARCHAR, Foreign Key → `users.id`): Sinh viên khởi tạo.
- `category_id` (VARCHAR): Nhóm vấn đề chọn xử lý.
- `title` (VARCHAR): Tiêu đề ngắn gọn.
- `description` (TEXT): Nội dung mô tả chi tiết vấn đề.
- `department_id` (VARCHAR): Phòng ban chịu trách nhiệm thụ lý.
- `assignee_id` (VARCHAR, Foreign Key → `users.id`): Nhân viên được gán xử lý.
- `priority` (ENUM): Độ ưu tiên (`LOW`, `MEDIUM`, `HIGH`, `URGENT`).
- `status` (ENUM): Trạng thái (`NEW`, `IN_PROGRESS`, `NEED_MORE_INFO`, `TRANSFERRED`, `CLOSED`, `REJECTED`).
- `resolution_note` (TEXT): Kết quả giải quyết của nhân viên.
- `rating_score` (INT): Đánh giá sao của sinh viên (1-5 sao).
- `rating_comment` (TEXT): Nhận xét đánh giá hài lòng.
- `created_at`, `updated_at`, `closed_at` (TIMESTAMP): Các mốc thời gian.

### 2.3. Bảng `attachments` (File đính kèm)

- `id` (VARCHAR/UUID, Primary Key): ID bản ghi file.
- `ticket_id` (VARCHAR, Foreign Key → `tickets.ticket_id`): Mã Ticket liên kết.
- `file_name` (VARCHAR): Tên file gốc.
- `file_path` (VARCHAR): Đường dẫn lưu file riêng tư trên Server.
- `file_size` (INT): Dung lượng file tính bằng bytes (Max 5MB).
- `file_type` (VARCHAR): Định dạng MIME (`application/pdf`, `image/png`, `image/jpeg`).
- `uploaded_by` (VARCHAR, Foreign Key → `users.id`): Người đăng file.

### 2.4. Bảng `audit_logs` (Nhật ký rà soát)

- `id` (BIGINT, Primary Key, Auto Increment).
- `user_id` (VARCHAR, Foreign Key → `users.id`): Người thực hiện.
- `action` (VARCHAR): Hành động (`CREATE_TICKET`, `TRANSFER_DEPT`, `CLOSE_TICKET`, ...).
- `target_id` (VARCHAR): Đối tượng chịu tác động (Mã Ticket, User ID).
- `ip_address` (VARCHAR): Địa chỉ IP truy cập.
- `timestamp` (TIMESTAMP): Thời điểm thực hiện.
# Thiết Kế Kiến Trúc & Kỹ Thuật Hệ Thống (System Architecture)

## 1. Tổng Quan
Thư mục này tài liệu hóa chi tiết kiến trúc tổng thể, mô hình dữ liệu, thiết kế RESTful API và cơ chế bảo mật của hệ thống **UniSupport** tại **Aurora University**. Các thiết kế đảm bảo hệ thống đáp ứng tốt quy mô 3.000 sinh viên, bảo mật dữ liệu và triển khai mượt mà trên hạ tầng của nhà trường.

---

## 2. Cấu Trúc Tài Liệu Kiến Trúc

| Mã Tài Liệu | Tên Tài Liệu | Nội Dung Trọng Tâm |
| :--- | :--- | :--- |
| **`system-context.md`** | Sơ Đồ Ngữ Cảnh (System Context) | Vị trí của UniSupport trong hệ sinh thái ứng dụng của Aurora University. |
| **`architecture-overview.md`** | Kiến Trúc Tổng Quan | Mô hình phân tầng Web Application (Frontend Responsive, Backend API Server, CSDL). |
| **`data-model.md`** | Mô Hình Dữ Liệu & ERD | Sơ đồ ERD và chi tiết bảng cơ sở dữ liệu quan hệ (PostgreSQL/MySQL). |
| **`api-design.md`** | Thiết Kế RESTful API | Danh mục end-points chuẩn RESTful cho 3 phân hệ (Sinh viên, Nhân viên, Quản lý). |
| **`security-design.md`** | Thiết Kế Bảo Mật & Xác Thực | Cơ chế xác thực Session/JWT, phân quyền RBAC 3 vai trò và bảo vệ File. |
| **`technical-decisions/`** | Các Quyết Định Kiến Trúc (ADRs) | Báo cáo ADR-001 (Ticket ID), ADR-002 (RBAC), ADR-003 (File Storage). |
# 1. Tổng Quan Kiến Trúc Bảo Mật (Security Architecture)
Hệ thống UniSupport áp dụng mô hình bảo mật đa lớp (Defense in Depth), bao gồm các trụ cột chính: Xác thực tập trung dựa trên Token (JWT Stateless Authentication), Phân quyền theo ngữ cảnh & phạm vi dữ liệu (RBAC & Data Isolation Middleware), Bảo mật tài nguyên lưu trữ File (Private Storage Streaming), Chống tấn công lỗ hổng OWASP Top 10 và Nhật ký tra soát vĩnh viễn (Append-Only Audit Trail).

---

# 2. Xác Thực & Quản Lý Phiên (Authentication & Session Management)

## 2.1. Cấu Trúc Mã Xác Thực JWT (JSON Web Token Specification)
Mọi request thành công từ phía Client đều phải gửi kèm Header: `Authorization: Bearer <JWT_Access_Token>`.
- **Thuật toán mã hóa:** HMAC-SHA256 (HS256) hoặc RSA-256 (RS256).
- **Thời hạn hiệu lực:**
  - **Access Token:** Hết hạn sau 15 phút (`exp = 900s`).
  - **Refresh Token:** Hết hạn sau 7 ngày (`exp = 604800s`), lưu trữ trong HTTP-Only, Secure, `SameSite=Strict` Cookie để chống tấn công XSS/CSRF.
- **Payload Chuẩn của JWT Access Token:**
```json
{
  "sub": "usr_stu_20260001",
  "iss": "unisupport-auth-service",
  "iat": 1791523200,
  "exp": 1791524100,
  "user_code": "SV20260001",
  "full_name": "Nguyễn Văn A",
  "email": "a.nguyen@aurora.edu.vn",
  "role": "STUDENT",
  "department_id": null
}
```
---
## 2.2. Cơ Chế Vô Hiệu Hóa Token Tức Thì (Token Revocation / Blacklisting)
Khi Admin thực hiện khóa tài khoản (`status = INACTIVE`) hoặc người dùng bấm Đăng xuất, Backend bắt buộc phải lưu `jti` (Token ID) hoặc `user_id` vào Redis Blacklist kèm theo thời gian hết hạn TTL (bằng thời gian còn lại của Access Token).

Mọi API Private khi verify JWT phải kiểm tra sự tồn tại của Token/User trong Redis Blacklist. Nếu có $\rightarrow$ Trả về lỗi `401 UNAUTHORIZED`.

# 3. Lớp Middleware Phân Quyền & Isolate Dữ Liệu (RBAC & Data Isolation Middleware)
Hệ thống cài đặt 3 Lớp Middleware bảo mật kiểm soát theo thứ tự:

```plaintext
[Incoming Request] ──> [1. AuthMiddleware] ──> [2. RoleGuardMiddleware] ──> [3. DataScopeMiddleware] ──> [Controller]
```
---
1. **AuthMiddleware (Xác thực Identity):** Decrypt Bearer Token, kiểm tra chữ ký và Hạn sử dụng (`exp`). Trích xuất `user_id`, `role`, `department_id` gắn vào Context Request.
2. **RoleGuardMiddleware (Xác thực Quyền vai trò):**
   - Chặn các request vi phạm vai trò (Ví dụ: `STUDENT` cố gọi Endpoint `/api/v1/staff/*` $\rightarrow$ Trả về `403 FORBIDDEN_ACCESS`).
3. **DataScopeMiddleware (Isolate Phạm vi Dữ liệu):**
   - **Đối với STUDENT:** Tự động chèn điều kiện Query CSDL: `WHERE student_id = current_user.id`. Nếu `student_id` trên Ticket khác `current_user.id` $\rightarrow$ Trả về `403 FORBIDDEN_ACCESS` (Chống lừa đảo đổi ID URL).
   - **Đối với STAFF:** Tự động chèn điều kiện Query CSDL: `WHERE department_id = current_user.department_id`. Nhân viên chỉ thao tác được trên Ticket thuộc phòng ban mình.
   - **Đối với MANAGER / ADMIN:** Cho phép bypass điều kiện kiểm tra `department_id` theo phạm vi ủy quyền.

## 4. An Toàn File, Sanitize Input & Chống OWASP Top 10

### 4.1. Sanitize Input & Chống Injection (SQLi / XSS)
- **Chống SQL Injection:** 100% các câu lệnh truy vấn CSDL bắt buộc sử dụng Parameterized Queries hoặc qua ORM / Query Builder. Tuyệt đối không cộng chuỗi SQL.
- **Chống Cross-Site Scripting (XSS):** Mọi trường dữ liệu dạng Text đầu vào (`title`, `description`, `resolution_note`) phải qua thư viện Sanitize (loại bỏ toàn bộ các thẻ `<script>`, `<iframe>`, `javascript:` protocol) trước khi lưu CSDL.
- **Cấu hình Security Headers (Helmet Middleware):** Trả về đầy đủ các Header an toàn:
  - `Content-Security-Policy` (CSP)
  - `X-Content-Type-Options: nosniff`
  - `X-Frame-Options: DENY` (Chống Clickjacking)
  - `Strict-Transport-Security` (HSTS)

### 4.2. Bảo Mật File Đính Kèm (Thực Thi Theo ADR-003)
- File lưu ngoài Web Root tại đĩa cứng private server (`/var/app/data/attachments/`).
- API phục vụ xem file (`GET /api/v1/attachments/{file_id}`) bắt buộc đi qua `AuthMiddleware` và `DataScopeMiddleware`.
- **Kiểm tra Binary Magic Bytes:** Backend đọc header nhị phân để xác minh file đúng là PDF/PNG/JPG trước khi lưu, chặn đứng file giả mạo extension.
- **Randomize File Name:** Tên file lưu trên đĩa cứng tự động đổi sang UUID v4 để loại bỏ lỗ hổng Path Traversal (`../../`).

## 5. Bảng Mã Lỗi Bảo Mật Chuẩn (Security Error Codes)

| HTTP Status | Error Code | Message Hiển Thị Cho Người Dùng | Kịch Bản Áp Dụng |
| :--- | :--- | :--- | :--- |
| **401** | `UNAUTHORIZED` | "Phiên đăng nhập đã hết hạn. Vui lòng đăng nhập lại." | Token không hợp lệ, hết hạn hoặc thiếu Bearer Token. |
| **401** | `ACCOUNT_DISABLED` | "Tài khoản của bạn đã bị vô hiệu hóa. Vui lòng liên hệ Admin." | Admin khóa tài khoản, Token bị đẩy vào Blacklist. |
| **403** | `FORBIDDEN_ACCESS` | "Bạn không có quyền truy cập vào tài nguyên này." | Khác vai trò hoặc xem Ticket của người khác. |
| **403** | `FORBIDDEN_DEPARTMENT` | "Bạn không có quyền thao tác trên Ticket thuộc phòng ban khác." | Staff cố truy cập Ticket phòng ban khác. |
| **429** | `TOO_MANY_REQUESTS` | "Bạn đã thao tác quá nhiều lần. Vui lòng thử lại sau 1 phút." | Vi phạm Rate Limit (Spam request / brute-force). |
# Sơ Đồ Ngữ Cảnh Hệ Thống (System Context)

## 1. Tổng Quan Ngữ Cảnh
Hệ thống **UniSupport** đóng vai trò là Web Application tập trung duy nhất tiếp nhận, điều phối và xử lý toàn bộ các yêu cầu hỗ trợ từ sinh viên Aurora University. Hệ thống vận hành độc lập trên hạ tầng máy chủ của nhà trường và tương tác trực tiếp với 3 nhóm người dùng chính.

---

## 2. Sơ Đồ Ngữ Cảnh (C4 Context Diagram)

```text
                               ┌─────────────────────────┐
                               │   Sinh Viên (Student)   │
                               │     (3.000 sinh viên)   │
                               └────────────┬────────────┘
                                            │
                                  Gửi Ticket, Tra cứu,
                                  Bổ sung hồ sơ, Đánh giá
                                            │
                                            ▼
 ┌────────────────────────┐    ┌─────────────────────────┐    ┌────────────────────────┐
 │ Nhân Viên (Staff)      │───►│    Hệ Thống Web App    │◄───│  Quản Lý (Manager)     │
 │ (Phòng Đào tạo, CTTT,  │    │       UniSupport        │    │  (Ban Giám hiệu,       │
 │ Tài chính, Kỹ thuật)   │    │  (Aurora University)    │    │   Trưởng phòng ban)    │
 └────────────────────────┘    └─────────────────────────┘    └────────────────────────┘
    Tiếp nhận, Phân loại,          tiếp nhận & Quản lý           Xem Dashboard, Báo cáo,
    Xử lý & Đóng Ticket           Vòng đời Ticket hỗ trợ         Quản trị phân quyền
```

---

## 3. Các Luồng Tương Tác Chính
* **Sinh viên**: Truy cập qua trình duyệt Web Desktop/Mobile để gửi yêu cầu, theo dõi trạng thái qua mã Ticket, tải lên file bổ sung và đánh giá chất lượng dịch vụ.
* **Nhân viên**: Tiếp nhận yêu cầu thuộc phòng ban, điều phối chuyển tiếp, yêu cầu sinh viên bổ sung tài liệu và cập nhật kết quả xử lý chính thức.
8 **Quản lý**: Giám sát tổng quan chỉ số vận hành, khối lượng công việc, theo dõi xu hướng sự cố và cấp quyền tài khoản.
# ADR-001: Quy Tắc Sinh Mã Ticket Duy Nhất (Ticket ID Generation Strategy)

- **Trạng thái (Status):** Accepted (Đã chấp thuận)
- **Ngày quyết định:** 2026-09-15 (Giai đoạn Thiết kế Kiến trúc)
- **Đối tượng áp dụng:** Backend Engineering Team, Database Administrator (DBA)

## 1. Bối Cảnh (Context)
Trong hệ thống UniSupport, mỗi yêu cầu hỗ trợ do sinh viên tạo ra cần một mã định danh duy nhất (`ticket_id`) để phục vụ tra cứu, giao tiếp giữa Sinh viên - Nhân viên - Quản lý, và theo dõi lịch sử trên toàn bộ các kênh (Web App, Email, In-app Notification).

Yêu cầu kỹ thuật bắt buộc:
1. **Dễ đọc & Dễ giao tiếp (Human-readable):** Sinh viên và Nhân viên có thể đọc, chép hoặc tìm kiếm thủ công nhanh chóng.
2. **Duy nhất tuyệt đối (Uniqueness):** Không bị trùng lặp dưới mọi điều kiện vận hành.
3. **Chống tranh chấp đồng thời (Concurrency-safe):** Đảm bảo tính nhất quán (Atomic Increment) khi có hàng trăm sinh viên bấm tạo Ticket cùng một thời điểm.
4. **Idempotency Support:** Kết hợp được với cơ chế Idempotency Key để ngăn tạo mã lặp khi đúp click hoặc mạng gián đoạn.

## 2. Các Phương Án Cân Nhắc (Options Considered)
- **Phương án A: UUID v4** (ví dụ: `c9bf9e57-1685-4c89-bafb-ff5af830be8a`)
  - *Ưu điểm:* Duy nhất tuyệt đối, sinh độc lập ở bất kỳ Node/Service nào mà không cần Lock CSDL.
  - *Nhược điểm:* Quá dài ($36\text{ ký tự}$), sinh viên không thể nhớ hoặc đọc qua điện thoại; làm phình to B-Tree Index trên Database khi lưu dưới dạng String.
- **Phương án B: Auto-increment ID CSDL** (ví dụ: `1`, `2`, `10523`)
  - *Ưu điểm:* Ngắn gọn, hiệu năng Index cực cao.
  - *Nhược điểm:* Lộ số lượng giao dịch thực tế của nhà trường; không chứa thông tin ngày tạo; dễ bị thu thập dữ liệu (Enumeration Attack) nếu lộ API endpoint.
- **Phương án C: Formatted Business Key TK-YYYYMMDD-XXXX** (Được chọn)
  - *Ưu điểm:* Dễ nhớ, chuyên nghiệp, phản ánh trực tiếp ngày tạo yêu cầu, tối ưu B-Tree Index khi sắp xếp theo chuỗi thời gian.
  - *Nhược điểm:* Cần cơ chế cấp phát số thứ tự tăng dần (Sequence) theo ngày an toàn và hiệu năng cao.

## 3. Quy Định Kỹ Thuật Chi Tiết (Detailed Specifications)

### 3.1. Cấu Trúc Mã Ticket (`TK-YYYYMMDD-XXXX`)
Mã Ticket bao gồm 3 thành phần nối với nhau bằng dấu gạch ngang (`-`):

| Thành phần | Định dạng | Ví dụ | Quy tắc Validation & Specs |
| :--- | :--- | :--- | :--- |
| **Prefix** | Chuỗi cố định | `TK` | Viết hoa, đại diện cho Ticket UniSupport. |
| **Date String** | `YYYYMMDD` | `20261009` | Lấy theo múi giờ hệ thống `Asia/Ho_Chi_Minh` (UTC+7) tại thời điểm khởi tạo. |
| **Sequence** | `XXXX` | `0001` | Số thứ tự tăng dần trong ngày, định dạng cố định 4 chữ số (Padded with zeros). |

- **Độ dài cố định:** Đúng $15\text{ ký tự}$ (Ví dụ: `TK-20261009-0001`).
- **Ví dụ mã hợp lệ:** `TK-20261009-0001`, `TK-20261009-0150`, `TK-20261009-9999`.

### 3.2. Cơ Chế Sinh Mã Đảm Bảo Concurrency & Atomic Increment
Để đảm bảo tốc độ sinh mã $< 5\text{ms}$ và không bị trùng lặp khi chạy đa tiến trình (Multi-thread/Multi-node):
- **Sử dụng Atomic Counter trên Redis:**
  - Tạo Redis Key theo ngày: `ticket:sequence:YYYYMMDD` (Ví dụ: `ticket:sequence:20261009`).
  - Sử dụng lệnh Atomic `INCR` của Redis để lấy số thứ tự tiếp theo.
  - Set thời gian hết hạn (TTL) cho Key là $48\text{ giờ}$ kể từ khi khởi tạo Key mới trong ngày (để tự động giải phóng bộ nhớ Redis).

- **Thuật toán xử lý phía Backend (Logic Flow):**
  - **Bước 1:** Lấy ngày hiện tại `YYYYMMDD` theo múi giờ UTC+7.
  - **Bước 2:** Gọi Redis `INCR ticket:sequence:YYYYMMDD` $\rightarrow$ Nhận về giá trị số nguyên $N$.
  - **Bước 3:** Nếu $N == 1$ (Key mới trong ngày), gọi Redis `EXPIRE ticket:sequence:YYYYMMDD 172800` ($48\text{ giờ}$).
  - **Bước 4:** Định dạng $N$ thành chuỗi 4 chữ số: `XXXX = String.format("%04d", N)`.
  - **Bước 5:** Ghép thành `ticket_id = "TK-" + YYYYMMDD + "-" + XXXX`.

- **Phương án Dự phòng (Fallback Mechanism):**
  - Nếu Redis ngắt kết nối/sự cố, Backend tự động chuyển sang query Database Sequence hoặc Atomic Database Transaction:
    `SELECT COALESCE(MAX(SUBSTRING(ticket_id, 13, 4)::INT), 0) + 1 FROM tickets WHERE created_at::date = CURRENT_DATE FOR UPDATE;`

## 4. Hệ Quả & Đánh Giá Kỹ Thuật (Consequences)

### Tích cực (Positive)
- **Trải nghiệm người dùng:** Sinh viên và Nhân viên chỉ cần nhớ 4 số cuối trong ngày để trao đổi nhanh (Ví dụ: *"Kiểm tra Ticket 0001 hôm nay"*).
- **Hiệu năng Indexing:** Do mã chứa ngày `YYYYMMDD` ở đầu, các bản ghi mới luôn được chèn vào cuối B-Tree Index của CSDL, hạn chế tối đa việc phân mảnh Index (Index Fragmentation).
- **An toàn Concurrency:** Lệnh `INCR` của Redis xử lý đơn luồng (Single-threaded) đạt hiệu năng đến hàng chục nghìn request/giây mà không lo tranh chấp dữ liệu.

### Ràng buộc & Giới hạn (Constraints & Limits)
- **Giới hạn $9.999\text{ Ticket/ngày}$:**
  - Khung 4 chữ số (`0001` - `9999`) đáp ứng tối đa $9.999\text{ Ticket}$ tạo mới trong một ngày.
  - Đánh giá quy mô: Dự án phục vụ 3.000 sinh viên, tải đỉnh điểm ước tính $< 500\text{ Ticket/ngày}$. Giới hạn $9.999$ hoàn toàn an toàn.
  - **Kế hoạch mở rộng (Scale-up Plan):** Nếu số Ticket vượt quá $9.999$, hệ thống tự động mở rộng chuỗi `XXXX` thành 5 chữ số (`00001` - `99999`) mà không ảnh hưởng tới logic tra cứu cũ.

## 5. Ràng Buộc Validation & Mã Lỗi Hệ Thống (Error Codes)

| Ràng buộc Kỹ thuật | Xử lý vi phạm | Mã lỗi HTTP & Error Code | Message hiển thị cho Sinh viên |
| :--- | :--- | :--- | :--- |
| **Định dạng Mã Ticket** | Kiểm tra Regex: `^TK-\d{8}-\d{4,5}$` | `400 Bad Request`<br><br>`INVALID_TICKET_ID_FORMAT` | "Mã Ticket không đúng định dạng chuẩn (VD: TK-20261009-0001)." |
| **Quá giới hạn trong ngày** | Khi Counter $> 99.999$ | `500 Internal Server Error`<br><br>`SEQUENCE_LIMIT_EXCEEDED` | "Hệ thống vượt quá số lượng tạo yêu cầu trong ngày. Vui lòng liên hệ Admin." |
| **Trùng lặp Key (Edge case)** | Vi phạm `UNIQUE(ticket_id)` ở CSDL | `409 Conflict`<br><br>`DUPLICATE_TICKET_ID` | "Mã Ticket bị trùng lặp. Hệ thống đang tự động thử lại." (Backend tự retry sinh mã mới). |
# ADR-002: Giải Pháp Phân Quyền Vai Trò (Role-Based Access Control Strategy)

- **Trạng thái (Status):** Accepted (Đã chấp thuận)
- **Ngày quyết định:** 2026-09-15 (Giai đoạn Thiết kế Kiến trúc)
- **Đối tượng áp dụng:** Backend Engineering Team, Frontend Engineering Team

## 1. Bối Cảnh (Context)
Hệ thống UniSupport phục vụ 3 nhóm đối tượng người dùng có trách nhiệm và quyền hạn hoàn toàn tách biệt: Sinh viên, Nhân viên các phòng ban và Ban Quản lý/Admin.

Hệ thống cần một cơ chế kiểm soát truy cập (Access Control) đảm bảo:
1. **Tính đóng gói và an toàn dữ liệu:** Sinh viên không thấy yêu cầu của nhau, Nhân viên không can thiệp phòng ban khác.
2. **Hiệu năng cao:** Kiểm tra quyền nhanh ($< 1\text{ms}$) trên mỗi request.
3. **Đơn giản, dễ bảo trì, dễ triển khai kiểm thử tự động.**

## 2. Các Phương Án Cân Nhắc (Options Considered)

### Phương án A: Attribute-Based Access Control (ABAC - Phân quyền theo Thuộc tính)
- **Ưu điểm:** Cực kỳ linh hoạt, cho phép định nghĩa luật truy cập phức tạp dựa trên ngữ cảnh (Ví dụ: Chỉ cho sửa Ticket vào giờ hành chính, hoặc khi nhiệt độ phòng máy $< 30^\circ\text{C}$).
- **Nhược điểm:** Phức tạp quá mức cần thiết; tốn thời gian phát triển và chi phí tính toán CPU cho từng request; vượt quá ngân sách và phạm vi dự án UniSupport.

### Phương án B: Static Role-Based Access Control (RBAC - Phân quyền 4 Vai trò Cố định - Được chọn)
- **Ưu điểm:** Cấu trúc phân cấp minh bạch, tích hợp hoàn hảo với JWT Claims, chi phí kiểm tra quyền cực thấp, bám sát 100% yêu cầu bài toán.
- **Nhược điểm:** Không hỗ trợ việc tạo thêm các Vai trò tùy biến động (Custom Dynamic Roles) do người dùng tự định nghĩa trên UI (Phù hợp hoàn toàn với phạm vi Out of Scope của dự án).

## 3. Quy Định Kỹ Thuật Chi Tiết (Detailed Specifications)

### 3.1. Danh Mục 4 Vai Trò Hệ Thống (System Role Definitions)

| Mã Vai Trò (`role`) | Tên Vai Trò | Phạm Vi Quyền Hạn Chi Tiết | Phạm Vi Dữ Liệu TRUY CẬP (Data Scope) |
| :--- | :--- | :--- | :--- |
| **STUDENT** | Sinh viên | Tạo Ticket, xem tiến độ, gửi bổ sung file, gửi đánh giá CSAT ($1-5$ sao). | Chỉ dữ liệu cá nhân: `student_id == current_user.id`. |
| **STAFF** | Nhân viên | Tiếp nhận (Claim), phân loại priority, chuyển phòng ban, yêu cầu bổ sung, ghi kết quả và giải quyết Ticket. | Chỉ dữ liệu phòng ban phụ trách: `department_id == current_user.department_id`. |
| **MANAGER** | Quản lý Phòng ban | Toàn bộ quyền của STAFF + Phân công/Thu hồi Ticket, xem Dashboard chỉ số SLA & CSAT phòng ban. | Dữ liệu thuộc phòng ban phụ trách: `department_id == current_user.department_id`. |
| **ADMIN** | Quản trị Hệ thống | Toàn quyền Quản trị Tài khoản (Tạo, sửa, khóa user), xem Dashboard/Báo cáo toàn trường, xem Audit Log. | Toàn bộ hệ thống (Global Scope): Không bị giới hạn `department_id`. |

### 3.2. Thiết Kế Ma Trận Phân Quyền Middleware (RBAC Authorization Matrix)
Backend triển khai lớp Annotation/Decorator `@RequireRole(...)` hoặc Middleware kiểm tra quyền truy cập trên từng API Endpoint:

| API Endpoint / Chức năng | STUDENT | STAFF | MANAGER | ADMIN |
| :--- | :---: | :---: | :---: | :---: |
| `POST /api/v1/tickets` | X | - | - | - |
| `GET /api/v1/tickets/my-tickets` | X | - | - | - |
| `POST /api/v1/tickets/{id}/rate` | X | - | - | - |
| `GET /api/v1/staff/queue` | - | X | X | X |
| `POST /api/v1/staff/tickets/{id}/*` | - | X | X | X |
| `POST /api/v1/staff/assign` | - | - | X | X |
| `GET /api/v1/reports/department` | - | - | X | X |
| `GET /api/v1/reports/system` | - | - | - | X |
| `POST/PUT/DELETE /api/v1/users` | - | - | - | X |
| `GET /api/v1/audit-logs` | - | - | - | X |

## 4. Hệ Quả & Đánh Giá Kỹ Thuật (Consequences)

### Tích cực (Positive)
- **Hiệu năng vượt trội:** Lớp Guard Middleware chỉ cần kiểm tra chuỗi `user.role` từ JWT Payload thu được ngay sau khi giải mã token mà không cần query lại Database.
- **An toàn triệt để:** Tránh hoàn toàn việc lộ chéo dữ liệu giữa Sinh viên với nhau và giữa các Phòng ban với nhau.
- **Đơn giản hóa Codebase:** Giúp các lập trình viên Frontend và Backend dễ dàng nắm bắt các annotation phân quyền khi viết code.

### Ràng buộc & Lưu ý Bảo trì (Constraints)
- Trường `role` và `department_id` được ghi cố định vào JWT Token tại thời điểm Đăng nhập. Nếu Admin thực hiện đổi Role hoặc Phòng ban của một User, Admin phải kích hoạt API Revoke Token/Session (Redis Blacklist) để ép User đó đăng nhập lại và nhận JWT Token mang vai trò mới.
# ADR-003: Phương Án Lưu Trữ & Kiểm Soát Truy Cập File Đính Kèm (File Attachment Storage & Access Control)

- **Trạng thái (Status):** Accepted (Đã chấp thuận)
- **Ngày quyết định:** 2026-09-15 (Giai đoạn Thiết kế Kiến trúc)
- **Đối tượng áp dụng:** Backend Engineering Team, Infrastructure / DevOps Team, Security Audit Team

## 1. Bối Cảnh (Context)
Trong hệ thống UniSupport, Sinh viên và Nhân viên thường xuyên tải lên các file đính kèm minh chứng (Bảng điểm, đơn từ, giấy xác nhận, ảnh chụp chứng minh y tế/gia cảnh). Các tài liệu này chứa thông tin cá nhân và dữ liệu học tập nhạy cảm.

Yêu cầu kỹ thuật bắt buộc:
1. **Bảo mật tuyệt đối (Zero Public Access):** Không lưu file ở thư mục Public web root. Ngăn chặn triệt để hành vi truy cập trực tiếp qua Static URL hoặc dò quét file (URL Enumeration Attack).
2. **Kiểm soát truy cập dựa trên Quyền (Contextual Access Control):** Chỉ những người dùng liên quan trực tiếp đến Ticket mới có quyền xem/tải file.
3. **Kiểm tra An toàn File (Security Validation):** Ngăn chặn việc tải lên file độc hại (Executable files, Web shell, Script Injection) giả mạo đuôi file.
4. **Giới hạn Tài nguyên (Resource Limit):** Kiểm soát chặt chẽ dung lượng và số lượng file để tránh tấn công từ chối dịch vụ (DoS Storage).

## 2. Các Phương Án Cân Nhắc (Options Considered)
- **Phương án A: Public Static Direct Link** (Lưu thư mục Public Web Root)
  - *Ưu điểm:* Cấu hình đơn giản, Web Server (Nginx/Apache) phục vụ static file cực nhanh mà không qua Backend processing.
  - *Nhược điểm:* Lỗ hổng bảo mật nghiêm trọng. Bất kỳ ai có đường dẫn URL (kể cả người dùng chưa đăng nhập) đều xem/tải được file nhạy cảm của sinh viên.
- **Phương án B: Presigned URL** (AWS S3 / Cloud Storage - Temporary URL)
  - *Ưu điểm:* Giảm tải I/O cho Backend Server, link tự động hết hạn sau khoảng thời gian ngắn (ví dụ: 15 phút).
  - *Nhược điểm:* Đòi hỏi tích hợp Cloud Storage ngoài; nếu mô hình triển khai của Aurora University sử dụng hạ tầng Server nội bộ (On-Premise) thì không áp dụng được.
- **Phương án C: Private Storage + Authenticated Stream API / Signed Proxy Path** (Được chọn)
  - *Ưu điểm:* Đảm bảo 100% file lưu ở thư mục bảo vệ cách ly hoàn toàn với Web Root. Mọi request truy cập file đều bắt buộc phải qua bước kiểm tra Token và Phân quyền context của Ticket.
  - *Nhược điểm:* Phát sinh I/O và CPU load nhẹ trên Backend Server khi kiểm tra quyền và stream dữ liệu file.

## 3. Quy Định Kỹ Thuật Chi Tiết (Detailed Specifications)

### 3.1. Quy Định Validation File Đính Kèm (File Validation Rules)
Mọi file tải lên (khi Tạo Ticket, Bổ sung hồ sơ, hay Gửi kết quả) đều phải trải qua 2 lớp kiểm tra (Two-tier Validation):

| Tiêu chí kiểm tra | Quy định Validation Phía Client | Quy định Validation Phía Server (Bắt buộc) |
| :--- | :--- | :--- |
| **Số lượng File** | Maximum 5 file / 1 lần request. | Block ngay nếu `files.length > 5`. Trả mã lỗi `400 FILE_COUNT_EXCEEDED`. |
| **Dung lượng File** | Maximum 5MB ($5.242.880\text{ Bytes}$) / 1 file. | Kiểm tra `file.size <= 5242880`. Trả mã lỗi `400 FILE_EXCEEDS_LIMIT`. |
| **Định dạng Mở rộng** | Chỉ cho phép chọn: `.pdf`, `.png`, `.jpg`, `.jpeg`. | Kiểm tra File Extension (Case-insensitive). |
| **MIME Type Thực tế** | Kiểm tra `file.type` từ Browser Input. | Đọc Magic Bytes (Binary Header) của file trên Server để xác thực MIME Type thực tế:<br>- PDF: `application/pdf` (`%PDF`)<br>- PNG: `image/png` (`\x89PNG`)<br>- JPEG/JPG: `image/jpeg` (`\xFF\D8\xFF`)<br>Chống hoàn toàn việc đổi đuôi `.exe` / `.php` thành `.pdf`. |
| **Đổi tên File (Sanitization)** | Giữ nguyên tên gốc hiển thị cho user (`file_name`). | Tự động đổi tên file khi lưu đĩa cứng sang chuỗi UUID v4 ngẫu nhiên để tránh đè file và chặn Path Traversal (`../../`):<br>`stored_filename = {uuid_v4}.{ext}` (VD: `e3b0c442-98fc-11ee-b9d1-0242ac120002.pdf`). |

### 3.2. Cấu Trúc Lưu Trữ (Directory Structure)
File đính kèm được lưu trữ tại thư mục cách ly ngoài Web Root trên Server nội bộ:  
`/var/app/data/attachments/YYYY/MM/DD/{stored_filename}`

### 3.3. Quy Trình Phân Quyền Xem File (Access Control Matrix & Streaming Mechanism)
Khi người dùng click vào link xem/tải file: `GET /api/v1/attachments/{file_id}`

```plaintext
[Client Request] ──(Header: Bearer Token)──> [API Gateway / Backend]
                                                    │
1. Verify JWT Token
                                                    │
2. Query Ticket Owner & Assignee
                                                    │
                                      ┌─────────────┴─────────────┐
                               [CÓ QUYỀN]                     [KHÔNG QUYỀN]
                                    │                               │
3. Read File Chunk & Stream            HTTP 403 Forbidden
                        `Content-Type` matching             `FORBIDDEN_ACCESS`
```
- Ma trận Phân quyền Truy cập File (Access Authorization Matrix):
---
| Vai trò / Tác nhân | Điều kiện được phép tải / xem File (`HTTP 200 OK`) |
| :--- | :--- |
| **Sinh viên (STUDENT)** | Đúng là Chủ sở hữu của Ticket chứa file đó (`student_id == ticket.student_id`). |
| **Nhân viên (STAFF)** | Thuộc Phòng ban đang thụ lý Ticket (`department_id == ticket.department_id`) HOẶC là Người trực tiếp xử lý (`assignee_id == ticket.assignee_id`). |
| **Quản lý / Admin (MANAGER / ADMIN)** | Được phép xem toàn bộ file trong hệ thống để phục vụ giám sát và kiểm tra chất lượng. |
| **Khác (Guest / Staff PB khác)** | Bị chặn hoàn toàn. Hệ thống trả về `HTTP 403 Forbidden`. |
---

## 4. Hệ Quả & Đánh Giá Kỹ Thuật (Consequences)

### Tích cực (Positive)
- **An toàn Bảo mật:** Loại bỏ 100% nguy cơ lộ thông tin cá nhân qua Static URL. Không ai có thể tải file nếu không có Token hợp lệ và không thuộc context của Ticket.
- **Chống Độc hại:** Việc kiểm tra Binary Magic Bytes chặn đứng nguy cơ Upload Malware/Webshell lên Server.
- **Toàn vẹn Dữ liệu:** Đổi tên file sang UUID v4 giúp loại bỏ lỗi trùng tên file, lỗi ký tự tiếng Việt có dấu hoặc ký tự đặc biệt gây hỏng đường dẫn storage.

### Ràng buộc & Tối ưu Hiệu năng (Performance Optimization Specs)
- **Tối ưu Server I/O Stream:** Backend **KHÔNG ĐƯỢC** đọc toàn bộ file 5MB vào RAM (`readFileSync`). Bắt buộc sử dụng Stream / Chunked Transfer Encoding (`createReadStream`) để truyền dữ liệu file về Client, giúp tiết kiệm RAM Backend Server.
- **Cấu hình Caching Control phía Client:** Trả về Header `Cache-Control: private, max-age=3600` để Trình duyệt của người dùng có quyền lưu cache tạm trong 1 giờ cho chính phiên làm việc đó, tránh việc gọi re-fetch API liên tục khi xem lại ảnh/PDF nhiều lần.

## 5. Ràng Buộc Validation & Mã Lỗi Hệ Thống (Error Codes)

| Ràng buộc / Tình huống | Mã lỗi HTTP & Error Code | Message hiển thị cho người dùng |
| :--- | :--- | :--- |
| **File quá dung lượng (> 5MB)** | `400 Bad Request`<br><br>`FILE_EXCEEDS_LIMIT` | "File [Tên_File] vượt quá dung lượng 5MB cho phép." |
| **Số lượng vượt quá 5 file** | `400 Bad Request`<br><br>`FILE_COUNT_EXCEEDED` | "Chỉ được tải lên tối đa 5 file đính kèm trong một lần gửi." |
| **Sai Magic Bytes / Giả mạo đuôi file** | `400 Bad Request`<br><br>`FILE_TYPE_NOT_ALLOWED` | "File không đúng định dạng cho phép (.pdf, .png, .jpg, .jpeg)." |
| **Không có Token xác thực** | `401 Unauthorized`<br><br>`UNAUTHORIZED` | "Phiên đăng nhập hết hạn. Vui lòng đăng nhập lại để xem file." |
| **Không có quyền truy cập file** | `403 Forbidden`<br><br>`FORBIDDEN_ACCESS` | "Bạn không có quyền xem tài liệu đính kèm này." |
| **File bị xóa hoặc không tìm thấy** | `404 Not Found`<br><br>`ATTACHMENT_NOT_FOUND` | "Tài liệu đính kèm không tồn tại trên hệ thống." |
# Quyết Định Kiến Trúc & Kỹ Thuật (Architecture Decision Records - ADR)

## 1. Tổng Quan
Thư mục này lưu trữ các Quyết định Kiến trúc & Kỹ thuật quan trọng (ADR) trong quá trình thiết kế và phát triển hệ thống **UniSupport** cho **Aurora University**. Mỗi tài liệu ADR ghi nhận bối cảnh, lý do lựa chọn giải pháp, cũng như ưu/nhược điểm và hệ quả của quyết định đó.

---

## 2. Danh Sách Các Báo Cáo ADR

| Mã ADR | Tiêu Đề Quyết Định | Trạng Thái | Tóm Tắt Giải Pháp |
| :--- | :--- | :---: | :--- |
| **`ADR-001`** | Quy tắc sinh mã Ticket duy nhất (Ticket ID Generation) | **ACCEPTED** | Định dạng `TK-YYYYMMDD-XXXX` tự sinh, đảm bảo duy nhất và hỗ trợ tra cứu. |
| **`ADR-002`** | Giải pháp phân quyền 3 vai trò (Role-Based Access Control) | **ACCEPTED** | Mô hình RBAC tĩnh với 3 vai trò: Sinh viên, Nhân viên, Quản lý. |
| **`ADR-003`** | Phương án lưu trữ & Phân quyền xem File đính kèm | **ACCEPTED** | Lưu trữ Private Storage, kiểm soát quyền xem qua Chống truy cập trực tiếp URL. |
# Thiết Kế Bảo Mật & Xác Thực (Security & Access Control)

## 1. Xác Thực & Ủy Quyền (Authentication & Authorization)
* **Xác thực danh tính:** Hệ thống áp dụng cơ chế xác thực dựa trên Token (JWT) hoặc Session bảo mật qua kết nối HTTPS.
* **Chống giả mạo:** Token đăng nhập lưu thông tin ID người dùng, vai trò (`Role`) và ID phòng ban liên kết. Mọi API private bắt buộc phải đi kèm Bearer Token trên header.

---

## 2. Kiểm Soát Truy Cập Phân Quyền (RBAC Middleware)
Backend xây dựng Middleware phân quyền kiểm tra theo ma trận vai trò (`ADR-002`):
* **Đối với Endpoint Sinh viên:** Middleware kiểm tra Token có vai trò `STUDENT`. Kiểm tra ID sinh viên trong Ticket trùng khớp với ID người dùng trong Token.
* **Đối với Endpoint Nhân viên:** Middleware kiểm tra Token có vai trò `STAFF`. Kiểm tra phòng ban xử lý Ticket trùng với phòng ban của nhân viên.
* **Đối với Endpoint Quản lý:** Middleware chặn toàn bộ truy cập không có vai trò `MANAGER` hoặc `ADMIN`.

---

## 3. An Toàn File & Dữ Liệu Nhạy Cảm
* **Bảo mật File đính kèm (`ADR-003`):** Tuyệt đối không lưu file trong thư mục công khai (`/public`). API xem file kiểm tra danh tính và trả dữ liệu dưới dạng FileStream trực tiếp.
* **Lọc dữ liệu độc hại:** Áp dụng Sanitize Input chống các cuộc tấn công Cross-Site Scripting (XSS), SQL Injection và validate dung lượng file strictly dưới 5MB.
* **Nhật ký tra soát (Audit Log):** Tự động ghi lại log thao tác đổi quyền, đổi trạng thái Ticket kèm địa chỉ IP vào bảng `audit_logs`.
# Các Ràng Buộc Dự Án (Project Constraints)

## 1. Ràng Buộc Về Thời Gian (Schedule Constraints)
* **Tổng thời gian thực hiện:** Đội ngũ phát triển có **14 tuần** (tương đương **70 ngày làm việc**) để hoàn thiện từ thời điểm khởi động dự án đến khi bàn giao chính thức.
* **Thời gian nghiệm thu:** Aurora University có **10 ngày làm việc** để tiến hành kiểm thử UAT kể từ khi nhận bàn giao chính thức (mốc Tuần 14).
* **Thời gian bảo hành:** Hệ thống được hỗ trợ sửa lỗi kỹ thuật miễn phí trong vòng **30 ngày** kể từ ngày hai bên xác nhận biên bản nghiệm thu.

---

## 2. Ràng Buộc Về Ngân Sách (Budget Constraints)
* **Tổng kinh phí thực hiện:** **300 Triệu VNĐ** (Chưa bao gồm các yêu cầu phát sinh ngoài phạm vi đã cam kết).
* **Điều khoản thanh toán:** Chi tiết các mốc thanh toán (bao gồm tiền đặt cọc khởi động Mốc 0) được quy định chi tiết trong hợp đồng triển khai chính thức.

---

## 3. Ràng Buộc Về Phạm Vi (Scope Constraints - Out of Scope)
Các hạng mục sau tuyệt đối không thuộc phạm vi thực hiện của dự án:
* Phát triển Mobile App độc lập (iOS/Android).
* Thiết lập sao lưu tự động (Auto-backup), giám sát hạ tầng máy chủ lâu dài.
* Phân quyền chi tiết nhiều cấp phức tạp và ghi lịch sử thao tác chi tiết ở mức nâng cao.
* Chức năng Chat trực tiếp (Livechat) hoặc Gọi thoại/Video trong hệ thống.
* Tối ưu hóa kiến trúc chịu tải lớn vượt quá quy mô 3.000 sinh viên.
# Thuật Ngữ & Giải Thích Khái Niệm Dự Án (Project Glossary & Technical Terms)

## 1. Mục Tiêu Chuẩn Hóa
Tài liệu Project Glossary đóng vai trò là từ điển thuật ngữ thống nhất (Single Source of Truth - SSOT) cho toàn bộ dự án UniSupport tại Aurora University. Việc chuẩn hóa danh mục từ khóa này giúp toàn bộ các bên liên quan (Chủ đầu tư, Ban Quản lý Dự án, Business Analyst, Tech Lead, Lập trình viên Backend/Frontend, QA/Tester và Đội ngũ Vận hành) sử dụng chung một ngôn ngữ kỹ thuật, tránh hiểu nhầm nghiệp vụ trong quá trình phát triển, kiểm thử UAT và bàn giao.

## 2. Bảng Danh Mục Thuật Ngữ Kỹ Thuật & Quản Lý Dự Án

| Thuật Ngữ | Tên Đầy Đủ / Khái Niệm | Giải Thích Kỹ Thuật Chi Tiết & Phạm Vi Áp Dụng |
| :--- | :--- | :--- |
| **UniSupport** | University Support Platform | Hệ thống phần mềm Web Application quản lý, điều phối và giải quyết các yêu cầu hỗ trợ sinh viên tại Aurora University, triển khai trong **14 tuần** với ngân sách **300 triệu VNĐ**. |
| **Ticket** | Support Ticket / Phiếu hỗ trợ | Đơn vị dữ liệu cốt lõi (Core Entity) đại diện cho 01 yêu cầu hỗ trợ do Sinh viên gửi. Chứa thông tin mô tả, trạng thái FSM, file đính kèm, lịch sử trao đổi và đánh giá CSAT. |
| **Ticket ID** | Ticket Identifier | Mã định danh duy nhất của Ticket có dạng `TK-YYYYMMDD-XXXX` (VD: `TK-20261009-0001`), độ dài **15 ký tự**, sinh tự động qua Redis Atomic Counter và là duy nhất trên toàn hệ thống. |
| **RBAC** | Role-Based Access Control | Cơ chế kiểm soát truy cập phân quyền tĩnh với 4 Vai trò: `STUDENT`, `STAFF`, `MANAGER`, `ADMIN` (ADR-002). Xác thực qua JWT và Middleware phân quyền theo Data Scope. |
| **FSM** | Finite State Machine | Máy trạng thái hữu hạn quản lý 6 trạng thái vòng đời Ticket: `NEW`, `IN_PROGRESS`, `NEED_MORE_INFO`, `TRANSFERRED`, `RESOLVED`, `CLOSED` (Cùng trạng thái terminal `REJECTED`). |
| **SLA** | Service Level Agreement | Cam kết thời gian giải quyết Ticket tối đa **24 giờ làm việc** (Chỉ tính từ 08:00 đến 17:00 từ Thứ 2 đến Thứ 6). Quản lý qua 3 trạng thái chỉ báo: `ON_TRACK`, `WARNING`, `BREACHED`. |
| **CSAT** | Customer Satisfaction Score | Điểm số đánh giá mức độ hài lòng của Sinh viên sau khi Ticket được giải quyết, tính theo thang điểm **1–5 sao** kèm nhận xét tùy chọn. |
| **Idempotency Key** | Client Request Identifier | Mã UUID v4 ngẫu nhiên gửi trong Request Header `X-Client-Request-ID` khi bấm gửi Ticket nhằm chống tạo trùng dữ liệu do mạng gián đoạn hoặc click đúp. |
| **Zero Public Access** | Private File Storage Policy | Kiến trúc bảo mật lưu trữ file đính kèm ngoài Web Root (`/var/app/data/attachments/`). File chỉ được truy cập qua API Check Authentication & Stream Binary Chunk. |
| **Audit Trail** | Audit Logging | Bảng nhật ký ghi vết tự động (`audit_logs`) dạng Append-Only, lưu vĩnh viễn các thao tác quản trị nhạy cảm (Đăng nhập, Phân quyền, Khóa tài khoản, Chuyển phòng ban). |
| **JWT** | JSON Web Token | Mã định danh xác thực Stateless sử dụng thuật toán HMAC-SHA256 (HS256). Access Token có hiệu lực **15 phút**, Refresh Token lưu Cookie HTTP-Only có hiệu lực **7 ngày**. |
| **Redis Cache** | Remote Dictionary Server | Hệ thống bộ nhớ In-Memory Data Store dùng để đếm Atomic Ticket ID, lưu JWT Blacklist khi Logout/Khóa account, và Cache dữ liệu thống kê Dashboard (TTL = 30–60 giây). |
| **UAT** | User Acceptance Testing | Kiểm thử chấp nhận người dùng do Cán bộ và Ban Quản lý Aurora University trực tiếp thực hiện trong **10 ngày làm việc** trước khi nghiệm thu chính thức. |
| **RTM** | Requirements Traceability Matrix | Ma trận truy xuất yêu cầu liên kết 1:1 từ Proposal $\rightarrow$ PRD Feature $\rightarrow$ API Endpoint $\rightarrow$ UAT Test Scenario nhằm đảm bảo **100%** tính bao phủ nghiệm thu. |
| **Responsive UI** | Responsive User Interface | Thiết kế giao diện đa nền tảng (Desktop & Mobile) áp dụng Tailwind CSS / Ant Design Breakpoints, tối ưu trải nghiệm cho 3.000 sinh viên và nhân viên. |
| **Out of Scope** | Ngoài phạm vi dự án | Các tính năng không nằm trong cam kết Hợp đồng dự án (VD: Gọi điện/Video call trực tiếp, Tích hợp AI Chatbot tự động trả lời, Dynamic ABAC Custom Roles, Mobile App Native). |

## 3. Ma Trận Áp Dụng Thuật Ngữ Theo Tài Liệu Hệ Thống

| Nhóm Tài Liệu | Danh Mục Thuật Ngữ Cốt Lõi Áp Dụng |
| :--- | :--- |
| **01-product / 02-domain** | Ticket, Ticket ID, FSM, SLA, CSAT, Responsive UI, Out of Scope |
| **03-modules (M01–M03)** | RBAC, SLA, CSAT, Idempotency Key, Zero Public Access |
| **04-workflows (WF-01 – WF-06)** | FSM, Ticket ID, Audit Trail, Zero Public Access, SLA |
| **05-nfr / 07-architecture** | RBAC, JWT, Redis Cache, Zero Public Access, Idempotency Key, Audit Trail |
| **06-acceptance / 08-project** | UAT, RTM, UniSupport, Out of Scope |
# Lịch Trình Thực Hiện & Các Cột Mốc Key Milestones

## 1. Kế Hoạch Triển Khai Theo Giai Đoạn (14 Tuần / 70 Ngày Làm Việc)

| Giai Đoạn | Thời Gian | Nội Dung Công Việc Chính |
| :--- | :--- | :--- |
| **Giai đoạn 1 – Thu thập yêu cầu** | Tuần 1–2 | Thu thập và phân tích yêu cầu, xác định phạm vi, luồng nghiệp vụ và tiêu chí nghiệm thu. |
| **Giai đoạn 2 – Thiết kế** | Tuần 3–4 | Thiết kế giao diện (UI/UX), prototype, kiến trúc hệ thống, cơ sở dữ liệu (ERD), API và phân quyền. |
| **Giai đoạn 3 – Phát triển chính** | Tuần 5–9 | Phát triển 3 phân hệ chức năng cốt lõi:<br>• *Module Sinh viên (Tuần 5–6):* Đăng nhập, Tạo Ticket, Theo dõi, Đánh giá.<br>• *Module Nhân viên (Tuần 7–8):* Tiếp nhận, Phân loại, Xử lý, Chuyển phòng ban, Đóng Ticket.<br>• *Module Quản lý (Tuần 9):* Dashboard, Báo cáo thống kê, Quản trị tài khoản. |
| **Giai đoạn 4 – Tích hợp hệ thống** | Tuần 10–11 | Tích hợp giao diện Frontend và Backend, xây dựng Dashboard, Báo cáo và kiểm tra phân quyền RBAC. |
| **Giai đoạn 5 – Kiểm thử & Nghiệm thu** | Tuần 12–13 | Kiểm thử chức năng, kiểm thử tích hợp, kiểm thử hồi quy, UAT với Client và sửa lỗi. |
| **Giai đoạn 6 – Hoàn thiện & Bàn giao** | Tuần 14 | Sửa lỗi cuối, triển khai hệ thống lên Server Client, hoàn thiện tài liệu và bàn giao chính thức. |

---

## 2. Các Cột Mốc Quan Trọng (Key Milestones)

* **Mốc 0 (Tuần 1):** Ký xác nhận hợp tác và đặt cọc triển khai dự án.
* **Mốc 1 (Cuối Tuần 2):** Chốt phạm vi nghiệp vụ và tài liệu yêu cầu dự án.
* **Mốc 2 (Cuối Tuần 4):** Phê duyệt bản thiết kế giao diện & Prototype.
* **Mốc 3 (Cuối Tuần 9):** Hoàn thành phát triển 3 phân hệ, Demo nội bộ.
* **Mốc 4 (Tuần 13):** Hoàn thành đợt kiểm thử UAT và tổng hợp phản hồi từ Client.
* **Mốc 5 (Tuần 14):** Hoàn tất xử lý các lỗi thuộc phạm vi, triển khai và bàn giao chính thức.

---

## 3. Lịch Trình Nghiệm Thu & Bảo Hành Post-Delivery

* **Quy trình nghiệm thu (10 ngày làm việc):** Aurora University có 10 ngày làm việc kể từ thời điểm bàn giao chính thức (Mốc 5) để tiến hành kiểm thử nghiệm thu. Các lỗi phát sinh do đội phát triển được ghi nhận và khắc phục, không tính là điều kiện từ chối nghiệm thu nếu không ảnh hưởng chức năng chính.
* **Chính sách bảo hành (30 ngày):** Hỗ trợ khắc phục lỗi kỹ thuật miễn phí trong 30 ngày kể từ ngày ký biên bản nghiệm thu chính thức. Không áp dụng cho các yêu cầu thay đổi hoặc tính năng mới ngoài phạm vi.
# Các Vấn Đề Chờ Thảo Luận & Phê Duyệt (Open Questions)

Tài liệu này ghi nhận các vấn đề cần sự phối hợp xác nhận hoặc phê duyệt từ đại diện **Aurora University** trong các giai đoạn triển khai:

---

## Danh Sách Các Câu Hỏi & Vấn Đề Mở

| STT | Vấn Đề Trao Đổi | Bên Phụ Trách | Trạng Thái | Ghi Chú / Kết Quả Xác Nhận |
| :---: | :--- | :---: | :---: | :--- |
| **01** | Cung cấp thông số cấu hình Hạ tầng Server và Tên miền (Domain) chính thức phục vụ triển khai Staging/Production? | Aurora University | **Pending** | Cần chốt trước Tuần 11 để chuẩn bị môi trường. |
| **02** | Thống nhất danh sách tài khoản mẫu và phân quyền phòng ban ban đầu để import dữ liệu kiểm thử UAT? | Aurora University | **Pending** | Cần bàn giao trước Tuần 12. |
| **03** | Xác nhận quy định thời gian xử lý tiêu chuẩn (SLA) mặc định cho từng nhóm vấn đề hỗ trợ? | Aurora University | **In Progress** | Sử dụng làm căn cứ tính chỉ số Overdue Ticket trên Dashboard. |
| **04** | Thống nhất danh mục các định dạng file và giới hạn 5MB cho file đính kèm đợt UAT? | Hai bên | **Confirmed** | Đã chốt file PDF, PNG, JPG, JPEG <= 5MB (`ADR-003`). |
